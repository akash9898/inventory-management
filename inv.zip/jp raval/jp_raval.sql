-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 20, 2020 at 10:27 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jp_raval`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_expired_card`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_expired_card` (IN `_sdm_id` INT(11), IN `_sdm_cust_id` INT(12), IN `_sdm_repeat` INT(2), IN `_sdm_comment` MEDIUMTEXT, IN `_sdm_interval_days` INT(11), IN `_sdm_interval_months` INT(11), IN `_sdm_interval_year` INT(11), IN `_sdm_insrid` INT(10), IN `_sdm_insdt` DATETIME, IN `_sdm_logrid` INT(10), IN `_sdm_logdt` DATETIME, IN `_sdtm_id` INT(11), IN `_sdtm_cust_id` INT(12), IN `_sdtm_sdm_id` INT(12), IN `_sdtm_date` DATETIME, IN `_sdtm_insrid` INT(12), IN `_sdtm_insdt` DATETIME, IN `_sdtm_logrid` INT(12), IN `_sdtm_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
				insert into service_details_master values(null,_sdm_cust_id,_sdm_repeat,_sdm_comment,0,_sdm_interval_days,_sdm_interval_months,_sdm_interval_year,_sdm_insrid,_sdm_insdt,_sdm_logrid,_sdm_logdt);
				SET _ret = 2;
                set _sdtm_sdm_id = LAST_INSERT_ID();
                insert into service_date_master  values(null,_sdtm_cust_id,_sdtm_sdm_id,6,_sdtm_date,2,_sdtm_insrid,_sdtm_insdt,_sdtm_logrid,_sdtm_logdt);
END$$

DROP PROCEDURE IF EXISTS `add_product_variation_name_qty`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_product_variation_name_qty` (IN `_prvm_id` INT(11), IN `_prvm_pdrm_id` INT(11), IN `_prvm_product_variation_name` VARCHAR(45), IN `_prvm_tax_code_id` INT(10), IN `_prvm_low_stock` INT(10), IN `_prvm_insrid` INT(11), IN `_prvm_insdt` DATETIME, IN `_prvm_logdt` DATETIME, IN `_prvm_logrid` INT(11), IN `_pssm_id` INT(11), IN `_pssm_prdm_id` INT(11), IN `_pssm_pvnm_id` INT(11), IN `_pssm_starting_qty` INT(11), IN `_pssm_starting_price` INT(11), IN `_pssm_financial_year` VARCHAR(15), IN `_pssm_insrid` INT(11), IN `_pssm_insdt` DATETIME, IN `_pssm_logrid` INT(11), IN `_pssm_logdt` DATETIME, OUT `_prd_var_id` INT(10), OUT `_ret` INT(10))  BEGIN

	declare _pvnmval bool;
/*	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;*/
    SET _pvnmval = true;
    
		IF EXISTS(SELECT prvm_id FROM product_variation_name_master WHERE prvm_product_variation_name = _prvm_product_variation_name and prvm_pdrm_id=_prvm_pdrm_id )
			THEN
				SET _ret = 1;
                
                 set _pvnmval = false;
			END IF;
				
                IF(_pvnmval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_prvm_id = 0 )
              THEN
					Insert into product_variation_name_master
					values(null,_prvm_pdrm_id,_prvm_product_variation_name,_prvm_tax_code_id,_prvm_low_stock,_prvm_insrid,_prvm_insdt,_prvm_logdt,_prvm_logrid);
                    
                    set _prd_var_id = last_insert_id();
                    set _pssm_prdm_id = _prvm_pdrm_id;
                    set _pssm_pvnm_id = last_insert_id();
					
                    /*set _prd_spe_pvnm_id = last_insert_id();*/
                     
                    insert into product_starting_stock_master 
                    values(null,_pssm_prdm_id,_pssm_pvnm_id,_pssm_starting_qty,_pssm_starting_price,_pssm_financial_year,_pssm_insrid,_pssm_insdt,_pssm_logrid,_pssm_logdt);
                  	SET _ret = 2;
                    
                    /*
                    set _prd_spe_prdm_id = _prvm_pdrm_id;
                   
                    insert into product_specification_master 
                    values(null,_prd_spe_prdm_id,_prd_spe_pvnm_id,_prd_spe_oth_cat_id,_prd_spe_oth_cat_val,_prd_spe_insrid,_prd_spe_insdt,_prd_spe_logrid,_prd_spe_logdt);
                    */
				
			   END IF;       
   END If;         
   END$$

DROP PROCEDURE IF EXISTS `add_sales_bill_details`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_sales_bill_details` (IN `_sbd_id` INT(11), IN `_sbd_bill_id` INT(10), IN `_sbd_product_id` INT(10), IN `_sbd_product_price` FLOAT, IN `_sbd_product_actual_price` FLOAT, IN `_sbd_quentity` INT(10), IN `_sbd_actual_quentity` INT(10), IN `_sbd_total` FLOAT, IN `_sbd_actual_total` FLOAT, IN `_sbd_discount` FLOAT, IN `_sbd_discount_amount` FLOAT, IN `_sbd_cgst` FLOAT, IN `_sbd_sgst` FLOAT, IN `_sbd_igst` FLOAT, IN `_sbd_insrid` INT(10), IN `_sbd_insdt` DATETIME, IN `_sbd_logrid` INT(10), IN `_sbd_logdt` DATETIME)  BEGIN

insert into sales_bill_detail values(null,_sbd_bill_id,_sbd_product_id,_sbd_product_price,_sbd_product_actual_price,_sbd_quentity,_sbd_actual_quentity,_sbd_total,_sbd_actual_total,_sbd_discount,_sbd_discount_amount,_sbd_cgst,_sbd_sgst,_sbd_igst,_sbd_insrid,_sbd_insdt,_sbd_logrid,_sbd_logdt);

END$$

DROP PROCEDURE IF EXISTS `add_sales_bill_master`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_sales_bill_master` (IN `_sbm_id` INT(11), IN `_customer_id` INT(10), IN `_sbm_sales_bill_id` VARCHAR(45), IN `_sbm_sales_date` DATETIME, IN `_sbm_total_amount` INT(20), IN `_sbm_total_actual_amount` INT(20), IN `_sbm_status` TINYINT(10), IN `_sbm_financial_year` VARCHAR(20), IN `_sbm_mode_of_payment` INT(10), IN `_sbm_insrid` INT(10), IN `_sbm_insdt` DATETIME, IN `_sbm_logrid` INT(10), IN `_sbm_logdt` DATETIME, OUT `_sbm_ret_id` INT(10), OUT `_ret` INT(10))  BEGIN

	declare _sbmval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;

	SET _sbm_ret_id=0;
	SET _sbmval = true;

		    
			IF(_sbmval = false)
                THEN
					SET _ret = 1;
                ELSE
			IF(_sbm_id = 0 )
              THEN
			insert into sales_bill_master values(null,_customer_id,_sbm_sales_bill_id,_sbm_sales_date,_sbm_total_amount,_sbm_total_actual_amount,_sbm_status,_sbm_financial_year,_sbm_mode_of_payment,_sbm_insrid,_sbm_insdt,_sbm_logrid,_sbm_logdt);
			SET _ret = 2;
			SET _sbm_ret_id = last_insert_id();
            
        END IF;
 END IF;   
 COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_sales_bill_payment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_sales_bill_payment` (IN `_sbp_id` INT(11), IN `_sbp_bill_id` INT(10), IN `_sbp_mod_of_payment` INT(10), IN `_sbp_date_of_payment` DATETIME, IN `_sbp_amount` INT(10), IN `_sbp_insrid` INT(10), IN `_sbp_insdt` DATETIME, IN `_sbp_logrid` INT(10), IN `_sbp_logdt` DATETIME)  BEGIN

insert into sales_bill_payment values(null,_sbp_bill_id,_sbp_mod_of_payment,_sbp_date_of_payment,_sbp_amount,_sbp_insrid,_sbp_insdt,_sbp_logrid,_sbp_logdt);

END$$

DROP PROCEDURE IF EXISTS `add_supplier_bill`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_supplier_bill` (IN `_spb_id` INT(11), IN `_spb_supplier_id` INT(10), IN `_spb_purchse_date` DATETIME, IN `_spb_total_amount` INT(20), IN `_spb_status` TINYINT(10), IN `_spb_insrid` INT(10), IN `_spb_insdt` DATETIME, IN `_spb_logrid` INT(10), IN `_spb_logdt` DATETIME, OUT `spb_id` INT(10))  BEGIN


insert into supplier_purchase_bill_master values(null,_spb_supplier_id,_spb_purchse_date,_spb_total_amount,_spb_status,_spb_insrid,_spb_insdt,_spb_logrid,_spb_logdt);
set spb_id = last_insert_id();


END$$

DROP PROCEDURE IF EXISTS `add_supplier_bill_details`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_supplier_bill_details` (IN `_spbd_id` INT(11), IN `_spbd_bill_id` INT(11), IN `_spbd_product_id` INT(10), IN `_spbd_quentity` INT(10), IN `_spbd_total` INT(10), IN `_spbd_cgst` VARCHAR(10), IN `_spbd_sgst` VARCHAR(10), IN `_spbd_igst` VARCHAR(10), IN `_spbd_insrid` INT(10), IN `_spbd_insdt` DATETIME, IN `_spbd_logrid` INT(10), IN `_spbd_logdt` DATETIME)  BEGIN

insert into supplier_purchase_bill_detail values(null,_spbd_bill_id,_spbd_product_id,_spbd_quentity,_spbd_total,_spbd_cgst,_spbd_sgst,_spbd_igst,_spbd_insrid,_spbd_insdt,_spbd_logrid,_spbd_logdt);

END$$

DROP PROCEDURE IF EXISTS `add_supplier_purchase_bill_details`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_supplier_purchase_bill_details` (IN `_spbd_id` INT(11), IN `_spbd_bill_id` INT(11), IN `_spbd_product_id` INT(10), IN `_spbd_product_price` FLOAT, IN `_spbd_product_actual_price` FLOAT, IN `_spbd_quentity` INT(10), IN `_spbd_actual_quentity` INT(10), IN `_spbd_total` FLOAT, IN `_spbd_actual_total` FLOAT, IN `_spbd_discount` FLOAT, IN `_spbd_discount_amount` FLOAT, IN `_spbd_cgst` VARCHAR(10), IN `_spbd_sgst` VARCHAR(10), IN `_spbd_igst` VARCHAR(10), IN `_spbd_insrid` INT(10), IN `_spbd_insdt` DATETIME, IN `_spbd_logrid` INT(10), IN `_spbd_logdt` DATETIME)  BEGIN

insert into supplier_purchase_bill_detail values(null,_spbd_bill_id,_spbd_product_id,_spbd_product_price,_spbd_product_actual_price,_spbd_quentity,_spbd_actual_quentity,_spbd_total,_spbd_actual_total,_spbd_discount,_spbd_discount_amount,_spbd_cgst,_spbd_sgst,_spbd_igst,_spbd_insrid,_spbd_insdt,_spbd_logrid,_spbd_logdt);

END$$

DROP PROCEDURE IF EXISTS `add_supplier_purchase_bill_master`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_supplier_purchase_bill_master` (IN `_spb_id` INT(11), IN `_spb_supplier_id` INT(10), IN `_spb_purchase_bill_id` VARCHAR(45), IN `_spb_purchse_date` DATE, IN `_spb_total_amount` INT(20), IN `_spb_total_actual_amount` INT(20), IN `_spb_status` TINYINT(10), IN `_spb_financial_year` VARCHAR(20), IN `_spb_mode_of_payment` INT(10), IN `_spb_insrid` INT(10), IN `_spb_insdt` DATETIME, IN `_spb_logrid` INT(10), IN `_spb_logdt` DATETIME, OUT `_spb_ret_id` INT(10), OUT `_ret` INT(10))  BEGIN

	declare _spbval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;

SET _spb_ret_id=0;
SET _spbval = true;

		    
			IF(_spbval = false)
                THEN
					SET _ret = 1;
                ELSE
			IF(_spb_id = 0 )
              THEN
			insert into supplier_purchase_bill_master values(null,_spb_supplier_id,_spb_purchase_bill_id,_spb_purchse_date,_spb_total_amount,_spb_total_actual_amount,_spb_status,_spb_financial_year,_spb_mode_of_payment,_spb_insrid,_spb_insdt,_spb_logrid,_spb_logdt);
			SET _ret = 2;
			SET _spb_ret_id = last_insert_id();
            
        END IF;
 END IF;   
 COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_supplier_purchase_bill_payment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_supplier_purchase_bill_payment` (IN `_spbp_id` INT(11), IN `_spbp_bill_id` INT(10), IN `_spbp_mod_of_payment` INT(10), IN `_spbp_date_of_payment` DATETIME, IN `_spbp_amount` INT(10), IN `_spbp_insrid` INT(10), IN `_spbp_insdt` DATETIME, IN `_spbp_logrid` INT(10), IN `_spbp_logdt` DATETIME)  BEGIN

insert into supplier_purchase_bill_payment values(null,_spbp_bill_id,_spbp_mod_of_payment,_spbp_date_of_payment,_spbp_amount,_spbp_insrid,_spbp_insdt,_spbp_logrid,_spbp_logdt);

END$$

DROP PROCEDURE IF EXISTS `add_update_brand`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_brand` (IN `_bm_rid` INT(11), IN `_bm_name` VARCHAR(45), IN `_bm_insrid` INT(11), IN `_bm_insdt` DATETIME, IN `_bm_logrid` INT(11), IN `_bm_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
	declare _bmval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _bmval = true;
			         
			IF EXISTS(SELECT bm_rid FROM brand_master WHERE bm_name = _bm_name)
			THEN
				SET _ret = 1;
                
                 set _bmval = false;
			END IF;
				
                IF(_bmval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_bm_rid = 0 )
              THEN
					Insert into brand_master
					values(null,_bm_name,_bm_insrid,_bm_insdt,_bm_logrid,_bm_logdt);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_bm_rid != 0)
              THEN
					Update brand_master set bm_name=_bm_name,bm_logrid=_bm_logrid,bm_logdt=_bm_logdt where bm_rid=_bm_rid;
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_category`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_category` (IN `_cat_id` INT(11), IN `_cat_name` VARCHAR(45), IN `_cat_insrid` INT(11), IN `_cat_insdt` DATETIME, IN `_cat_logrid` INT(11), IN `_cat_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
	declare _catval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _catval = true;
			         
			IF EXISTS(SELECT cat_id FROM category_master WHERE cat_name = _cat_name)
			THEN
				 SET _ret = 1;
                 set _catval = false;
			END IF;
				
                IF(_catval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_cat_id = 0 )
              THEN
					Insert into category_master
					values(null,_cat_name,_cat_insrid,_cat_insdt,_cat_logrid,_cat_logdt);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_cat_id != 0)
              THEN
					Update category_master set cat_name=_cat_name,cat_logrid=_cat_logrid,cat_logdt=_cat_logdt where cat_id=_cat_id;
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_customer`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_customer` (IN `_cust_id` INT(11), IN `_cust_first_name` VARCHAR(45), IN `_cust_middle_name` VARCHAR(45), IN `_cust_last_name` VARCHAR(45), IN `_cust_busines_name` VARCHAR(45), IN `_cust_gender` VARCHAR(10), IN `_cust_city_village` VARCHAR(45), IN `_cust_pincode` INT(10), IN `_cust_address` VARCHAR(100), IN `_cust_primary_ctn` VARCHAR(12), IN `_cust_whats_app_ctn` VARCHAR(12), IN `_cust_second_ctn` VARCHAR(12), IN `_cust_third_ctn` VARCHAR(12), IN `_cust_insrid` INT(11), IN `_cust_insdt` DATETIME, IN `_cust_logrid` INT(11), IN `_cust_logdt` DATETIME, IN `_cust_email` VARCHAR(100), OUT `_ret` INT(11))  BEGIN
	DECLARE flag bool;
    DECLARE mobile varchar(50);
    DECLARE email varchar(50);
    DECLARE msg text;
   
    SET _ret = 0;
    IF EXISTS (SELECT cust_id from customer_master Where cust_primary_ctn = _cust_primary_ctn)
    THEN

    
			  IF EXISTS (SELECT cust_id from customer_master Where cust_primary_ctn = _cust_primary_ctn)
              THEN 
				IF(_cust_id > 0)
                THEN
					SET mobile = (SELECT cust_primary_ctn FROM customer_master Where cust_id = _cust_id);
                    IF(mobile = _cust_primary_ctn)
                    THEN
						SET flag = false;
					ELSE
						SET flag = true;
                        SET msg = "1Mobile";
                        SET _ret = -1;
                    END IF;
				ELSE
					SET flag = true;
					SET _ret = -1;
                    SET msg = "2Mobile";
                END IF;
				
			
              END IF;
	ELSE
		
			SET flag = false;
			SET _ret = -3;
		
		
    END IF;
    
    IF(flag = false)
    THEN
		IF(_cust_id > 0)
        THEN
			Update customer_master set cust_first_name=_cust_first_name,cust_middle_name=_cust_middle_name,cust_last_name=_cust_last_name,cust_busines_name=_cust_busines_name,cust_primary_ctn=_cust_primary_ctn,cust_whats_app_ctn=_cust_whats_app_ctn,cust_second_ctn=_cust_second_ctn,cust_third_ctn=_cust_third_ctn,cust_gender=_cust_gender,cust_email=_cust_email,cust_address=_cust_address,cust_city_village=_cust_city_village,cust_pincode=_cust_pincode,cust_logrid=_cust_logrid,cust_logdt=_cust_logdt where cust_id=_cust_id;
			
            SET _ret = -5;
        ELSE
        Insert into customer_master values(null,_cust_first_name,_cust_middle_name,_cust_last_name,_cust_busines_name,_cust_primary_ctn,_cust_whats_app_ctn,_cust_second_ctn,_cust_third_ctn,_cust_gender,_cust_email,_cust_address,_cust_city_village,_cust_pincode,_cust_insrid,_cust_insdt,_cust_logrid,_cust_logdt);
			
            SET _ret =LAST_INSERT_ID();
        END IF;
    ELSE
		
        select msg AS '** DEBUG:';
    END IF;
END$$

DROP PROCEDURE IF EXISTS `add_update_ideal_selling_price`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_ideal_selling_price` (IN `_idle_sell_id` INT(10), IN `_idle_prod_var_id` INT(10), IN `_idle_prod_var_name` VARCHAR(45), IN `_idle_prod_selling_price` INT(10), IN `_idle_insrid` INT(10), IN `_idle_insdt` DATETIME, IN `_idle_logrid` INT(10), IN `_idle_logdt` DATETIME)  BEGIN

if(_idle_sell_id = 0)
THEN
insert into idle_selling_price values(null,_idle_prod_var_id,_idle_prod_var_name,_idle_prod_selling_price,_idle_insrid,_idle_insdt,_idle_logrid,_idle_logdt);
end if;

if(_idle_sell_id!=0)
THEN
update idle_selling_price set idle_prod_var_name=_idle_prod_var_name,idle_prod_selling_price=_idle_prod_selling_price,idle_logrid=_idle_logrid,idle_logdt=_idle_logdt where idle_sell_id=_idle_sell_id;
end if;

END$$

DROP PROCEDURE IF EXISTS `add_update_into_product_specification_edit_page`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_into_product_specification_edit_page` (IN `_prd_spe_id` INT(11), IN `_prd_spe_prdm_id` INT(11), IN `_prd_spe_pvnm_id` INT(11), IN `_prd_spe_oth_cat_id` INT(11), IN `_prd_spe_oth_cat_val` VARCHAR(45), IN `_prd_spe_insrid` INT(11), IN `_prd_spe_insdt` DATETIME, IN `_prd_spe_logrid` INT(11), IN `_prd_spe_logdt` DATETIME)  BEGIN
 /*
	declare _prdval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		
        SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _prdval = true;
*/
	if(_prd_spe_id = 0)
    THEN 
    insert into product_specification_master values(null,_prd_spe_prdm_id,_prd_spe_pvnm_id,_prd_spe_oth_cat_id,_prd_spe_oth_cat_val,_prd_spe_insrid,_prd_spe_insdt,_prd_spe_logrid,_prd_spe_logdt);
	END IF;
    
    if(_prd_spe_id != 0)
    THEN 
	update product_specification_master set prd_spe_oth_cat_val=_prd_spe_oth_cat_val,prd_spe_logrid=_prd_spe_logrid,prd_spe_logdt=_prd_spe_logdt where prd_spe_id=_prd_spe_id;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `add_update_mode_of_payment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_mode_of_payment` (IN `_mop_id` INT(11), IN `_mop_name` VARCHAR(45), OUT `_ret` TINYINT(2))  BEGIN
	declare _mopval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _mopval = true;
			         
			IF EXISTS(SELECT mop_id FROM mode_of_payment WHERE mop_name = _mop_name)
			THEN
				SET _ret = 1;
                
                 set _mopval = false;
			END IF;
				
                IF(_mopval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_mop_id = 0 )
              THEN
					Insert into mode_of_payment
					values(null,_mop_name);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_mop_id != 0)
              THEN
					Update mode_of_payment set mop_name=_mop_name  where mop_id=_mop_id;
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_other_category`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_other_category` (IN `_oth_cat_id` INT(11), IN `_oth_cat_name` VARCHAR(45), IN `_oth_cat_is_unit` TINYINT(2), IN `_oth_cat_unit_id` INT(2), IN `_oth_cat_insrid` INT(10), IN `_oth_cat_insdt` DATETIME, IN `_oth_cat_logrid` INT(10), IN `_oth_cat_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
	declare _oth_catval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _oth_catval = true;
			SET _ret = 1;   
			IF EXISTS(SELECT oth_cat_id FROM other_category_master WHERE oth_cat_name = _oth_cat_name and oth_cat_is_unit=_oth_cat_is_unit and oth_cat_unit_id=_oth_cat_unit_id)
			THEN
				 SET _ret = 1;
                 set _oth_catval = false;
			END IF;
				
                IF(_oth_catval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_oth_cat_id = 0 )
              THEN
					Insert into other_category_master
					values(null,_oth_cat_name,_oth_cat_is_unit,_oth_cat_unit_id,_oth_cat_insrid,_oth_cat_insdt,_oth_cat_logrid,_oth_cat_logdt);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_oth_cat_id != 0)
              THEN
					Update other_category_master set oth_cat_name=_oth_cat_name,oth_cat_is_unit=_oth_cat_is_unit,oth_cat_unit_id=_oth_cat_unit_id,oth_cat_logrid=_oth_cat_logrid,oth_cat_logdt=_oth_cat_logdt where oth_cat_id=_oth_cat_id;
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_product`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_product` (IN `_prdm_id` INT(12), IN `_prdm_name` VARCHAR(45), IN `_prdm_cat_id` INT(11), IN `_prdm_brand_id` INT(11), IN `_prdm_unit_id` INT(11), IN `_prdm_photo_link` MEDIUMTEXT, IN `_prdm_insrid` INT(11), IN `_prdm_ldt` DATETIME, IN `_prdm_logrid` INT(11), IN `_prdm_logdt` DATETIME, IN `_prvm_id` INT(11), IN `_prvm_pdrm_id` INT(11), IN `_prvm_product_variation_name` VARCHAR(45), IN `_prvm_tax_code_id` INT(10), IN `_prvm_low_stock` INT(10), IN `_prvm_insrid` INT(11), IN `_prvm_insdt` DATETIME, IN `_prvm_logdt` DATETIME, IN `_prvm_logrid` INT(11), IN `_pssm_id` INT(11), IN `_pssm_prdm_id` INT(11), IN `_pssm_pvnm_id` INT(11), IN `_pssm_starting_qty` INT(11), IN `_pssm_starting_price` INT(11), IN `_pssm_financial_year` VARCHAR(20), IN `_pssm_insrid` INT(11), IN `_pssm_insdt` DATETIME, IN `_pssm_logrid` INT(11), IN `_pssm_logdt` DATETIME, IN `_idle_sell_id` INT(10), IN `_idle_prod_var_id` INT(10), IN `_idle_prod_var_name` VARCHAR(45), IN `_idle_prod_selling_price` INT(10), IN `_idle_insrid` INT(10), IN `_idle_insdt` DATETIME, IN `_idle_logrid` INT(10), IN `_idle_logdt` DATETIME, OUT `_prd_spe_prdm_id_out` INT(10), OUT `_prd_spe_pvnm_id_out` INT(10))  BEGIN

insert into product_master values(null,_prdm_name,_prdm_cat_id,_prdm_brand_id,_prdm_unit_id,_prdm_photo_link,_prdm_insrid,_prdm_ldt,_prdm_logrid,_prdm_logdt);
set _prvm_pdrm_id = LAST_INSERT_ID();
set _pssm_prdm_id = LAST_INSERT_ID();

insert into product_variation_name_master values(null,_prvm_pdrm_id,_prvm_product_variation_name,_prvm_tax_code_id,_prvm_low_stock,_prvm_insrid,_prvm_insdt,_prvm_logdt,_prvm_logrid);
set _pssm_pvnm_id = LAST_INSERT_ID();


insert into idle_selling_price values(null,_pssm_pvnm_id,_idle_prod_var_name,_idle_prod_selling_price,_idle_insrid,_idle_insdt,_idle_logrid,_idle_logdt);

insert into product_starting_stock_master values(null,_pssm_prdm_id,_pssm_pvnm_id,_pssm_starting_qty,_pssm_starting_price,_pssm_financial_year,_pssm_insrid,_pssm_insdt,_pssm_logrid,_pssm_logdt);

set _prd_spe_prdm_id_out = _prvm_pdrm_id;
set _prd_spe_pvnm_id_out = _pssm_pvnm_id;


END$$

DROP PROCEDURE IF EXISTS `add_update_product_specification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_product_specification` (IN `_prd_spe_id` INT(11), IN `_prd_spe_prdm_id` INT(11), IN `_prd_spe_pvnm_id` INT(11), IN `_prd_spe_oth_cat_id` INT(11), IN `_prd_spe_oth_cat_val` VARCHAR(45), IN `_prd_spe_insrid` INT(11), IN `_prd_spe_insdt` DATETIME, IN `_prd_spe_logrid` INT(11), IN `_prd_spe_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
	DECLARE _pssm_pvnm_id int;
    
    IF(_prd_spe_id = 0)
    THEN
    insert into product_specification_master values(null,_prd_spe_prdm_id,_prd_spe_pvnm_id,_prd_spe_oth_cat_id,_prd_spe_oth_cat_val,_prd_spe_insrid,_prd_spe_insdt,_prd_spe_logrid,_prd_spe_logdt);
	SET _ret = 2;
    END IF;
    
    IF(_prd_spe_id!=0)
    THEN 
    
    update product_variation_name_master set prvm_product_variation_name=_prvm_product_variation_name,prvm_logdt=_prvm_logdt,prvm_logrid=_prvm_logrid where prvm_pdrm_id=_prd_spe_id;
    set _pssm_pvnm_id = pvnm_id;
    
    update product_starting_stock_master set pssm_starting_qty=_pssm_starting_qty,pssm_starting_price=_pssm_starting_price,pssm_financial_year=_pssm_financial_year,pssm_logrid=_pssm_logrid,pssm_logdt=_pssm_logdt where pssm_pvnm_id=_pssm_pvnm_id;
    
    update product_specification_master set prd_spe_oth_cat_val=_prd_spe_oth_cat_val,prd_spe_logrid=_prd_spe_logrid,prd_spe_logdt=_prd_spe_logdt where prd_spe_id=_prd_spe_id;
    SET _ret = 3;
   END IF;
    
END$$

DROP PROCEDURE IF EXISTS `add_update_service_details`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_service_details` (IN `_sdm_id` INT(11), IN `_sdm_cust_id` INT(12), IN `_sdm_repeat` INT(2), IN `_sdm_comment` MEDIUMTEXT, IN `_sdm_interval_days` INT(11), IN `_sdm_interval_months` INT(11), IN `_sdm_interval_year` INT(11), IN `_sdm_insrid` INT(10), IN `_sdm_insdt` DATETIME, IN `_sdm_logrid` INT(10), IN `_sdm_logdt` DATETIME, IN `_sdtm_id` INT(11), IN `_sdtm_cust_id` INT(12), IN `_sdtm_sdm_id` INT(12), IN `_sdtm_date` DATETIME, IN `_sdtm_insrid` INT(12), IN `_sdtm_insdt` DATETIME, IN `_sdtm_logrid` INT(12), IN `_sdtm_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN


	/*DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;*/

			

              IF(_sdm_id = 0 )
              THEN
					insert into service_details_master values(null,_sdm_cust_id,_sdm_repeat,_sdm_comment,1,_sdm_interval_days,_sdm_interval_months,_sdm_interval_year,_sdm_insrid,_sdm_insdt,_sdm_logrid,_sdm_logdt);
					SET _ret = 2;
                    set _sdtm_sdm_id = LAST_INSERT_ID();
                    insert into service_date_master  values(null,_sdtm_cust_id,_sdtm_sdm_id,0,_sdtm_date,0,_sdtm_insrid,_sdtm_insdt,_sdtm_logrid,_sdtm_logdt);
			   END IF;       
              	
              IF(_sdm_id != 0)
              THEN
					update service_details_master set sdm_cust_id=_sdm_cust_id,sdm_repeat=_sdm_repeat,sdm_comment=_sdm_comment,sdm_interval_days=_sdm_interval_days,sdm_interval_months=_sdm_interval_months,sdm_interval_year=_sdm_interval_year,sdm_insrid=_sdm_insrid,sdm_logrid=_sdm_logrid,sdm_logdt=_sdm_logdt;
					SET _ret = 3;
				END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_supplier`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_supplier` (IN `_sup_id` INT(11), IN `_sup_first_name` VARCHAR(45), IN `_sup_middle_name` VARCHAR(45), IN `_sup_last_name` VARCHAR(45), IN `_sup_business_name` VARCHAR(100), IN `_sup_gst_no` VARCHAR(100), IN `_sup_primary_ctn` VARCHAR(12), IN `_sup_second_ctn` VARCHAR(12), IN `_sup_third_ctn` VARCHAR(12), IN `_sup_email` VARCHAR(100), IN `_sup_address` VARCHAR(150), IN `_sup_city_village` VARCHAR(45), IN `_sup_pincode` VARCHAR(11), IN `_sup_insrid` INT(11), IN `_sup_insdt` DATETIME, IN `_sup_logrid` INT(11), IN `_sup_logdt` DATETIME, OUT `_ret` INT(11))  BEGIN

declare _supval bool;
	SET _ret = 0;
SET _supval = true;
	
    IF EXISTS(SELECT sup_id FROM supplier_master WHERE sup_primary_ctn=_sup_primary_ctn and sup_business_name=_sup_business_name)
		THEN
				SET _ret = 1;
                
                 set _supval = false;
			END IF;
			IF(_supval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_sup_id = 0 )
              THEN
					Insert into supplier_master
					values(null,_sup_first_name,_sup_middle_name,_sup_last_name,_sup_business_name,_sup_gst_no,_sup_primary_ctn,_sup_second_ctn,_sup_third_ctn,_sup_email,_sup_address,_sup_city_village,_sup_pincode,_sup_insrid,_sup_insdt,_sup_logrid,_sup_logdt);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_sup_id != 0)
              THEN
					Update supplier_master set sup_first_name=_sup_first_name,sup_middle_name=_sup_middle_name,sup_last_name=_sup_last_name,sup_business_name=_sup_business_name,sup_gst_no=_sup_gst_no,sup_primary_ctn=_sup_primary_ctn,sup_second_ctn=_sup_second_ctn,sup_third_ctn=_sup_third_ctn,sup_email=_sup_email,sup_address=_sup_address,sup_city_village=_sup_city_village,sup_pincode=_sup_pincode,sup_logrid=_sup_logrid,sup_logdt=_sup_logdt where sup_id=_sup_id;  
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_tax`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_tax` (IN `_txcd_id` INT(11), IN `_txcd_name` VARCHAR(45), IN `_txcd_cgst` FLOAT(20), IN `_txcd_sgst` FLOAT(20), IN `_txcd_igst` FLOAT(20), IN `_txcd_insrid` INT(12), IN `_txcd_insdt` DATETIME, IN `_txcd_logrid` INT(12), IN `_txcd_logdt` DATETIME, OUT `_ret` INT(11))  BEGIN
	declare _txval bool;
/*	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
       
		ROLLBACK;
	END;
    START TRANSACTION;*/
    SET _txval = true;

		IF EXISTS(SELECT txcd_id FROM tax_code_master WHERE txcd_name = _txcd_name and txcd_cgst=_txcd_cgst and  txcd_sgst=_txcd_sgst and txcd_igst=_txcd_igst)
			THEN
				SET _ret = 1;
                
                 set _txval = false;
		END IF;
        
        IF(_txval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_txcd_id = 0 )
              THEN
					Insert into tax_code_master
					values(null,_txcd_name,_txcd_cgst,_txcd_sgst,_txcd_igst,_txcd_insrid,_txcd_insdt,_txcd_logrid,_txcd_logdt);
					SET _ret = 2;
			   END IF; 
               
           IF(_txcd_id != 0)
              THEN
					Update tax_code_master set txcd_name=_txcd_name,txcd_cgst=_txcd_cgst,txcd_sgst=_txcd_sgst,txcd_igst=_txcd_igst,txcd_logrid=_txcd_logrid,txcd_logdt=_txcd_logdt where txcd_id=_txcd_id;
					SET _ret = 3;
				END IF;
		END IF; 

COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_unit`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_unit` (IN `_um_id` INT(11), IN `_um_name` VARCHAR(45), IN `_um_insrid` INT(11), IN `_um_insdt` DATETIME, IN `_um_logrid` INT(11), IN `_um_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
	declare _umval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _umval = true;
			         
			IF EXISTS(SELECT um_id FROM unit_master WHERE um_name = _um_name)
			THEN
				 SET _ret = 1;
                 set _umval = false;
			END IF;
				
                IF(_umval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_um_id = 0 )
              THEN
					Insert into unit_master
					values(null,_um_name,_um_insrid,_um_insdt,_um_logrid,_um_logdt);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_um_id != 0)
              THEN
					Update unit_master set um_name=_um_name,um_insrid=_um_insrid,um_logrid=_um_logrid,um_logdt=_um_logdt where um_id=_um_id;
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_update_voucher`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_voucher` (IN `_vm_id` INT(11), IN `_vm_vnm_id` INT(10), IN `_vm_name` VARCHAR(45), IN `_vm_person_name` VARCHAR(45), IN `_vm_phone_num` VARCHAR(45), IN `_vm_amount` INT(10), IN `_vm_date` DATETIME, IN `_vm_financial_year` VARCHAR(40), IN `_vm_insrid` INT(10), IN `_vm_insdt` DATETIME, IN `_vm_logrid` INT(10), IN `_vm_logdt` DATETIME)  BEGIN

	if(_vm_id=0)
    Then
    insert into voucher_master values(null,_vm_vnm_id,_vm_name,_vm_person_name,_vm_phone_num,_vm_amount,_vm_date,_vm_financial_year,_vm_insrid,_vm_insdt,_vm_logrid,_vm_logdt);
	END IF;
    
	if(_vm_id>0)
    THEN 
    update voucher_master set vm_vnm_id=_vm_vnm_id, vm_name=_vm_name,vm_person_name=_vm_person_name,vm_phone_num=_vm_phone_num,vm_amount=_vm_amount,vm_date=_vm_date,vm_financial_year=_vm_financial_year,vm_logrid=_vm_logrid,vm_logdt=_vm_logdt where vm_id=_vm_id;
    END IF;
 
END$$

DROP PROCEDURE IF EXISTS `add_update_voucher_name_master`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_update_voucher_name_master` (IN `_vm_id` INT(11), IN `_vm_name` VARCHAR(45), IN `_vm_insrid` INT(10), IN `_vm_insdt` DATETIME, IN `_vm_logrid` INT(10), IN `_vm_logdt` DATETIME, OUT `_ret` TINYINT(2))  BEGIN
	declare _vmval bool;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
	BEGIN
		SET _ret = 0;
        
		ROLLBACK;
	END;
    START TRANSACTION;
    SET _vmval = true;
			         
			IF EXISTS(SELECT vm_id FROM voucher_name_master WHERE vm_name = _vm_name)
			THEN
				SET _ret = 1;
                
                 set _vmval = false;
			END IF;
				
                IF(_vmval = false)
                THEN
					SET _ret = 1;
                ELSE
              IF(_vm_id = 0 )
              THEN
					Insert into voucher_name_master
					values(null,_vm_name,_vm_insrid,_vm_insdt,_vm_logrid,_vm_logdt);
					SET _ret = 2;
			   END IF;       
              	
                
              IF(_vm_id != 0)
              THEN
					Update voucher_name_master set vm_name=_vm_name,vm_logrid=_vm_logrid,vm_logdt=_vm_logdt where vm_id=_vm_id;
					SET _ret = 3;
				END IF;
		END IF; 
           
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `admin_user_add_update`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_user_add_update` (IN `_admn_usr_id` INT(11), IN `_admn_usr_first_name` VARCHAR(100), IN `_admn_usr_father_name` VARCHAR(45), IN `_admn_usr_sur_name` VARCHAR(45), IN `_admn_usr_gender` VARCHAR(6), IN `_admn_usr_mobile_no` VARCHAR(12), IN `_admn_usr_email` VARCHAR(50), IN `_admn_usr_password` VARCHAR(45), IN `_admn_usr_role` INT(11), IN `_admn_usr_status` TINYINT(2), IN `_admn_usr_last_login` DATETIME, IN `_admn_usr_last_logout` DATETIME, IN `_admn_usr_insdt` DATETIME, IN `_admn_usr_insrid` INT(11), IN `_admn_usr_logdt` DATETIME, IN `_admn_usr_logrid` INT(11), OUT `_ret` TINYINT(2))  BEGIN
	DECLARE flag bool;
    DECLARE mobile varchar(50);
    DECLARE email varchar(50);
    DECLARE msg text;
   
    SET _ret = 0;
    IF EXISTS (SELECT admn_usr_id from admin_registration_master Where admn_usr_mobile_no = _admn_usr_mobile_no or admn_usr_email = _admn_usr_email)
    THEN

    
			  IF EXISTS (SELECT admn_usr_id from admin_registration_master Where admn_usr_mobile_no = _admn_usr_mobile_no)
              THEN 
				IF(_admn_usr_id > 0)
                THEN
					SET mobile = (SELECT admn_usr_mobile_no FROM admin_registration_master Where admn_usr_id = _admn_usr_id);
                    IF(mobile = _admn_usr_mobile_no)
                    THEN
						SET flag = false;
					ELSE
						SET flag = true;
                        SET msg = "1Mobile";
                        SET _ret = 1;
                    END IF;
				ELSE
					SET flag = true;
					SET _ret = 1;
                    SET msg = "2Mobile";
                END IF;
				
			  ELSE
				IF (_admn_usr_email = "")
				  THEN 
					SET flag = false;
				  ELSE
					 IF EXISTS (SELECT admn_usr_id from admin_registration_master Where admn_usr_email = _admn_usr_email)
					 THEN 
						IF(_admn_usr_id > 0)
						THEN
							SET email = (SELECT admn_usr_email FROM admin_registration_master Where admn_usr_id = _admn_usr_id);
							IF(email = _admn_usr_email)
							THEN
								SET flag = false;
							ELSE
								SET flag = true;
								SET _ret =2;
                                SET msg = "3Email";
							END IF;
						ELSE
							SET flag = true;
							SET _ret = 2;
                            SET msg = "4Email";
						END IF;
						
					 ELSE
						SET flag = false;
                     END IF;
				 END IF;
              END IF;
	ELSE
		
			SET flag = false;
			SET _ret = 3;
		
		
    END IF;

    
    IF(flag = false)
    THEN
		IF(_admn_usr_id > 0)
        THEN
			Update admin_registration_master set admn_usr_first_name=_admn_usr_first_name,admn_usr_father_name=_admn_usr_father_name,admn_usr_sur_name=_admn_usr_sur_name,admn_usr_gender=_admn_usr_gender,admn_usr_mobile_no=_admn_usr_mobile_no,admn_usr_email=_admn_usr_email,admn_usr_password=_admn_usr_password,admn_usr_role=_admn_usr_role,admn_usr_status=_admn_usr_status,admn_usr_last_login=_admn_usr_last_login,admn_usr_last_logout=_admn_usr_last_logout,admn_usr_insrid=_admn_usr_insrid,admn_usr_logdt=_admn_usr_logdt,admn_usr_logrid=_admn_usr_logrid where admn_usr_id=_admn_usr_id;
			
            SET _ret = 5;
        ELSE
        Insert into admin_registration_master values(null,_admn_usr_first_name,_admn_usr_father_name,_admn_usr_sur_name,_admn_usr_gender,_admn_usr_mobile_no,_admn_usr_email,_admn_usr_password,_admn_usr_role,_admn_usr_status,_admn_usr_last_login,_admn_usr_last_logout,_admn_usr_insdt,_admn_usr_insrid,_admn_usr_logdt,_admn_usr_logrid);
			
            SET _ret = 4;
        END IF;
    ELSE
		
        select msg AS '** DEBUG:';
    END IF;
END$$

DROP PROCEDURE IF EXISTS `insert_into_starting_stock_master`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_into_starting_stock_master` (IN `_var` INT(10))  BEGIN

if(_var=1)
then

insert into product_starting_stock_master(pssm_prdm_id,pssm_pvnm_id,pssm_starting_qty,pssm_starting_price,pssm_financial_year,pssm_insrid,pssm_insdt,pssm_logrid,pssm_logdt)
select pssm_prdm_id,pssm_pvnm_id,pssm_starting_qty,pssm_starting_price,"0",pssm_insrid,pssm_insdt,pssm_logrid,pssm_logdt from product_starting_stock_master 
where pssm_financial_year=(select current_financial_year from current_financial_year_master);


else if(_var=2)
then
insert into product_starting_stock_master(pssm_prdm_id,pssm_pvnm_id,pssm_starting_qty,pssm_starting_price,pssm_financial_year,pssm_insrid,pssm_insdt,pssm_logrid,pssm_logdt)
select pssm_prdm_id,pssm_pvnm_id,pssm_starting_qty,pssm_starting_price,"0",pssm_insrid,pssm_insdt,pssm_logrid,pssm_logdt from product_starting_stock_master 
where pssm_insdt > (select current_financial_year_logdt from current_financial_year_master);

end if;
end if;
END$$

DROP PROCEDURE IF EXISTS `system_admin_login`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `system_admin_login` (IN `_admn_usr_mobile_no` VARCHAR(12), IN `_admn_usr_password` VARCHAR(45), OUT `_ret` TINYINT(2), OUT `_user_id` INT(11), OUT `_user_role` TINYINT(2))  BEGIN

	declare _admn_usr_id int(11);
    declare _admn_usr_role int(11);
    
	if exists(select admn_usr_id from admin_registration_master where admn_usr_mobile_no=_admn_usr_mobile_no and admn_usr_password=_admn_usr_password)
	then 
        
			if exists
			(select admn_usr_id from admin_registration_master where admn_usr_mobile_no=_admn_usr_mobile_no and admn_usr_password=_admn_usr_password and admn_usr_status=1)
				then
				set	_admn_usr_id = (select admn_usr_id from admin_registration_master where admn_usr_mobile_no=_admn_usr_mobile_no and admn_usr_password=_admn_usr_password);
                set	_admn_usr_role = (select admn_usr_role from admin_registration_master where admn_usr_id=_admn_usr_id);
				
                update admin_registration_master set admn_usr_last_login=now() where admn_usr_id=_admn_usr_id;
				set _ret=2;
                set _user_id=_admn_usr_id;
                set _user_role = _admn_usr_role;
			else 
			set _ret=1;
            set _user_id=0;
			end if;
    else
    
		set _ret=0;
        set _user_id=0;
    end if;
END$$

DROP PROCEDURE IF EXISTS `update_product`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_product` (IN `_prvm_id` INT(11), IN `_prvm_product_variation_name` VARCHAR(45), IN `_prvm_tax_code_id` INT(10), IN `_prvm_logdt` DATETIME, IN `_prvm_logrid` INT(11), IN `_pssm_pvnm_id` INT(11), IN `_pssm_starting_qty` INT(11), IN `_pssm_starting_price` INT(11), IN `_pssm_financial_year` VARCHAR(15), IN `_pssm_logrid` INT(11), IN `_pssm_logdt` DATETIME)  BEGIN

update product_variation_name_master set prvm_product_variation_name=_prvm_product_variation_name,prvm_tax_code_id=_prvm_tax_code_id,prvm_logdt=_prvm_logdt,prvm_logrid=_prvm_logrid where prvm_id=_prvm_id;
update product_starting_stock_master set pssm_starting_qty=_pssm_starting_qty,pssm_starting_price=_pssm_starting_price,pssm_financial_year=_pssm_financial_year,pssm_logrid=_pssm_logrid,pssm_logdt=_pssm_logdt where pssm_pvnm_id=_prvm_id;
/*update product_specification_master set prd_spe_oth_cat_id=_prd_spe_oth_cat_id,prd_spe_oth_cat_val=_prd_spe_oth_cat_val,prd_spe_logrid=_prd_spe_logrid,prd_spe_logdt=_prd_spe_logdt where prd_spe_pvnm_id;*/

END$$

DROP PROCEDURE IF EXISTS `update_product_average_price`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_product_average_price` (IN `_year` VARCHAR(20))  BEGIN


update product_starting_stock_master as pssm set pssm_starting_price=(
select avg(spbd_product_price) from supplier_purchase_bill_detail  as spbd where spbd.spbd_product_id=pssm.pssm_pvnm_id)
where pssm.pssm_pvnm_id in(select  spbd_product_id from supplier_purchase_bill_detail group by spbd_product_id) and pssm.pssm_financial_year=_year;


update product_starting_stock_master as pssm set pssm_starting_qty=(
select rpvn.current_quentity from report_product_var_name as rpvn where rpvn.pssm_pvnm_id = pssm.pssm_pvnm_id
)
where pssm.pssm_pvnm_id in(select psm.prd_spe_pvnm_id from product_specification_master as psm
left join supplier_purchase_bill_detail as spbd on psm.prd_spe_pvnm_id=spbd.spbd_product_id ) and pssm.pssm_financial_year=_year;


END$$

DROP PROCEDURE IF EXISTS `update_product_variation_price_qty_year`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_product_variation_price_qty_year` (IN `_prvm_id` INT(11), IN `_prvm_pdrm_id` INT(11), IN `_prvm_product_variation_name` VARCHAR(45), IN `_prvm_logdt` DATETIME, IN `_prvm_logrid` INT(11), IN `_pssm_id` INT(11), IN `_pssm_prdm_id` INT(11), IN `_pssm_pvnm_id` INT(11), IN `_pssm_starting_qty` INT(11), IN `_pssm_starting_price` INT(11), IN `_pssm_financial_year` VARCHAR(15), IN `_pssm_logrid` INT(11), IN `_pssm_logdt` DATETIME)  BEGIN

update product_variation_name_master set prvm_product_variation_name=_prvm_product_variation_name,prvm_logdt=_prvm_logdt,prvm_logrid=_prvm_logrid where prvm_id=_prvm_id;
update product_starting_stock_master set pssm_starting_qty=_pssm_starting_qty,pssm_starting_price=_pssm_starting_price,pssm_financial_year=_pssm_financial_year,pssm_logrid=_pssm_logrid,pssm_logdt=_pssm_logdt where pssm_pvnm_id=_prvm_id;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_registration_master`
--

DROP TABLE IF EXISTS `admin_registration_master`;
CREATE TABLE IF NOT EXISTS `admin_registration_master` (
  `admn_usr_id` int(11) NOT NULL AUTO_INCREMENT,
  `admn_usr_first_name` varchar(45) NOT NULL,
  `admn_usr_father_name` varchar(45) NOT NULL,
  `admn_usr_sur_name` varchar(45) NOT NULL,
  `admn_usr_gender` varchar(45) NOT NULL,
  `admn_usr_mobile_no` varchar(12) NOT NULL,
  `admn_usr_email` varchar(45) NOT NULL,
  `admn_usr_password` varchar(45) NOT NULL,
  `admn_usr_role` int(11) NOT NULL,
  `admn_usr_status` tinyint(2) NOT NULL,
  `admn_usr_last_login` datetime NOT NULL,
  `admn_usr_last_logout` datetime NOT NULL,
  `admn_usr_insdt` datetime NOT NULL,
  `admn_usr_insrid` int(11) NOT NULL,
  `admn_usr_logdt` datetime NOT NULL,
  `admn_usr_logrid` int(11) NOT NULL,
  PRIMARY KEY (`admn_usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_registration_master`
--

INSERT INTO `admin_registration_master` (`admn_usr_id`, `admn_usr_first_name`, `admn_usr_father_name`, `admn_usr_sur_name`, `admn_usr_gender`, `admn_usr_mobile_no`, `admn_usr_email`, `admn_usr_password`, `admn_usr_role`, `admn_usr_status`, `admn_usr_last_login`, `admn_usr_last_logout`, `admn_usr_insdt`, `admn_usr_insrid`, `admn_usr_logdt`, `admn_usr_logrid`) VALUES
(8, 'jimish', 's', 'shah', 'Male', '9999999999', 'gp@gmail.com', '1234', 1, 1, '2020-01-20 15:45:26', '2019-09-23 09:44:52', '2019-09-23 09:44:52', 1, '2019-09-23 09:44:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `brand_master`
--

DROP TABLE IF EXISTS `brand_master`;
CREATE TABLE IF NOT EXISTS `brand_master` (
  `bm_rid` int(11) NOT NULL AUTO_INCREMENT,
  `bm_name` varchar(45) NOT NULL,
  `bm_insrid` int(11) NOT NULL,
  `bm_insdt` datetime NOT NULL,
  `bm_logrid` int(11) NOT NULL,
  `bm_logdt` datetime NOT NULL,
  PRIMARY KEY (`bm_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand_master`
--

INSERT INTO `brand_master` (`bm_rid`, `bm_name`, `bm_insrid`, `bm_insdt`, `bm_logrid`, `bm_logdt`) VALUES
(2, 'VIVIDH PLAST', 1, '2019-07-27 17:57:12', 8, '2019-10-15 18:06:55'),
(3, 'LEXCRU', 1, '2019-08-10 18:39:09', 1, '2019-08-10 18:39:09'),
(5, 'NON BRANDED', 1, '2019-07-27 17:50:42', 1, '2019-07-27 17:51:02'),
(6, 'DELL', 8, '2019-10-15 15:59:50', 8, '2019-10-15 15:59:50');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

DROP TABLE IF EXISTS `category_master`;
CREATE TABLE IF NOT EXISTS `category_master` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(45) NOT NULL,
  `cat_insrid` int(11) NOT NULL,
  `cat_insdt` datetime NOT NULL,
  `cat_logrid` int(11) NOT NULL,
  `cat_logdt` datetime NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`cat_id`, `cat_name`, `cat_insrid`, `cat_insdt`, `cat_logrid`, `cat_logdt`) VALUES
(1, 'MISCELANIOUS', 1, '2019-07-27 17:57:00', 1, '2019-07-27 17:57:00'),
(2, 'PUMP HEAD', 1, '2019-08-10 13:38:26', 1, '2019-08-17 11:36:17'),
(3, 'PUMP', 1, '2019-08-10 18:47:49', 1, '2019-08-10 18:47:49'),
(4, 'INLINES', 1, '2019-08-10 18:49:59', 1, '2019-08-10 18:49:59'),
(5, 'GAC', 1, '2019-08-14 10:23:44', 1, '2019-08-14 10:23:44'),
(6, 'POST CARBON', 1, '2019-08-14 10:27:01', 1, '2019-08-14 10:27:01'),
(7, 'MEMBRANE HOUSING', 1, '2019-08-14 10:29:08', 1, '2019-08-14 10:29:08'),
(8, 'PP FILTER', 1, '2019-08-14 10:31:49', 1, '2019-08-14 10:31:49'),
(9, 'FILTER HOUSING', 1, '2019-08-14 10:34:06', 1, '2019-08-14 10:34:06'),
(10, 'CABINETS', 1, '2019-08-14 10:35:57', 1, '2019-08-14 10:35:57'),
(11, 'ASSESORIES', 1, '2019-08-14 10:36:08', 1, '2019-08-14 10:36:08'),
(12, 'TUBING', 1, '2019-08-14 10:36:25', 1, '2019-08-14 10:36:25'),
(13, 'BODY', 1, '2019-08-17 12:05:38', 1, '2019-08-17 12:05:38'),
(14, 'DOMESTIC R.O. PLANT', 1, '2019-08-18 16:34:07', 1, '2019-08-18 16:34:07'),
(15, 'WATER JUG', 1, '2019-08-18 16:38:06', 1, '2019-08-18 16:38:06'),
(16, 'ELBOW / OTHER VALVE', 1, '2019-08-18 16:40:29', 1, '2019-08-18 17:13:01'),
(17, 'COVER', 1, '2019-08-18 16:42:53', 1, '2019-08-18 16:42:53'),
(18, 'GEYSER COMPONENT', 1, '2019-08-18 17:56:49', 1, '2019-08-18 17:56:49'),
(19, 'DOMESTIC GEYSER', 1, '2019-08-18 18:16:52', 1, '2019-08-18 18:16:52'),
(20, 'ELECTRIC STOVE', 1, '2019-08-18 18:23:05', 1, '2019-08-18 18:23:05'),
(21, 'JUMBO FILTER', 1, '2019-08-18 18:24:15', 1, '2019-08-18 18:24:15'),
(22, 'ELECTRICAL ITEMS', 1, '2019-08-18 19:31:45', 1, '2019-08-18 19:31:45'),
(23, 'JUG ACCESSORY', 1, '2019-08-18 20:36:13', 1, '2019-08-18 20:36:13'),
(24, 'PET JAR', 1, '2019-08-18 21:45:38', 1, '2019-08-18 21:45:38'),
(25, 'PET JAR ASSESORIES', 1, '2019-08-18 21:48:27', 1, '2019-08-18 21:48:27'),
(26, 'DISH', 1, '2019-08-27 14:50:31', 1, '2019-08-27 14:50:31'),
(27, 'TEA POWSER', 1, '2019-08-27 14:56:06', 1, '2019-08-27 14:56:06'),
(28, 'COFFEE POWDER', 1, '2019-08-27 14:56:17', 1, '2019-08-27 14:56:17'),
(29, 'MEMBRANE', 3, '2019-08-27 15:39:00', 3, '2019-08-27 15:39:00'),
(30, 'COMMERCIAL R.O. SYSTEM', 1, '2019-08-31 16:42:06', 1, '2019-08-31 16:42:06'),
(31, 'COMMERCIAL PURIFIER', 1, '2019-08-31 16:42:24', 1, '2019-08-31 16:42:24'),
(32, 'PRESSURE TANK', 1, '2019-08-31 16:56:00', 1, '2019-08-31 16:56:00'),
(33, 'WATER SOFTNER', 1, '2019-08-31 17:13:28', 1, '2019-08-31 17:13:28');

-- --------------------------------------------------------

--
-- Table structure for table `current_financial_year_master`
--

DROP TABLE IF EXISTS `current_financial_year_master`;
CREATE TABLE IF NOT EXISTS `current_financial_year_master` (
  `current_financial_year_id` int(11) NOT NULL,
  `current_financial_year` varchar(45) DEFAULT NULL,
  `current_financial_year_insdt` datetime DEFAULT NULL,
  `current_financial_year_rid` int(11) DEFAULT NULL,
  `current_financial_year_logdt` datetime DEFAULT NULL,
  `current_financial_year_logrid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `current_financial_year_master`
--

INSERT INTO `current_financial_year_master` (`current_financial_year_id`, `current_financial_year`, `current_financial_year_insdt`, `current_financial_year_rid`, `current_financial_year_logdt`, `current_financial_year_logrid`) VALUES
(1, '2020 - 2021', NULL, NULL, '2019-11-21 19:52:11', 8);

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

DROP TABLE IF EXISTS `customer_master`;
CREATE TABLE IF NOT EXISTS `customer_master` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_first_name` varchar(45) DEFAULT NULL,
  `cust_middle_name` varchar(45) DEFAULT NULL,
  `cust_last_name` varchar(45) DEFAULT NULL,
  `cust_busines_name` varchar(45) DEFAULT NULL,
  `cust_primary_ctn` varchar(12) DEFAULT NULL,
  `cust_whats_app_ctn` varchar(12) DEFAULT NULL,
  `cust_second_ctn` varchar(12) DEFAULT NULL,
  `cust_third_ctn` varchar(12) DEFAULT NULL,
  `cust_gender` varchar(10) DEFAULT NULL,
  `cust_email` varchar(100) DEFAULT NULL,
  `cust_address` varchar(150) DEFAULT NULL,
  `cust_city_village` varchar(45) DEFAULT NULL,
  `cust_pincode` int(11) DEFAULT NULL,
  `cust_insrid` int(11) DEFAULT NULL,
  `cust_insdt` datetime DEFAULT NULL,
  `cust_logrid` int(11) DEFAULT NULL,
  `cust_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`cust_id`, `cust_first_name`, `cust_middle_name`, `cust_last_name`, `cust_busines_name`, `cust_primary_ctn`, `cust_whats_app_ctn`, `cust_second_ctn`, `cust_third_ctn`, `cust_gender`, `cust_email`, `cust_address`, `cust_city_village`, `cust_pincode`, `cust_insrid`, `cust_insdt`, `cust_logrid`, `cust_logdt`) VALUES
(146, 'akashas', 'v', 'chauhan', 'akash shop', '7777777777', '', '', '', 'Male', 'ak@gmail.com', '', '', 383001, 8, '2019-09-23 11:57:13', 8, '2019-09-28 21:03:10'),
(147, 'jimish', 's', 's', 'jimish shop', '9898989898', '', '', '', 'Male', '', '', '', 383001, 8, '2019-09-23 11:57:33', 8, '2019-09-23 13:25:02'),
(149, 'jimish', 's', 'shah', 'jimish new shop', '9998999999', '', '', '', 'Male', '', '', '', 0, 8, '2019-09-23 12:08:21', 8, '2019-09-23 12:08:21'),
(150, 'jimish', 'jj', 'shah', 'jimish new shop 1', '8888888888', '', '', '', 'Male', '', '', '', 383001, 8, '2019-09-23 12:08:36', 8, '2019-09-23 12:09:14');

-- --------------------------------------------------------

--
-- Table structure for table `financial_year_master`
--

DROP TABLE IF EXISTS `financial_year_master`;
CREATE TABLE IF NOT EXISTS `financial_year_master` (
  `financial_year_id` int(11) NOT NULL AUTO_INCREMENT,
  `financial_year` varchar(45) DEFAULT NULL,
  `financial_year_insdt` datetime DEFAULT NULL,
  `financial_year_rid` int(11) DEFAULT NULL,
  `financial_year_logdt` datetime DEFAULT NULL,
  `financial_year_logrid` int(11) DEFAULT NULL,
  PRIMARY KEY (`financial_year_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COMMENT='					';

--
-- Dumping data for table `financial_year_master`
--

INSERT INTO `financial_year_master` (`financial_year_id`, `financial_year`, `financial_year_insdt`, `financial_year_rid`, `financial_year_logdt`, `financial_year_logrid`) VALUES
(10, '2019 - 2020', '2019-07-21 20:42:25', 0, '2019-07-21 20:42:25', 0),
(11, '2018 - 2019', '2019-07-21 20:47:46', 0, '2019-07-21 20:47:46', 0),
(12, '2020 - 2021', '2019-11-21 19:25:34', 8, '2019-11-21 19:25:34', 8);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_all_product_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_all_product_details`;
CREATE TABLE IF NOT EXISTS `get_all_product_details` (
`prdm_id` int(11)
,`prdm_name` varchar(45)
,`prdm_cat_id` int(11)
,`prdm_brand_id` int(11)
,`prdm_unit_id` mediumtext
,`prdm_photo_link` varchar(100)
,`prdm_insrid` int(11)
,`prdm_ldt` datetime
,`prdm_logrid` int(11)
,`prdm_logdt` datetime
,`um_id` int(11)
,`um_name` varchar(45)
,`um_insrid` int(11)
,`um_insdt` datetime
,`um_logrid` int(11)
,`um_logdt` datetime
,`cat_id` int(11)
,`cat_name` varchar(45)
,`cat_insrid` int(11)
,`cat_insdt` datetime
,`cat_logrid` int(11)
,`cat_logdt` datetime
,`bm_rid` int(11)
,`bm_name` varchar(45)
,`bm_insrid` int(11)
,`bm_insdt` datetime
,`bm_logrid` int(11)
,`bm_logdt` datetime
,`prvm_id` int(11)
,`prvm_pdrm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`prvm_tax_code_id` int(11)
,`prvm_low_stock` int(10)
,`prvm_insrid` int(11)
,`prvm_insdt` datetime
,`prvm_logdt` datetime
,`prvm_logrid` int(11)
,`pssm_id` int(11)
,`pssm_prdm_id` int(11)
,`pssm_pvnm_id` int(11)
,`pssm_starting_qty` bigint(20)
,`pssm_starting_price` int(11)
,`pssm_financial_year` varchar(20)
,`pssm_insrid` int(11)
,`pssm_insdt` datetime
,`pssm_logrid` int(11)
,`pssm_logdt` datetime
,`prd_spe_id` int(11)
,`prd_spe_prdm_id` int(11)
,`prd_spe_pvnm_id` int(11)
,`prd_spe_oth_cat_id` int(11)
,`prd_spe_oth_cat_val` varchar(45)
,`prd_spe_insrid` int(11)
,`prd_spe_insdt` datetime
,`prd_spe_logrid` int(11)
,`prd_spe_logdt` datetime
,`oth_cat_id` int(11)
,`oth_cat_name` varchar(45)
,`oth_cat_is_unit` tinyint(2)
,`oth_cat_unit_id` int(2)
,`oth_cat_insrid` int(10)
,`oth_cat_insdt` datetime
,`oth_cat_logrid` int(10)
,`oth_cat_logdt` datetime
,`txcd_id` int(11)
,`txcd_name` varchar(45)
,`txcd_cgst` float
,`txcd_sgst` float
,`txcd_igst` float
,`txcd_insrid` int(12)
,`txcd_insdt` datetime
,`txcd_logrid` int(12)
,`txcd_logdt` datetime
,`idle_sell_id` int(10)
,`idle_prod_var_id` int(10)
,`idle_prod_var_name` varchar(45)
,`idle_prod_selling_price` int(10)
,`idle_insrid` int(10)
,`idle_insdt` datetime
,`idle_logrid` int(10)
,`idle_logdt` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_bill_detail_for_list_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_bill_detail_for_list_view`;
CREATE TABLE IF NOT EXISTS `get_bill_detail_for_list_view` (
`spb_id` int(11)
,`spb_purchase_bill_id` varchar(45)
,`spb_financial_year` varchar(20)
,`spbd_id` int(11)
,`spbd_product_price` float
,`spbd_quentity` int(10)
,`price_each_product` double
,`spbd_product_id` int(10)
,`spbd_product_actual_price` float
,`spbd_actual_quentity` int(10)
,`spbd_actual_total` float
,`spbd_discount` float
,`spbd_discount_amount` float
,`spb_purchse_date` datetime
,`spb_total_amount` int(20)
,`spb_total_actual_amount` int(20)
,`spb_status` tinyint(10)
,`sup_business_name` varchar(100)
,`sup_id` int(11)
,`sup_primary_ctn` varchar(12)
,`spbd_bill_id` int(11)
,`spbp_amount` int(10)
,`mop_id` int(11)
,`mop_name` varchar(45)
,`txcd_name` varchar(45)
,`txcd_cgst` float
,`txcd_sgst` float
,`txcd_igst` float
,`cust_id` int(11)
,`cust_first_name` varchar(45)
,`cust_middle_name` varchar(45)
,`cust_last_name` varchar(45)
,`cust_primary_ctn` varchar(12)
,`paidamount` decimal(32,0)
,`unpaidamount` decimal(33,0)
,`prvm_product_variation_name` varchar(45)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_customer_search_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_customer_search_details`;
CREATE TABLE IF NOT EXISTS `get_customer_search_details` (
`sbm_id` int(11)
,`customer_id` int(10)
,`sbm_sales_bill_id` varchar(45)
,`sbm_sales_date` datetime
,`sbm_total_amount` float
,`sbm_total_actual_amount` float
,`sbm_status` tinyint(10)
,`sbm_financial_year` varchar(20)
,`mop_id` int(10)
,`sbm_insrid` int(10)
,`sbm_insdt` datetime
,`sbm_logrid` int(10)
,`sbm_logdt` datetime
,`sbd_id` int(11)
,`sbd_bill_id` int(10)
,`sbd_product_id` int(10)
,`sbd_product_price` float
,`sbd_product_actual_price` float
,`sbd_quentity` int(10)
,`sbd_actual_quentity` int(10)
,`sbd_total` float
,`sbd_actual_total` float
,`sbd_discount` float
,`sbd_discount_amount` float
,`sbd_cgst` float
,`sbd_sgst` float
,`sbd_igst` float
,`sbd_insrid` int(10)
,`sbd_insdt` datetime
,`sbd_logrid` int(10)
,`sbd_logdt` datetime
,`sbp_id` int(11)
,`sbp_bill_id` int(10)
,`sbp_mod_of_payment` int(10)
,`sbp_date_of_payment` datetime
,`sbp_amount` int(10)
,`sbp_insrid` int(10)
,`sbp_insdt` datetime
,`sbp_logrid` int(10)
,`sbp_logdt` datetime
,`cust_id` int(11)
,`cust_first_name` varchar(45)
,`cust_middle_name` varchar(45)
,`cust_last_name` varchar(45)
,`cust_gender` varchar(10)
,`cust_city_village` varchar(45)
,`cust_pincode` int(11)
,`cust_address` varchar(150)
,`cust_primary_ctn` varchar(12)
,`cust_whats_app_ctn` varchar(12)
,`cust_second_ctn` varchar(12)
,`cust_third_ctn` varchar(12)
,`cust_insrid` int(11)
,`cust_insdt` datetime
,`cust_logrid` int(11)
,`cust_logdt` datetime
,`cust_email` varchar(100)
,`prvm_id` int(11)
,`prvm_pdrm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`prvm_tax_code_id` int(11)
,`prvm_insrid` int(11)
,`prvm_insdt` datetime
,`prvm_logdt` datetime
,`prvm_logrid` int(11)
,`prdm_id` int(11)
,`prdm_name` varchar(45)
,`prdm_cat_id` int(11)
,`prdm_brand_id` int(11)
,`prdm_unit_id` mediumtext
,`prdm_photo_link` varchar(100)
,`prdm_insrid` int(11)
,`prdm_ldt` datetime
,`prdm_logrid` int(11)
,`prdm_logdt` datetime
,`txcd_id` int(11)
,`txcd_name` varchar(45)
,`txcd_cgst` float
,`txcd_sgst` float
,`txcd_igst` float
,`txcd_insrid` int(12)
,`txcd_insdt` datetime
,`txcd_logrid` int(12)
,`txcd_logdt` datetime
,`mop_name` varchar(45)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_low_stock_alert`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_low_stock_alert`;
CREATE TABLE IF NOT EXISTS `get_low_stock_alert` (
`pssm_pvnm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`current_quentity` decimal(34,0)
,`prvm_low_stock` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_other_cat_unit_name`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_other_cat_unit_name`;
CREATE TABLE IF NOT EXISTS `get_other_cat_unit_name` (
`oth_cat_id` int(11)
,`oth_cat_name` varchar(45)
,`oth_cat_is_unit` tinyint(2)
,`oth_cat_unit_id` int(2)
,`oth_cat_insrid` int(10)
,`oth_cat_insdt` datetime
,`oth_cat_logrid` int(10)
,`oth_cat_logdt` datetime
,`um_id` int(11)
,`um_name` varchar(45)
,`um_insrid` int(11)
,`um_insdt` datetime
,`um_logrid` int(11)
,`um_logdt` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_product_list_bill_payment`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_product_list_bill_payment`;
CREATE TABLE IF NOT EXISTS `get_product_list_bill_payment` (
`spbd_bill_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`spbd_product_price` float
,`spbd_product_actual_price` float
,`spbd_quentity` int(10)
,`spbd_actual_quentity` int(10)
,`spbd_total` float
,`spbd_actual_total` float
,`spbd_igst` float
,`spbd_discount` float
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_product_list_for_filter`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_product_list_for_filter`;
CREATE TABLE IF NOT EXISTS `get_product_list_for_filter` (
`prdm_id` int(11)
,`product_name` varchar(45)
,`total_quentity` decimal(41,0)
,`starting_price` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_product_list_sales_bill_payment`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_product_list_sales_bill_payment`;
CREATE TABLE IF NOT EXISTS `get_product_list_sales_bill_payment` (
`sbd_id` int(11)
,`sbd_bill_id` int(10)
,`sbd_product_id` int(10)
,`sbd_product_price` float
,`sbd_product_actual_price` float
,`sbd_quentity` int(10)
,`sbd_actual_quentity` int(10)
,`sbd_total` float
,`sbd_actual_total` float
,`sbd_discount` float
,`sbd_discount_amount` float
,`sbd_cgst` float
,`sbd_sgst` float
,`sbd_igst` float
,`sbd_insrid` int(10)
,`sbd_insdt` datetime
,`sbd_logrid` int(10)
,`sbd_logdt` datetime
,`prvm_id` int(11)
,`prvm_pdrm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`prvm_tax_code_id` int(11)
,`prvm_low_stock` int(10)
,`prvm_insrid` int(11)
,`prvm_insdt` datetime
,`prvm_logdt` datetime
,`prvm_logrid` int(11)
,`sbm_id` int(11)
,`customer_id` int(10)
,`sbm_sales_bill_id` varchar(45)
,`sbm_sales_date` datetime
,`sbm_total_amount` float
,`sbm_total_actual_amount` float
,`sbm_status` tinyint(10)
,`sbm_financial_year` varchar(20)
,`sbm_mode_of_payment` int(10)
,`sbm_insrid` int(10)
,`sbm_insdt` datetime
,`sbm_logrid` int(10)
,`sbm_logdt` datetime
,`cust_id` int(11)
,`cust_first_name` varchar(45)
,`cust_middle_name` varchar(45)
,`cust_last_name` varchar(45)
,`cust_gender` varchar(10)
,`cust_city_village` varchar(45)
,`cust_pincode` int(11)
,`cust_address` varchar(150)
,`cust_primary_ctn` varchar(12)
,`cust_whats_app_ctn` varchar(12)
,`cust_second_ctn` varchar(12)
,`cust_third_ctn` varchar(12)
,`cust_insrid` int(11)
,`cust_insdt` datetime
,`cust_logrid` int(11)
,`cust_logdt` datetime
,`cust_email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_product_variation_edit_page`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_product_variation_edit_page`;
CREATE TABLE IF NOT EXISTS `get_product_variation_edit_page` (
`prvm_id` int(11)
,`prvm_pdrm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`prvm_tax_code_id` int(11)
,`prvm_insrid` int(11)
,`prvm_insdt` datetime
,`prvm_logdt` datetime
,`prvm_logrid` int(11)
,`pssm_id` int(11)
,`pssm_prdm_id` int(11)
,`pssm_pvnm_id` int(11)
,`pssm_starting_qty` bigint(20)
,`pssm_starting_price` int(11)
,`pssm_financial_year` varchar(20)
,`pssm_insrid` int(11)
,`pssm_insdt` datetime
,`pssm_logrid` int(11)
,`pssm_logdt` datetime
,`prdm_id` int(11)
,`prdm_name` varchar(45)
,`prdm_cat_id` int(11)
,`prdm_brand_id` int(11)
,`prdm_unit_id` mediumtext
,`prdm_photo_link` varchar(100)
,`prdm_insrid` int(11)
,`prdm_ldt` datetime
,`prdm_logrid` int(11)
,`prdm_logdt` datetime
,`prd_spe_id` int(11)
,`prd_spe_prdm_id` int(11)
,`prd_spe_pvnm_id` int(11)
,`prd_spe_oth_cat_id` int(11)
,`prd_spe_oth_cat_val` varchar(45)
,`prd_spe_insrid` int(11)
,`prd_spe_insdt` datetime
,`prd_spe_logrid` int(11)
,`prd_spe_logdt` datetime
,`oth_cat_id` int(11)
,`oth_cat_name` varchar(45)
,`oth_cat_is_unit` tinyint(2)
,`oth_cat_unit_id` int(2)
,`oth_cat_insrid` int(10)
,`oth_cat_insdt` datetime
,`oth_cat_logrid` int(10)
,`oth_cat_logdt` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_reminder`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_reminder`;
CREATE TABLE IF NOT EXISTS `get_reminder` (
`cust_id` int(11)
,`cust_first_name` varchar(45)
,`cust_middle_name` varchar(45)
,`cust_last_name` varchar(45)
,`customer_name` varchar(137)
,`cust_busines_name` varchar(45)
,`cust_gender` varchar(10)
,`cust_city_village` varchar(45)
,`cust_pincode` int(11)
,`cust_address` varchar(150)
,`cust_primary_ctn` varchar(12)
,`cust_whats_app_ctn` varchar(12)
,`cust_second_ctn` varchar(12)
,`cust_third_ctn` varchar(12)
,`cust_insrid` int(11)
,`cust_insdt` datetime
,`cust_logrid` int(11)
,`cust_logdt` datetime
,`cust_email` varchar(100)
,`sdm_id` int(11)
,`sdm_cust_id` int(12)
,`sdm_repeat` int(2)
,`sdm_comment` mediumtext
,`sdm_continuity` tinyint(2)
,`sdm_interval_days` int(11)
,`sdm_interval_months` int(11)
,`sdm_interval_year` int(11)
,`sdm_insrid` int(10)
,`sdm_insdt` datetime
,`sdm_logrid` int(10)
,`sdm_logdt` datetime
,`sdtm_id` int(11)
,`sdtm_cust_id` int(12)
,`sdtm_sdm_id` int(12)
,`sdtm_date` datetime
,`sdtm_service_man_id` int(11)
,`sdtm_status` int(11)
,`sdtm_insrid` int(12)
,`sdtm_insdt` datetime
,`sdtm_logrid` int(12)
,`sdtm_logdt` datetime
,`service_person_name` varchar(137)
,`admn_usr_mobile_no` varchar(12)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_sell_detail_for_list_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_sell_detail_for_list_view`;
CREATE TABLE IF NOT EXISTS `get_sell_detail_for_list_view` (
`sbm_id` int(11)
,`customer_id` int(10)
,`sbm_sales_bill_id` varchar(45)
,`sbm_sales_date` datetime
,`sbm_total_amount` float
,`sbm_total_actual_amount` float
,`sbm_status` tinyint(10)
,`sbm_insrid` int(10)
,`sbm_insdt` datetime
,`sbm_logrid` int(10)
,`sbm_logdt` datetime
,`sbd_id` int(11)
,`sbd_bill_id` int(10)
,`sbd_product_id` int(10)
,`sbd_product_price` float
,`sbd_product_actual_price` float
,`sbd_quentity` int(10)
,`sbd_actual_quentity` int(10)
,`sbd_total` float
,`sbd_actual_total` float
,`sbd_discount` float
,`sbd_discount_amount` float
,`sbd_cgst` float
,`sbd_sgst` float
,`sbd_igst` float
,`sbd_insrid` int(10)
,`sbd_insdt` datetime
,`sbd_logrid` int(10)
,`sbd_logdt` datetime
,`sbp_id` int(11)
,`sbp_bill_id` int(10)
,`sbp_mod_of_payment` int(10)
,`sbp_date_of_payment` datetime
,`sbp_amount` int(10)
,`sbp_insrid` int(10)
,`sbp_insdt` datetime
,`sbp_logrid` int(10)
,`sbp_logdt` datetime
,`cust_id` int(11)
,`cust_first_name` varchar(45)
,`cust_middle_name` varchar(45)
,`cust_last_name` varchar(45)
,`cust_gender` varchar(10)
,`cust_city_village` varchar(45)
,`cust_pincode` int(11)
,`cust_address` varchar(150)
,`cust_primary_ctn` varchar(12)
,`cust_whats_app_ctn` varchar(12)
,`cust_second_ctn` varchar(12)
,`cust_third_ctn` varchar(12)
,`cust_insrid` int(11)
,`cust_insdt` datetime
,`cust_logrid` int(11)
,`cust_logdt` datetime
,`cust_email` varchar(100)
,`prvm_id` int(11)
,`prvm_pdrm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`prvm_tax_code_id` int(11)
,`prvm_insrid` int(11)
,`prvm_insdt` datetime
,`prvm_logdt` datetime
,`prvm_logrid` int(11)
,`prdm_id` int(11)
,`prdm_name` varchar(45)
,`prdm_cat_id` int(11)
,`prdm_brand_id` int(11)
,`prdm_unit_id` mediumtext
,`prdm_photo_link` varchar(100)
,`prdm_insrid` int(11)
,`prdm_ldt` datetime
,`prdm_logrid` int(11)
,`prdm_logdt` datetime
,`txcd_id` int(11)
,`txcd_name` varchar(45)
,`txcd_cgst` float
,`txcd_sgst` float
,`txcd_igst` float
,`txcd_insrid` int(12)
,`txcd_insdt` datetime
,`txcd_logrid` int(12)
,`txcd_logdt` datetime
,`mop_id` int(11)
,`mop_name` varchar(45)
,`paidamount` decimal(32,0)
,`unpaidamount` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_specification_edit_page`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_specification_edit_page`;
CREATE TABLE IF NOT EXISTS `get_specification_edit_page` (
`prdm_id` int(11)
,`prdm_name` varchar(45)
,`prvm_product_variation_name` varchar(45)
,`oth_cat_name` varchar(45)
,`oth_cat_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_supplier_search_details`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_supplier_search_details`;
CREATE TABLE IF NOT EXISTS `get_supplier_search_details` (
`spb_id` int(11)
,`spb_purchase_bill_id` varchar(45)
,`spb_financial_year` varchar(20)
,`mop_id` int(10)
,`spbd_id` int(11)
,`spbd_product_price` float
,`spbd_quentity` int(10)
,`price_each_product` float
,`spbd_product_id` int(10)
,`spbd_product_actual_price` float
,`spbd_actual_quentity` int(10)
,`spbd_actual_total` float
,`spbd_discount` float
,`spbd_discount_amount` float
,`spb_purchse_date` datetime
,`spb_total_amount` int(20)
,`sup_business_name` varchar(100)
,`sup_id` int(11)
,`sup_primary_ctn` varchar(12)
,`spbd_bill_id` int(11)
,`spbd_amount` int(10)
,`mop_name` varchar(45)
,`txcd_name` varchar(45)
,`txcd_cgst` float
,`txcd_sgst` float
,`txcd_igst` float
,`prvm_product_variation_name` varchar(45)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `get_todays_reminder`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `get_todays_reminder`;
CREATE TABLE IF NOT EXISTS `get_todays_reminder` (
`cust_id` int(11)
,`cust_first_name` varchar(45)
,`cust_middle_name` varchar(45)
,`cust_last_name` varchar(45)
,`cust_busines_name` varchar(45)
,`cust_gender` varchar(10)
,`cust_city_village` varchar(45)
,`cust_pincode` int(11)
,`cust_address` varchar(150)
,`cust_primary_ctn` varchar(12)
,`cust_whats_app_ctn` varchar(12)
,`cust_second_ctn` varchar(12)
,`cust_third_ctn` varchar(12)
,`cust_insrid` int(11)
,`cust_insdt` datetime
,`cust_logrid` int(11)
,`cust_logdt` datetime
,`cust_email` varchar(100)
,`sdm_id` int(11)
,`sdm_cust_id` int(12)
,`sdm_repeat` int(2)
,`sdm_interval_days` int(11)
,`sdm_interval_months` int(11)
,`sdm_interval_year` int(11)
,`sdm_insrid` int(10)
,`sdm_insdt` datetime
,`sdm_logrid` int(10)
,`sdm_logdt` datetime
,`sdtm_id` int(11)
,`sdtm_cust_id` int(12)
,`sdtm_date` datetime
,`sdtm_sdm_id` int(12)
,`sdtm_insrid` int(12)
,`sdtm_insdt` datetime
,`sdtm_logrid` int(12)
,`sdtm_logdt` datetime
,`sdtm_service_man_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `idle_selling_price`
--

DROP TABLE IF EXISTS `idle_selling_price`;
CREATE TABLE IF NOT EXISTS `idle_selling_price` (
  `idle_sell_id` int(10) NOT NULL AUTO_INCREMENT,
  `idle_prod_var_id` int(10) DEFAULT NULL,
  `idle_prod_var_name` varchar(45) DEFAULT NULL,
  `idle_prod_selling_price` int(10) DEFAULT NULL,
  `idle_insrid` int(10) DEFAULT NULL,
  `idle_insdt` datetime DEFAULT NULL,
  `idle_logrid` int(10) DEFAULT NULL,
  `idle_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`idle_sell_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `idle_selling_price`
--

INSERT INTO `idle_selling_price` (`idle_sell_id`, `idle_prod_var_id`, `idle_prod_var_name`, `idle_prod_selling_price`, `idle_insrid`, `idle_insdt`, `idle_logrid`, `idle_logdt`) VALUES
(1, 1, 'JIMISH VAR 1', 0, 8, '2019-11-20 11:40:14', 8, '2019-11-20 11:40:14'),
(2, 4, 'JIMISH PRD 2 VAR 1', 0, 8, '2019-11-20 11:46:51', 8, '2019-11-20 11:46:51'),
(3, 7, 'JIMISH PRD 3 VAR 1', 0, 8, '2019-11-20 13:11:03', 8, '2019-11-20 13:11:03'),
(4, 9, 'JIMISH PRD 4 VAR 1', 0, 8, '2019-11-20 13:17:47', 8, '2019-11-20 13:17:47'),
(5, 10, 'JIMISH PRD 5 VAR 1', 0, 8, '2019-11-20 13:18:53', 8, '2019-11-20 13:18:53'),
(6, 11, 'JIMISH PRD 5 VAR 1', 0, 8, '2019-11-20 13:31:35', 8, '2019-11-20 13:31:35'),
(7, 12, 'DASDAS', 0, 8, '2019-11-20 13:34:31', 8, '2019-11-20 13:34:31'),
(8, 13, 'DASDAS', 0, 8, '2019-11-20 13:35:14', 8, '2019-11-20 13:35:14'),
(9, 1, 'JIMISH VAR 1', 0, 8, '2019-11-20 14:24:44', 8, '2019-11-20 14:24:44'),
(10, 2, 'JIMISH PRD 2 VAR 1', 0, 8, '2019-11-20 14:25:07', 8, '2019-11-20 14:25:07'),
(11, 3, 'JIMISH PRD 3 VAR 1', 0, 8, '2019-11-20 14:25:29', 8, '2019-11-20 14:25:29'),
(12, 1, 'JIMISH PRD VAR 1', 0, 8, '2019-11-20 15:45:39', 8, '2019-11-20 15:45:39'),
(13, 4, 'ANOTHER VAR 1', 0, 8, '2019-11-20 15:50:53', 8, '2019-11-20 15:50:53'),
(14, 5, 'JIMISH NEW PRD VAR NEW', 0, 8, '2019-11-20 17:02:27', 8, '2019-11-20 17:02:27'),
(15, 1, 'JIMISH VAR 1', 0, 8, '2019-11-20 17:17:25', 8, '2019-11-20 17:17:25'),
(16, 4, 'NEW JIMISH', 0, 8, '2019-11-20 17:22:21', 8, '2019-11-20 17:22:21'),
(17, 5, 'JIMISH VAR 1', 0, 8, '2019-11-20 17:41:59', 8, '2019-11-20 17:41:59'),
(18, 6, 'NEW DEMO PRD', 0, 8, '2019-11-20 17:45:30', 8, '2019-11-20 17:45:30'),
(19, 1, 'JIMISH VAR 1', 0, 8, '2019-11-21 19:08:11', 8, '2019-11-21 19:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `mode_of_payment`
--

DROP TABLE IF EXISTS `mode_of_payment`;
CREATE TABLE IF NOT EXISTS `mode_of_payment` (
  `mop_id` int(11) NOT NULL AUTO_INCREMENT,
  `mop_name` varchar(45) NOT NULL,
  PRIMARY KEY (`mop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mode_of_payment`
--

INSERT INTO `mode_of_payment` (`mop_id`, `mop_name`) VALUES
(1, 'TOTAL CASH'),
(2, 'PART PAYMENT'),
(3, 'TOTAL CREDIT');

-- --------------------------------------------------------

--
-- Table structure for table `other_category_master`
--

DROP TABLE IF EXISTS `other_category_master`;
CREATE TABLE IF NOT EXISTS `other_category_master` (
  `oth_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `oth_cat_name` varchar(45) NOT NULL,
  `oth_cat_is_unit` tinyint(2) NOT NULL,
  `oth_cat_unit_id` int(2) NOT NULL,
  `oth_cat_insrid` int(10) NOT NULL,
  `oth_cat_insdt` datetime NOT NULL,
  `oth_cat_logrid` int(10) NOT NULL,
  `oth_cat_logdt` datetime NOT NULL,
  PRIMARY KEY (`oth_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other_category_master`
--

INSERT INTO `other_category_master` (`oth_cat_id`, `oth_cat_name`, `oth_cat_is_unit`, `oth_cat_unit_id`, `oth_cat_insrid`, `oth_cat_insdt`, `oth_cat_logrid`, `oth_cat_logdt`) VALUES
(2, 'COLOR', 0, 0, 1, '2019-07-27 17:57:29', 1, '2019-08-03 18:49:59'),
(3, 'STORAGE CAPACITY', 1, 6, 1, '2019-07-27 17:57:54', 1, '2019-07-27 17:57:54'),
(4, 'TYPE', 0, 0, 1, '2019-08-10 13:52:34', 1, '2019-08-10 13:52:34'),
(5, 'GPD', 0, 0, 1, '2019-08-10 18:47:19', 1, '2019-08-10 18:47:19'),
(6, 'SIZE IN INCH', 1, 7, 1, '2019-08-14 10:21:46', 1, '2019-08-14 10:45:05'),
(7, 'DAI SPAN', 0, 0, 1, '2019-08-14 10:32:05', 1, '2019-08-14 10:32:05'),
(8, 'NAME', 0, 0, 1, '2019-08-14 10:36:58', 1, '2019-08-14 10:36:58'),
(9, 'SIZE IN MTR', 1, 8, 1, '2019-08-14 10:45:31', 1, '2019-08-14 10:45:31'),
(10, 'DIAMETER SIZE', 1, 7, 1, '2019-08-14 13:49:16', 1, '2019-08-14 13:49:16'),
(11, 'BRAND', 0, 0, 1, '2019-08-17 11:28:14', 1, '2019-08-17 11:28:14'),
(12, 'VOLTAGE', 1, 9, 1, '2019-08-18 19:36:12', 1, '2019-08-18 19:36:51'),
(13, 'CURRENT', 1, 10, 1, '2019-08-18 19:37:03', 1, '2019-08-18 19:37:03'),
(14, 'LPH', 1, 6, 1, '2019-08-27 13:06:49', 1, '2019-08-27 13:06:49'),
(15, 'PRINTING', 0, 0, 1, '2019-08-27 14:53:21', 1, '2019-08-27 14:53:21'),
(16, 'FLAVOR', 0, 0, 1, '2019-08-27 14:57:44', 1, '2019-08-27 14:57:44'),
(17, 'PACKAGE SIZE IN KG', 0, 0, 1, '2019-08-27 14:58:27', 1, '2019-08-27 14:58:27'),
(18, 'FLOW RESTRICTOR', 0, 0, 1, '2019-08-31 17:00:15', 1, '2019-08-31 17:02:35');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

DROP TABLE IF EXISTS `product_master`;
CREATE TABLE IF NOT EXISTS `product_master` (
  `prdm_id` int(11) NOT NULL AUTO_INCREMENT,
  `prdm_name` varchar(45) NOT NULL,
  `prdm_cat_id` int(11) NOT NULL,
  `prdm_brand_id` int(11) NOT NULL,
  `prdm_unit_id` mediumtext NOT NULL,
  `prdm_photo_link` varchar(100) NOT NULL,
  `prdm_insrid` int(11) NOT NULL,
  `prdm_ldt` datetime NOT NULL,
  `prdm_logrid` int(11) NOT NULL,
  `prdm_logdt` datetime NOT NULL,
  PRIMARY KEY (`prdm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`prdm_id`, `prdm_name`, `prdm_cat_id`, `prdm_brand_id`, `prdm_unit_id`, `prdm_photo_link`, `prdm_insrid`, `prdm_ldt`, `prdm_logrid`, `prdm_logdt`) VALUES
(1, 'DEMO PRD NAME', 1, 1, '1', '~/product_photo/noimage.png', 8, '2019-11-21 19:08:11', 8, '2020-01-18 17:07:17');

-- --------------------------------------------------------

--
-- Table structure for table `product_specification_master`
--

DROP TABLE IF EXISTS `product_specification_master`;
CREATE TABLE IF NOT EXISTS `product_specification_master` (
  `prd_spe_id` int(11) NOT NULL AUTO_INCREMENT,
  `prd_spe_prdm_id` int(11) NOT NULL,
  `prd_spe_pvnm_id` int(11) NOT NULL,
  `prd_spe_oth_cat_id` int(11) NOT NULL,
  `prd_spe_oth_cat_val` varchar(45) NOT NULL,
  `prd_spe_insrid` int(11) NOT NULL,
  `prd_spe_insdt` datetime NOT NULL,
  `prd_spe_logrid` int(11) NOT NULL,
  `prd_spe_logdt` datetime NOT NULL,
  PRIMARY KEY (`prd_spe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_specification_master`
--

INSERT INTO `product_specification_master` (`prd_spe_id`, `prd_spe_prdm_id`, `prd_spe_pvnm_id`, `prd_spe_oth_cat_id`, `prd_spe_oth_cat_val`, `prd_spe_insrid`, `prd_spe_insdt`, `prd_spe_logrid`, `prd_spe_logdt`) VALUES
(1, 1, 1, 2, 'RED', 8, '2019-11-21 19:08:11', 8, '2019-11-21 19:08:11'),
(2, 1, 2, 2, 'blue', 8, '2019-11-21 19:08:27', 8, '2019-11-21 19:08:27'),
(3, 1, 3, 2, 'yellow', 8, '2019-11-21 19:08:39', 8, '2019-11-21 19:08:39');

-- --------------------------------------------------------

--
-- Table structure for table `product_starting_stock_master`
--

DROP TABLE IF EXISTS `product_starting_stock_master`;
CREATE TABLE IF NOT EXISTS `product_starting_stock_master` (
  `pssm_id` int(11) NOT NULL AUTO_INCREMENT,
  `pssm_prdm_id` int(11) NOT NULL,
  `pssm_pvnm_id` int(11) NOT NULL,
  `pssm_starting_qty` bigint(20) NOT NULL,
  `pssm_starting_price` int(11) NOT NULL,
  `pssm_financial_year` varchar(20) NOT NULL,
  `pssm_insrid` int(11) NOT NULL,
  `pssm_insdt` datetime NOT NULL,
  `pssm_logrid` int(11) NOT NULL,
  `pssm_logdt` datetime NOT NULL,
  PRIMARY KEY (`pssm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_starting_stock_master`
--

INSERT INTO `product_starting_stock_master` (`pssm_id`, `pssm_prdm_id`, `pssm_pvnm_id`, `pssm_starting_qty`, `pssm_starting_price`, `pssm_financial_year`, `pssm_insrid`, `pssm_insdt`, `pssm_logrid`, `pssm_logdt`) VALUES
(1, 1, 1, 100, 10, '2018 - 2019', 8, '2019-11-21 19:08:11', 8, '2019-11-21 19:08:11'),
(2, 1, 2, 100, 10, '2018 - 2019', 8, '2019-11-21 19:08:27', 8, '2019-11-21 19:08:27'),
(3, 1, 3, 100, 10, '2018 - 2019', 8, '2019-11-21 19:08:39', 8, '2019-11-21 19:08:39'),
(4, 1, 1, 66, 10, '2019 - 2020', 8, '2019-11-21 19:52:05', 8, '2019-11-21 19:52:05'),
(5, 1, 2, 134, 100, '2019 - 2020', 8, '2019-11-21 19:52:05', 8, '2019-11-21 19:52:05'),
(6, 1, 3, 100, 10, '2019 - 2020', 8, '2019-11-21 19:52:05', 8, '2019-11-21 19:52:05'),
(21, 1, 1, 66, 10, '2020 - 2021', 8, '2019-11-21 19:52:11', 8, '2019-11-21 19:52:11'),
(22, 1, 2, 134, 100, '2020 - 2021', 8, '2019-11-21 19:52:11', 8, '2019-11-21 19:52:11'),
(23, 1, 3, 100, 10, '2020 - 2021', 8, '2019-11-21 19:52:11', 8, '2019-11-21 19:52:11');

-- --------------------------------------------------------

--
-- Table structure for table `product_variation_name_master`
--

DROP TABLE IF EXISTS `product_variation_name_master`;
CREATE TABLE IF NOT EXISTS `product_variation_name_master` (
  `prvm_id` int(11) NOT NULL AUTO_INCREMENT,
  `prvm_pdrm_id` int(11) NOT NULL,
  `prvm_product_variation_name` varchar(45) NOT NULL,
  `prvm_tax_code_id` int(11) NOT NULL,
  `prvm_low_stock` int(10) DEFAULT '0',
  `prvm_insrid` int(11) NOT NULL,
  `prvm_insdt` datetime NOT NULL,
  `prvm_logdt` datetime NOT NULL,
  `prvm_logrid` int(11) NOT NULL,
  PRIMARY KEY (`prvm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_variation_name_master`
--

INSERT INTO `product_variation_name_master` (`prvm_id`, `prvm_pdrm_id`, `prvm_product_variation_name`, `prvm_tax_code_id`, `prvm_low_stock`, `prvm_insrid`, `prvm_insdt`, `prvm_logdt`, `prvm_logrid`) VALUES
(1, 1, 'JIMISH VAR 1', 0, 10, 8, '2019-11-21 19:08:11', '2019-11-21 19:08:11', 8),
(2, 1, 'JIMISH PRD VAR 2', 0, 10, 8, '2019-11-21 19:08:27', '2019-11-21 19:08:27', 8),
(3, 1, 'JIMISH PRD  VAR 3', 0, 10, 8, '2019-11-21 19:08:39', '2019-11-21 19:08:39', 8);

-- --------------------------------------------------------

--
-- Stand-in structure for view `report_product_name`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `report_product_name`;
CREATE TABLE IF NOT EXISTS `report_product_name` (
`prdm_id` int(11)
,`prdm_name` varchar(45)
,`pssm_starting_qty` bigint(20)
,`purchased_quentity` decimal(32,0)
,`sell_quantity` decimal(32,0)
,`total_out_standing_quantity` decimal(34,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `report_product_var_name`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `report_product_var_name`;
CREATE TABLE IF NOT EXISTS `report_product_var_name` (
`pssm_pvnm_id` int(11)
,`prvm_product_variation_name` varchar(45)
,`pssm_starting_qty` bigint(20)
,`purchased_quentity` decimal(32,0)
,`sold_quentity` bigint(11)
,`current_quentity` decimal(34,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `report_voucher`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `report_voucher`;
CREATE TABLE IF NOT EXISTS `report_voucher` (
`vm_vnm_id` int(10)
,`voucher_type` varchar(45)
,`total_voucher` bigint(21)
,`total_voucher_amount` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `sales_bill_detail`
--

DROP TABLE IF EXISTS `sales_bill_detail`;
CREATE TABLE IF NOT EXISTS `sales_bill_detail` (
  `sbd_id` int(11) NOT NULL AUTO_INCREMENT,
  `sbd_bill_id` int(10) DEFAULT NULL,
  `sbd_product_id` int(10) DEFAULT NULL,
  `sbd_product_price` float DEFAULT NULL,
  `sbd_product_actual_price` float DEFAULT NULL,
  `sbd_quentity` int(10) DEFAULT NULL,
  `sbd_actual_quentity` int(10) DEFAULT NULL,
  `sbd_total` float DEFAULT NULL,
  `sbd_actual_total` float DEFAULT NULL,
  `sbd_discount` float DEFAULT NULL,
  `sbd_discount_amount` float DEFAULT NULL,
  `sbd_cgst` float DEFAULT NULL,
  `sbd_sgst` float DEFAULT NULL,
  `sbd_igst` float DEFAULT NULL,
  `sbd_insrid` int(10) DEFAULT NULL,
  `sbd_insdt` datetime DEFAULT NULL,
  `sbd_logrid` int(10) DEFAULT NULL,
  `sbd_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`sbd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_bill_detail`
--

INSERT INTO `sales_bill_detail` (`sbd_id`, `sbd_bill_id`, `sbd_product_id`, `sbd_product_price`, `sbd_product_actual_price`, `sbd_quentity`, `sbd_actual_quentity`, `sbd_total`, `sbd_actual_total`, `sbd_discount`, `sbd_discount_amount`, `sbd_cgst`, `sbd_sgst`, `sbd_igst`, `sbd_insrid`, `sbd_insdt`, `sbd_logrid`, `sbd_logdt`) VALUES
(1, 1, 1, 10, 10, 33, 34, 330, 340, 0, 0, 0, 0, 0, 8, '2019-11-21 19:09:07', 8, '2019-11-21 19:09:07'),
(2, 2, 1, 100, 100, 12, 12, 1200, 1200, 0, 0, 0, 0, 0, 8, '2020-01-18 17:21:45', 8, '2020-01-18 17:29:35'),
(3, 2, 2, 200, 200, 24, 24, 4800, 4800, 0, 0, 0, 0, 0, 8, '2020-01-18 17:29:35', 8, '2020-01-18 17:29:35');

-- --------------------------------------------------------

--
-- Table structure for table `sales_bill_master`
--

DROP TABLE IF EXISTS `sales_bill_master`;
CREATE TABLE IF NOT EXISTS `sales_bill_master` (
  `sbm_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `sbm_sales_bill_id` varchar(45) DEFAULT NULL,
  `sbm_sales_date` datetime DEFAULT NULL,
  `sbm_total_amount` float DEFAULT NULL,
  `sbm_total_actual_amount` float DEFAULT NULL,
  `sbm_status` tinyint(10) DEFAULT NULL,
  `sbm_financial_year` varchar(20) DEFAULT NULL,
  `sbm_mode_of_payment` int(10) DEFAULT NULL,
  `sbm_insrid` int(10) DEFAULT NULL,
  `sbm_insdt` datetime DEFAULT NULL,
  `sbm_logrid` int(10) DEFAULT NULL,
  `sbm_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`sbm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_bill_master`
--

INSERT INTO `sales_bill_master` (`sbm_id`, `customer_id`, `sbm_sales_bill_id`, `sbm_sales_date`, `sbm_total_amount`, `sbm_total_actual_amount`, `sbm_status`, `sbm_financial_year`, `sbm_mode_of_payment`, `sbm_insrid`, `sbm_insdt`, `sbm_logrid`, `sbm_logdt`) VALUES
(1, 147, 'JIMISH', '2019-11-21 00:00:00', 330, 340, 1, '2018 - 2019', 2, 8, '2019-11-21 19:09:07', 8, '2019-11-21 19:09:07'),
(2, 149, 'DEMO BILL', '2020-01-18 00:00:00', 6000, 6000, 1, '2020 - 2021', 1, 8, '2020-01-18 17:21:45', 8, '2020-01-18 17:29:35');

-- --------------------------------------------------------

--
-- Table structure for table `sales_bill_payment`
--

DROP TABLE IF EXISTS `sales_bill_payment`;
CREATE TABLE IF NOT EXISTS `sales_bill_payment` (
  `sbp_id` int(11) NOT NULL AUTO_INCREMENT,
  `sbp_bill_id` int(10) DEFAULT NULL,
  `sbp_mod_of_payment` int(10) DEFAULT NULL,
  `sbp_date_of_payment` datetime DEFAULT NULL,
  `sbp_amount` int(10) DEFAULT NULL,
  `sbp_insrid` int(10) DEFAULT NULL,
  `sbp_insdt` datetime DEFAULT NULL,
  `sbp_logrid` int(10) DEFAULT NULL,
  `sbp_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`sbp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_bill_payment`
--

INSERT INTO `sales_bill_payment` (`sbp_id`, `sbp_bill_id`, `sbp_mod_of_payment`, `sbp_date_of_payment`, `sbp_amount`, `sbp_insrid`, `sbp_insdt`, `sbp_logrid`, `sbp_logdt`) VALUES
(1, 1, 2, '2019-11-21 00:00:00', 150, 8, '2019-11-21 19:09:07', 8, '2019-11-21 19:09:07'),
(2, 2, 1, '2020-01-18 00:00:00', 1200, 8, '2020-01-18 17:21:45', 8, '2020-01-18 17:21:45'),
(3, 2, 2, '2020-01-18 00:00:00', 800, 8, '2020-01-18 17:30:59', 8, '2020-01-18 17:30:59');

-- --------------------------------------------------------

--
-- Table structure for table `service_date_master`
--

DROP TABLE IF EXISTS `service_date_master`;
CREATE TABLE IF NOT EXISTS `service_date_master` (
  `sdtm_id` int(11) NOT NULL AUTO_INCREMENT,
  `sdtm_cust_id` int(12) NOT NULL,
  `sdtm_sdm_id` int(12) NOT NULL,
  `sdtm_service_man_id` int(11) NOT NULL,
  `sdtm_date` datetime NOT NULL,
  `sdtm_status` int(11) DEFAULT NULL,
  `sdtm_insrid` int(12) NOT NULL,
  `sdtm_insdt` datetime NOT NULL,
  `sdtm_logrid` int(12) NOT NULL,
  `sdtm_logdt` datetime NOT NULL,
  PRIMARY KEY (`sdtm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_date_master`
--

INSERT INTO `service_date_master` (`sdtm_id`, `sdtm_cust_id`, `sdtm_sdm_id`, `sdtm_service_man_id`, `sdtm_date`, `sdtm_status`, `sdtm_insrid`, `sdtm_insdt`, `sdtm_logrid`, `sdtm_logdt`) VALUES
(20, 16, 29, 6, '2019-07-10 00:00:00', 2, 3, '2019-07-12 18:18:00', 3, '2019-08-21 16:48:51'),
(21, 15, 30, 6, '2019-07-13 00:00:00', 2, 3, '2019-07-12 18:18:00', 1, '2019-08-04 20:22:55'),
(24, 19, 34, 0, '2019-10-06 00:00:00', 0, 3, '2019-07-12 18:18:00', 3, '2019-07-12 18:18:00'),
(25, 20, 35, 0, '2019-10-03 00:00:00', 0, 3, '2019-07-13 15:14:16', 3, '2019-07-13 15:14:16'),
(26, 21, 36, 6, '2019-09-05 00:00:00', 2, 3, '2019-07-13 15:18:54', 1, '2019-08-14 11:27:05'),
(27, 22, 37, 6, '2019-07-02 00:00:00', 2, 3, '2019-07-13 15:24:14', 1, '2019-08-12 15:50:06'),
(28, 23, 38, 6, '2019-01-29 00:00:00', 2, 3, '2019-07-13 15:29:40', 1, '2019-08-12 15:52:28'),
(29, 24, 39, 6, '2019-03-28 00:00:00', 2, 3, '2019-07-13 15:33:04', 1, '2019-08-12 18:23:23'),
(30, 25, 40, 6, '2019-08-08 00:00:00', 2, 3, '2019-07-13 15:36:10', 3, '2019-08-20 22:26:43'),
(31, 26, 41, 6, '2018-10-19 00:00:00', 2, 3, '2019-07-13 15:38:27', 1, '2019-08-14 11:26:04'),
(32, 27, 42, 6, '2019-02-01 00:00:00', 2, 3, '2019-07-13 15:41:15', 1, '2019-08-12 18:10:56'),
(33, 28, 43, 0, '2019-08-17 00:00:00', 0, 3, '2019-07-13 15:43:45', 3, '2019-07-13 15:43:45'),
(35, 31, 45, 6, '2019-06-25 00:00:00', 2, 3, '2019-07-13 16:20:31', 1, '2019-08-12 15:50:18'),
(36, 33, 47, 6, '2018-11-28 00:00:00', 2, 3, '2019-07-13 16:26:50', 1, '2019-08-12 15:54:45'),
(37, 34, 48, 6, '2019-09-01 00:00:00', 1, 3, '2019-07-13 16:29:47', 1, '2019-09-21 15:32:23'),
(38, 35, 49, 6, '2018-12-12 00:00:00', 2, 3, '2019-07-13 16:32:27', 1, '2019-08-12 15:48:05'),
(39, 36, 50, 0, '2019-08-28 00:00:00', 0, 3, '2019-07-13 16:42:26', 3, '2019-07-13 16:42:26'),
(40, 37, 51, 0, '2019-08-28 00:00:00', 0, 3, '2019-07-13 16:45:22', 3, '2019-07-13 16:45:22'),
(41, 38, 52, 6, '2019-01-29 00:00:00', 2, 3, '2019-07-13 16:49:39', 1, '2019-08-14 11:07:06'),
(42, 39, 53, 6, '2019-07-30 00:00:00', 2, 3, '2019-07-13 16:52:45', 1, '2019-09-21 15:31:50'),
(43, 40, 54, 6, '2019-04-01 00:00:00', 2, 3, '2019-07-13 16:55:53', 1, '2019-08-12 18:18:59'),
(44, 41, 55, 6, '2019-04-22 00:00:00', 2, 3, '2019-07-13 16:58:51', 1, '2019-08-14 11:27:19'),
(49, 42, 60, 6, '2019-02-14 00:00:00', 2, 3, '2019-07-13 17:03:27', 1, '2019-08-12 18:16:00'),
(50, 43, 61, 6, '2018-10-16 00:00:00', 2, 3, '2019-07-13 17:09:41', 1, '2019-08-12 15:29:11'),
(53, 44, 64, 6, '2018-07-08 00:00:00', 2, 3, '2019-07-13 17:15:39', 1, '2019-08-14 11:24:55'),
(54, 45, 65, 6, '2019-06-01 00:00:00', 2, 3, '2019-07-13 17:19:25', 1, '2019-08-12 15:51:41'),
(55, 46, 66, 6, '2017-07-27 00:00:00', 2, 3, '2019-07-15 17:15:57', 1, '2019-08-14 11:19:24'),
(57, 47, 69, 6, '2019-04-14 00:00:00', 2, 3, '2019-07-17 15:33:01', 3, '2019-07-17 15:33:01'),
(58, 48, 70, 6, '2019-04-14 00:00:00', 2, 3, '2019-07-17 15:37:55', 3, '2019-07-17 15:37:55'),
(59, 49, 71, 6, '2019-06-14 00:00:00', 2, 3, '2019-07-17 15:43:45', 3, '2019-07-17 15:43:45'),
(60, 50, 72, 6, '2019-06-09 00:00:00', 2, 3, '2019-07-17 15:47:38', 3, '2019-07-17 15:47:38'),
(61, 52, 73, 6, '2019-05-08 00:00:00', 2, 3, '2019-07-17 15:50:44', 3, '2019-07-17 15:50:44'),
(62, 51, 74, 6, '2019-04-27 00:00:00', 2, 3, '2019-07-17 15:51:43', 3, '2019-07-17 15:51:43'),
(63, 53, 75, 6, '2017-04-29 00:00:00', 2, 3, '2019-07-17 16:03:09', 3, '2019-07-17 16:03:09'),
(64, 54, 76, 6, '2017-03-02 00:00:00', 2, 3, '2019-07-17 16:06:40', 3, '2019-07-17 16:06:40'),
(65, 55, 77, 6, '2017-11-19 00:00:00', 2, 3, '2019-07-17 16:10:25', 3, '2019-07-17 16:10:25'),
(66, 56, 78, 6, '2017-05-19 00:00:00', 2, 3, '2019-07-17 16:13:58', 3, '2019-07-17 16:13:58'),
(67, 57, 79, 6, '2017-05-21 00:00:00', 2, 3, '2019-07-17 16:24:04', 3, '2019-07-17 16:24:04'),
(68, 58, 80, 6, '2019-03-16 00:00:00', 2, 3, '2019-07-17 16:26:39', 3, '2019-07-17 16:26:39'),
(69, 59, 81, 6, '2019-04-03 00:00:00', 2, 3, '2019-07-17 16:29:21', 3, '2019-07-17 16:29:21'),
(70, 60, 82, 6, '2019-04-09 00:00:00', 2, 3, '2019-07-17 16:32:56', 3, '2019-07-17 16:32:56'),
(71, 61, 83, 6, '2017-07-01 00:00:00', 2, 3, '2019-07-19 17:40:52', 3, '2019-07-19 17:40:52'),
(72, 62, 84, 6, '2017-06-29 00:00:00', 2, 3, '2019-07-19 17:51:10', 3, '2019-07-19 17:51:10'),
(73, 63, 85, 6, '2017-06-06 00:00:00', 2, 3, '2019-07-19 17:54:01', 3, '2019-07-19 17:54:01'),
(74, 64, 86, 6, '2017-05-30 00:00:00', 2, 3, '2019-07-19 17:57:44', 3, '2019-07-19 17:57:44'),
(75, 65, 87, 6, '2016-05-29 00:00:00', 2, 3, '2019-07-19 17:59:32', 3, '2019-07-19 17:59:32'),
(76, 66, 88, 6, '2017-08-10 00:00:00', 2, 3, '2019-07-19 18:01:42', 3, '2019-07-19 18:01:42'),
(77, 67, 89, 6, '2017-11-08 00:00:00', 2, 3, '2019-07-19 18:04:09', 3, '2019-07-19 18:04:09'),
(78, 68, 90, 6, '2017-05-15 00:00:00', 2, 3, '2019-07-19 18:06:17', 3, '2019-07-19 18:06:17'),
(80, 69, 92, 6, '2019-05-17 00:00:00', 2, 3, '2019-07-19 18:09:41', 3, '2019-07-19 18:09:41'),
(81, 70, 93, 6, '2019-05-11 00:00:00', 2, 3, '2019-07-19 18:12:10', 3, '2019-07-19 18:12:10'),
(82, 71, 94, 6, '2019-05-08 00:00:00', 2, 3, '2019-07-19 18:15:14', 3, '2019-07-19 18:15:14'),
(83, 72, 95, 6, '2018-04-25 00:00:00', 2, 3, '2019-07-19 18:18:15', 3, '2019-07-19 18:18:15'),
(84, 73, 96, 6, '2017-09-03 00:00:00', 2, 3, '2019-07-19 18:21:50', 3, '2019-07-19 18:21:50'),
(85, 74, 97, 6, '2017-08-27 00:00:00', 2, 3, '2019-07-19 18:24:14', 3, '2019-07-19 18:24:14'),
(86, 75, 98, 6, '2017-07-27 00:00:00', 2, 3, '2019-07-19 18:26:20', 3, '2019-07-19 18:26:20'),
(87, 76, 99, 6, '2017-08-20 00:00:00', 2, 3, '2019-07-19 18:28:19', 3, '2019-07-19 18:28:19'),
(88, 77, 100, 6, '2017-08-20 00:00:00', 2, 3, '2019-07-19 18:30:23', 3, '2019-07-19 18:30:23'),
(89, 78, 101, 6, '2017-07-20 00:00:00', 2, 3, '2019-07-19 18:32:58', 3, '2019-07-19 18:32:58'),
(90, 79, 102, 6, '2018-01-16 00:00:00', 2, 3, '2019-07-19 18:34:40', 3, '2019-07-19 18:34:40'),
(91, 80, 103, 6, '2019-05-05 00:00:00', 2, 3, '2019-07-19 18:36:34', 3, '2019-07-19 18:36:34'),
(92, 81, 104, 6, '2019-02-28 00:00:00', 2, 3, '2019-07-19 18:39:07', 3, '2019-07-19 18:39:07'),
(93, 82, 105, 6, '2019-03-12 00:00:00', 2, 3, '2019-07-19 18:40:43', 3, '2019-07-19 18:40:43'),
(94, 29, 106, 6, '2019-04-01 00:00:00', 2, 3, '2019-07-19 18:44:20', 1, '2019-08-12 17:33:20'),
(95, 83, 107, 6, '2016-12-03 00:00:00', 2, 3, '2019-07-19 18:46:50', 3, '2019-07-19 18:46:50'),
(96, 84, 108, 6, '2017-12-21 00:00:00', 2, 3, '2019-07-19 18:48:41', 3, '2019-07-19 18:48:41'),
(97, 85, 109, 6, '2017-11-09 00:00:00', 2, 3, '2019-07-19 18:50:56', 3, '2019-07-19 18:50:56'),
(98, 86, 110, 6, '2018-05-27 00:00:00', 2, 3, '2019-07-19 18:53:06', 3, '2019-07-19 18:53:06'),
(99, 87, 111, 6, '2018-05-02 00:00:00', 2, 3, '2019-07-19 18:55:12', 3, '2019-07-19 18:55:12'),
(100, 88, 112, 6, '2017-05-03 00:00:00', 2, 3, '2019-07-19 18:58:30', 3, '2019-07-19 18:58:30'),
(102, 89, 114, 6, '2018-04-21 00:00:00', 2, 3, '2019-07-20 13:00:10', 3, '2019-07-20 13:00:10'),
(103, 90, 115, 6, '2017-05-03 00:00:00', 2, 3, '2019-07-20 13:02:17', 3, '2019-07-20 13:02:17'),
(104, 91, 116, 6, '2018-03-31 00:00:00', 2, 3, '2019-07-20 13:06:25', 3, '2019-07-20 13:06:25'),
(105, 92, 117, 6, '2018-03-31 00:00:00', 2, 3, '2019-07-20 13:08:09', 3, '2019-07-20 13:08:09'),
(106, 93, 118, 6, '2018-03-23 00:00:00', 2, 3, '2019-07-20 13:10:22', 3, '2019-07-20 13:10:22'),
(107, 94, 119, 6, '2018-02-21 00:00:00', 2, 3, '2019-07-20 13:12:32', 3, '2019-07-20 13:12:32'),
(108, 95, 120, 6, '2018-03-14 00:00:00', 2, 3, '2019-07-20 13:14:10', 3, '2019-07-20 13:14:10'),
(109, 96, 121, 6, '2018-02-28 00:00:00', 2, 3, '2019-07-20 13:18:06', 3, '2019-07-20 13:18:06'),
(110, 97, 122, 6, '2018-03-11 00:00:00', 2, 3, '2019-07-20 13:19:57', 3, '2019-07-20 13:19:57'),
(111, 98, 123, 6, '2017-10-18 00:00:00', 2, 3, '2019-07-20 13:22:26', 3, '2019-07-20 13:22:26'),
(112, 99, 124, 6, '2018-02-14 00:00:00', 2, 3, '2019-07-20 13:24:45', 3, '2019-07-20 13:24:45'),
(113, 100, 125, 6, '2018-02-22 00:00:00', 2, 3, '2019-07-20 13:29:58', 3, '2019-07-20 13:29:58'),
(114, 101, 126, 6, '2017-02-13 00:00:00', 2, 3, '2019-07-20 13:37:08', 3, '2019-07-20 13:37:08'),
(115, 102, 127, 6, '2016-02-08 00:00:00', 2, 3, '2019-07-20 13:39:48', 3, '2019-07-20 13:39:48'),
(116, 103, 128, 6, '2018-02-08 00:00:00', 2, 3, '2019-07-20 13:43:09', 3, '2019-07-20 13:43:09'),
(117, 104, 129, 6, '2018-02-01 00:00:00', 2, 3, '2019-07-20 13:46:27', 3, '2019-07-20 13:46:27'),
(118, 105, 130, 6, '2018-01-27 00:00:00', 2, 3, '2019-07-20 13:48:40', 3, '2019-07-20 13:48:40'),
(119, 106, 131, 6, '2018-01-09 00:00:00', 2, 3, '2019-07-20 13:50:42', 3, '2019-07-20 13:50:42'),
(120, 107, 132, 6, '2018-01-13 00:00:00', 2, 3, '2019-07-20 13:53:12', 3, '2019-07-20 13:53:12'),
(121, 108, 133, 6, '2018-10-17 00:00:00', 2, 3, '2019-07-20 13:57:27', 3, '2019-07-20 13:57:27'),
(123, 109, 135, 6, '2018-07-08 00:00:00', 2, 3, '2019-07-20 14:12:24', 3, '2019-07-20 14:12:24'),
(124, 110, 136, 6, '2017-07-08 00:00:00', 2, 3, '2019-07-20 14:15:23', 3, '2019-07-20 14:15:23'),
(125, 111, 137, 6, '2017-06-12 00:00:00', 2, 3, '2019-07-20 14:17:23', 3, '2019-07-20 14:17:23'),
(126, 112, 138, 6, '2018-06-28 00:00:00', 2, 3, '2019-07-20 14:19:55', 3, '2019-07-20 14:19:55'),
(127, 113, 139, 6, '2017-07-05 00:00:00', 2, 3, '2019-07-20 14:23:23', 3, '2019-07-20 14:23:23'),
(128, 114, 140, 6, '2015-10-10 00:00:00', 2, 3, '2019-07-22 16:51:17', 3, '2019-07-22 16:51:17'),
(129, 115, 141, 6, '2017-04-25 00:00:00', 2, 3, '2019-07-22 16:54:43', 3, '2019-07-22 16:54:43'),
(130, 116, 142, 6, '2016-05-06 00:00:00', 2, 3, '2019-07-22 17:12:50', 3, '2019-07-22 17:12:50'),
(131, 117, 143, 6, '2017-09-23 00:00:00', 2, 3, '2019-07-22 17:19:58', 3, '2019-07-22 17:19:58'),
(132, 118, 145, 6, '2018-08-29 00:00:00', 2, 3, '2019-07-22 17:25:59', 3, '2019-07-22 17:25:59'),
(133, 119, 146, 6, '2018-06-05 00:00:00', 2, 3, '2019-07-22 17:29:04', 3, '2019-07-22 17:29:04'),
(134, 120, 147, 6, '2018-06-29 00:00:00', 2, 3, '2019-07-22 17:32:42', 3, '2019-07-22 17:32:42'),
(135, 121, 148, 6, '2018-02-11 00:00:00', 2, 3, '2019-07-22 17:35:53', 3, '2019-07-22 17:35:53'),
(136, 122, 149, 6, '2018-05-07 00:00:00', 2, 3, '2019-07-22 17:38:42', 3, '2019-07-22 17:38:42'),
(137, 123, 150, 6, '2017-12-27 00:00:00', 2, 3, '2019-07-22 17:40:19', 3, '2019-07-22 17:40:19'),
(138, 124, 151, 6, '2016-08-12 00:00:00', 2, 3, '2019-07-22 17:43:36', 3, '2019-07-22 17:43:36'),
(139, 125, 152, 6, '2019-06-04 00:00:00', 2, 3, '2019-07-22 17:46:27', 3, '2019-07-22 17:46:27'),
(140, 126, 153, 6, '2017-09-12 00:00:00', 2, 3, '2019-07-22 17:48:01', 3, '2019-07-22 17:48:01'),
(141, 127, 154, 6, '2019-04-07 00:00:00', 2, 3, '2019-07-22 17:51:46', 3, '2019-07-22 17:51:46'),
(142, 128, 155, 6, '2018-06-02 00:00:00', 2, 3, '2019-07-22 17:58:05', 3, '2019-07-22 17:58:05'),
(143, 129, 156, 6, '2018-08-14 00:00:00', 2, 3, '2019-07-27 12:46:51', 3, '2019-07-27 12:46:51'),
(144, 130, 157, 6, '2018-08-01 00:00:00', 2, 3, '2019-07-27 12:51:02', 3, '2019-07-27 12:51:02'),
(145, 131, 158, 6, '2018-12-31 00:00:00', 2, 3, '2019-07-27 12:58:54', 3, '2019-07-27 12:58:54'),
(146, 132, 159, 6, '2018-11-16 00:00:00', 2, 3, '2019-07-27 13:01:03', 3, '2019-07-27 13:01:03'),
(147, 133, 160, 6, '2018-10-27 00:00:00', 2, 3, '2019-07-27 13:03:45', 3, '2019-07-27 13:03:45'),
(148, 134, 161, 6, '2014-06-26 00:00:00', 2, 3, '2019-07-27 13:05:31', 3, '2019-07-27 13:05:31'),
(149, 135, 162, 6, '2016-03-17 00:00:00', 2, 3, '2019-07-27 13:10:28', 3, '2019-07-27 13:10:28'),
(150, 136, 163, 6, '2016-12-21 00:00:00', 2, 3, '2019-07-27 13:24:41', 3, '2019-07-27 13:24:41'),
(151, 137, 164, 6, '2016-12-26 00:00:00', 2, 3, '2019-07-27 13:27:26', 3, '2019-07-27 13:27:26'),
(152, 138, 165, 6, '2016-01-05 00:00:00', 2, 3, '2019-07-27 13:30:19', 3, '2019-07-27 13:30:19'),
(153, 139, 166, 6, '2016-05-03 00:00:00', 2, 3, '2019-07-27 13:36:31', 3, '2019-07-27 13:36:31'),
(155, 43, 61, 6, '2019-01-16 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:33:10'),
(156, 43, 61, 6, '2019-04-16 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:33:26'),
(157, 43, 61, 6, '2019-07-16 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-09-21 15:57:48'),
(158, 35, 49, 6, '2019-03-12 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:48:21'),
(159, 35, 49, 6, '2019-06-12 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:48:44'),
(160, 35, 49, 6, '2019-09-12 00:00:00', 2, 0, '0001-01-01 00:00:00', 3, '2019-09-14 13:38:45'),
(161, 22, 37, 0, '2019-10-02 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:50:06'),
(162, 31, 45, 6, '2019-09-25 00:00:00', 1, 0, '0001-01-01 00:00:00', 3, '2019-09-03 16:06:39'),
(163, 45, 65, 6, '2019-07-01 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:51:54'),
(164, 45, 65, 6, '2019-08-01 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:52:03'),
(165, 45, 65, 6, '2019-09-01 00:00:00', 2, 0, '0001-01-01 00:00:00', 3, '2019-09-14 13:37:57'),
(166, 23, 38, 6, '2019-04-29 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:52:36'),
(167, 23, 38, 6, '2019-07-29 00:00:00', 1, 0, '0001-01-01 00:00:00', 3, '2019-08-14 13:41:02'),
(170, 33, 47, 6, '2019-02-28 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 15:54:58'),
(171, 33, 47, 6, '2019-05-27 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:27:51'),
(172, 29, 106, 6, '2019-07-01 00:00:00', 1, 0, '0001-01-01 00:00:00', 3, '2019-08-14 13:41:31'),
(173, 27, 42, 6, '2019-05-01 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 18:11:07'),
(174, 27, 42, 6, '2019-08-01 00:00:00', 1, 0, '0001-01-01 00:00:00', 0, '2019-08-14 14:13:13'),
(175, 42, 60, 6, '2019-05-14 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 18:16:15'),
(176, 42, 60, 6, '2019-08-14 00:00:00', 1, 0, '0001-01-01 00:00:00', 1, '2019-08-14 12:43:41'),
(177, 40, 54, 6, '2019-07-01 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-12 18:19:16'),
(178, 40, 54, 0, '2019-10-01 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-08-12 18:19:16'),
(179, 24, 39, 6, '2019-06-28 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:28:13'),
(180, 140, 168, 0, '2019-11-22 00:00:00', 0, 1, '2019-08-13 18:58:09', 1, '2019-08-13 18:58:09'),
(181, 141, 169, 0, '2019-11-05 00:00:00', 0, 1, '2019-08-13 19:00:46', 1, '2019-08-13 19:00:46'),
(182, 142, 170, 0, '2019-11-02 00:00:00', 0, 1, '2019-08-13 19:03:06', 1, '2019-08-13 19:03:06'),
(183, 143, 171, 6, '2019-06-08 00:00:00', 2, 1, '2019-08-13 19:05:43', 1, '2019-08-14 11:08:06'),
(184, 144, 172, 7, '2019-05-04 00:00:00', 2, 1, '2019-08-13 19:08:47', 1, '2019-08-14 11:04:26'),
(185, 145, 173, 6, '2018-07-30 00:00:00', 2, 1, '2019-08-13 19:11:00', 1, '2019-08-13 19:11:00'),
(186, 144, 172, 0, '2019-08-04 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:04:26'),
(187, 38, 52, 6, '2019-04-29 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:07:16'),
(188, 38, 52, 6, '2019-07-29 00:00:00', 1, 0, '0001-01-01 00:00:00', 0, '2019-08-14 14:14:30'),
(189, 143, 171, 6, '2019-09-08 00:00:00', 1, 0, '0001-01-01 00:00:00', 3, '2019-09-03 16:08:13'),
(190, 46, 66, 6, '2017-10-27 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:19:36'),
(191, 46, 66, 6, '2018-01-27 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:19:45'),
(192, 46, 66, 6, '2018-04-27 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:24:07'),
(193, 44, 64, 6, '2018-10-08 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:25:05'),
(194, 44, 64, 6, '2019-01-08 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:25:16'),
(195, 44, 64, 6, '2019-04-08 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:25:26'),
(196, 26, 41, 6, '2019-01-19 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:26:20'),
(197, 26, 41, 6, '2019-04-19 00:00:00', 2, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:26:37'),
(198, 26, 41, 6, '2019-07-19 00:00:00', 1, 0, '0001-01-01 00:00:00', 0, '2019-08-14 14:15:08'),
(199, 21, 36, 6, '2019-09-12 00:00:00', 2, 0, '0001-01-01 00:00:00', 3, '2019-09-16 10:47:43'),
(200, 41, 55, 6, '2019-07-22 00:00:00', 1, 0, '0001-01-01 00:00:00', 0, '2019-08-14 14:16:43'),
(201, 33, 47, 0, '2019-08-27 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-08-14 11:27:51'),
(202, 24, 39, 6, '2019-09-28 00:00:00', 2, 0, '0001-01-01 00:00:00', 3, '2019-09-17 10:14:19'),
(204, 39, 53, 0, '2019-10-30 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-09-21 15:26:27'),
(205, 39, 53, 0, '2019-10-30 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-09-21 15:31:50'),
(206, 34, 48, 0, '2019-12-01 00:00:00', 0, 0, '0001-01-01 00:00:00', 1, '2019-09-21 15:32:23'),
(207, 146, 174, 0, '2019-12-17 00:00:00', 0, 8, '2019-10-15 15:50:56', 8, '2019-10-15 15:50:56'),
(208, 146, 175, 0, '2019-11-16 00:00:00', 0, 8, '2019-10-15 15:51:15', 8, '2019-10-15 15:51:15');

-- --------------------------------------------------------

--
-- Table structure for table `service_details_master`
--

DROP TABLE IF EXISTS `service_details_master`;
CREATE TABLE IF NOT EXISTS `service_details_master` (
  `sdm_id` int(11) NOT NULL AUTO_INCREMENT,
  `sdm_cust_id` int(12) NOT NULL,
  `sdm_repeat` int(2) NOT NULL,
  `sdm_comment` mediumtext,
  `sdm_continuity` tinyint(2) DEFAULT NULL,
  `sdm_interval_days` int(11) DEFAULT NULL,
  `sdm_interval_months` int(11) DEFAULT NULL,
  `sdm_interval_year` int(11) DEFAULT NULL,
  `sdm_insrid` int(10) NOT NULL,
  `sdm_insdt` datetime NOT NULL,
  `sdm_logrid` int(10) NOT NULL,
  `sdm_logdt` datetime NOT NULL,
  PRIMARY KEY (`sdm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_details_master`
--

INSERT INTO `service_details_master` (`sdm_id`, `sdm_cust_id`, `sdm_repeat`, `sdm_comment`, `sdm_continuity`, `sdm_interval_days`, `sdm_interval_months`, `sdm_interval_year`, `sdm_insrid`, `sdm_insdt`, `sdm_logrid`, `sdm_logdt`) VALUES
(29, 16, 1, 'Elite RO', 1, 0, 3, 0, 3, '2019-07-12 18:18:00', 3, '2019-07-12 18:18:00'),
(30, 15, 0, 'PLUTO RO', 1, 0, 3, 0, 3, '2019-07-12 18:18:00', 3, '2019-07-12 18:18:00'),
(34, 19, 1, 'lexpure classic plus', 1, 0, 3, 0, 3, '2019-07-12 18:18:00', 3, '2019-07-12 18:18:00'),
(35, 20, 1, 'dolphin cruze (with B12 membrane', 1, 0, 3, 0, 3, '2019-07-13 15:14:16', 3, '2019-07-13 15:14:16'),
(36, 21, 1, 'ELITE RO', 1, 0, 3, 0, 3, '2019-07-13 15:18:54', 3, '2019-07-13 15:18:54'),
(37, 22, 1, 'ELITE RO', 1, 0, 3, 0, 3, '2019-07-13 15:24:14', 3, '2019-07-13 15:24:14'),
(38, 23, 1, 'LEXPURE CLASSIC PLUS', 1, 0, 3, 0, 3, '2019-07-13 15:29:40', 3, '2019-07-13 15:29:40'),
(39, 24, 1, 'LEXPURE CLASSIC PLUS', 1, 0, 3, 0, 3, '2019-07-13 15:33:04', 3, '2019-07-13 15:33:04'),
(40, 25, 1, 'AQUAGRAND ALTIS', 1, 0, 3, 0, 3, '2019-07-13 15:36:10', 3, '2019-07-13 15:36:10'),
(41, 26, 1, '25 LITRE RO', 1, 0, 3, 0, 3, '2019-07-13 15:38:27', 3, '2019-07-13 15:38:27'),
(42, 27, 1, '10 litre RO', 1, 0, 3, 0, 3, '2019-07-13 15:41:15', 3, '2019-07-13 15:41:15'),
(43, 28, 1, '', 1, 0, 3, 0, 3, '2019-07-13 15:43:45', 3, '2019-07-13 15:43:45'),
(45, 31, 1, '100 ltr purifier', 1, 0, 3, 0, 3, '2019-07-13 16:20:31', 3, '2019-07-13 16:20:31'),
(47, 33, 1, '10 ltr pressure tank RO', 1, 0, 3, 0, 3, '2019-07-13 16:26:50', 3, '2019-07-13 16:26:50'),
(48, 34, 1, 'AQUA DIGI', 1, 0, 3, 0, 3, '2019-07-13 16:29:47', 3, '2019-07-13 16:29:47'),
(49, 35, 1, 'AQUAGUARD', 0, 0, 3, 0, 3, '2019-07-13 16:32:27', 3, '2019-07-13 16:32:27'),
(50, 36, 1, 'LEXPURE RO PRESSURE TANK', 1, 0, 3, 0, 3, '2019-07-13 16:42:26', 3, '2019-07-13 16:42:26'),
(51, 37, 1, 'LEXPURE RO AQUARIUM', 1, 0, 3, 0, 3, '2019-07-13 16:45:22', 3, '2019-07-13 16:45:22'),
(52, 38, 1, '10 LTR RO, PURIFIER 25 LTR', 1, 0, 3, 0, 3, '2019-07-13 16:49:39', 3, '2019-07-13 16:49:39'),
(53, 39, 1, '50 LTR PURIFIER', 1, 0, 3, 0, 3, '2019-07-13 16:52:45', 3, '2019-07-13 16:52:45'),
(54, 40, 1, 'ELITE RO SYSTEM', 1, 0, 3, 0, 3, '2019-07-13 16:55:53', 3, '2019-07-13 16:55:53'),
(55, 41, 1, '100 LTR RO', 1, 0, 3, 0, 3, '2019-07-13 16:58:51', 3, '2019-07-13 16:58:51'),
(56, 42, 1, '', 1, 0, 0, 0, 3, '2019-07-13 17:02:47', 3, '2019-07-13 17:02:47'),
(57, 42, 1, '', 1, 0, 0, 0, 3, '2019-07-13 17:02:47', 3, '2019-07-13 17:02:47'),
(58, 42, 1, '', 1, 0, 0, 0, 3, '2019-07-13 17:02:48', 3, '2019-07-13 17:02:48'),
(59, 42, 1, '', 1, 0, 0, 0, 3, '2019-07-13 17:02:49', 3, '2019-07-13 17:02:49'),
(60, 42, 1, '100 LTR RO', 1, 0, 3, 0, 3, '2019-07-13 17:03:27', 3, '2019-07-13 17:03:27'),
(61, 43, 1, '50 LTR PURIFIER', 0, 0, 3, 0, 3, '2019-07-13 17:09:41', 3, '2019-07-13 17:09:41'),
(62, 44, 1, '', 1, 0, 0, 0, 3, '2019-07-13 17:14:05', 3, '2019-07-13 17:14:05'),
(63, 44, 1, '', 1, 0, 0, 0, 3, '2019-07-13 17:14:45', 3, '2019-07-13 17:14:45'),
(64, 44, 1, 'AQUAGUARD', 0, 0, 3, 0, 3, '2019-07-13 17:15:39', 3, '2019-07-13 17:15:39'),
(65, 45, 1, 'WATER SOFTNER', 1, 0, 1, 0, 3, '2019-07-13 17:19:25', 3, '2019-07-13 17:19:25'),
(66, 46, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-15 17:15:57', 3, '2019-07-15 17:15:57'),
(69, 47, 1, '', 0, 0, 3, 0, 3, '2019-07-17 15:33:01', 3, '2019-07-17 15:33:01'),
(70, 48, 1, 'AQUAGUARD', 0, 0, 3, 0, 3, '2019-07-17 15:37:55', 3, '2019-07-17 15:37:55'),
(71, 49, 1, 'lexpure elite', 0, 0, 3, 0, 3, '2019-07-17 15:43:45', 3, '2019-07-17 15:43:45'),
(72, 50, 1, 'lexpure elite', 0, 0, 3, 0, 3, '2019-07-17 15:47:38', 3, '2019-07-17 15:47:38'),
(73, 52, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-17 15:50:44', 3, '2019-07-17 15:50:44'),
(74, 51, 1, 'ELITE RO', 0, 0, 3, 0, 3, '2019-07-17 15:51:43', 3, '2019-07-17 15:51:43'),
(75, 53, 1, 'AQUAGUARD', 0, 0, 3, 0, 3, '2019-07-17 16:03:09', 3, '2019-07-17 16:03:09'),
(76, 54, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-17 16:06:40', 3, '2019-07-17 16:06:40'),
(77, 55, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-17 16:10:25', 3, '2019-07-17 16:10:25'),
(78, 56, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-17 16:13:58', 3, '2019-07-17 16:13:58'),
(79, 57, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-17 16:24:04', 3, '2019-07-17 16:24:04'),
(80, 58, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-17 16:26:39', 3, '2019-07-17 16:26:39'),
(81, 59, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-17 16:29:21', 3, '2019-07-17 16:29:21'),
(82, 60, 1, 'RO', 0, 0, 3, 0, 3, '2019-07-17 16:32:56', 3, '2019-07-17 16:32:56'),
(83, 61, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-19 17:40:52', 3, '2019-07-19 17:40:52'),
(84, 62, 1, 'AQUA GRAND', 0, 0, 3, 0, 3, '2019-07-19 17:51:10', 3, '2019-07-19 17:51:10'),
(85, 63, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-19 17:54:01', 3, '2019-07-19 17:54:01'),
(86, 64, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-19 17:57:44', 3, '2019-07-19 17:57:44'),
(87, 65, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-19 17:59:32', 3, '2019-07-19 17:59:32'),
(88, 66, 1, 'PLUTO RO', 0, 0, 3, 0, 3, '2019-07-19 18:01:42', 3, '2019-07-19 18:01:42'),
(89, 67, 1, 'DOLPHIN RO', 0, 0, 3, 0, 3, '2019-07-19 18:04:09', 3, '2019-07-19 18:04:09'),
(90, 68, 1, 'ELITE RO', 0, 0, 3, 0, 3, '2019-07-19 18:06:17', 3, '2019-07-19 18:06:17'),
(91, 68, 1, 'ELITE RO', 0, 0, 3, 0, 3, '2019-07-19 18:07:38', 3, '2019-07-19 18:07:38'),
(92, 69, 1, 'ELITE RO', 0, 0, 3, 0, 3, '2019-07-19 18:09:41', 3, '2019-07-19 18:09:41'),
(93, 70, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-19 18:12:10', 3, '2019-07-19 18:12:10'),
(94, 71, 1, '', 0, 0, 3, 0, 3, '2019-07-19 18:15:14', 3, '2019-07-19 18:15:14'),
(95, 72, 1, 'AQUA GRAND', 0, 0, 3, 0, 3, '2019-07-19 18:18:15', 3, '2019-07-19 18:18:15'),
(96, 73, 1, 'AMAZON RO', 0, 0, 3, 0, 3, '2019-07-19 18:21:50', 3, '2019-07-19 18:21:50'),
(97, 74, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-19 18:24:14', 3, '2019-07-19 18:24:14'),
(98, 75, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-19 18:26:20', 3, '2019-07-19 18:26:20'),
(99, 76, 1, 'WATER LILY', 0, 0, 3, 0, 3, '2019-07-19 18:28:19', 3, '2019-07-19 18:28:19'),
(100, 77, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-19 18:30:23', 3, '2019-07-19 18:30:23'),
(101, 78, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-19 18:32:58', 3, '2019-07-19 18:32:58'),
(102, 79, 1, 'ELITE RO', 0, 0, 3, 0, 3, '2019-07-19 18:34:40', 3, '2019-07-19 18:34:40'),
(103, 80, 1, 'WALLMOUNT PRESSURE TANK', 0, 0, 3, 0, 3, '2019-07-19 18:36:34', 3, '2019-07-19 18:36:34'),
(104, 81, 1, 'Elite RO', 0, 0, 3, 0, 3, '2019-07-19 18:39:07', 3, '2019-07-19 18:39:07'),
(105, 82, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-19 18:40:43', 3, '2019-07-19 18:40:43'),
(106, 29, 1, 'FORTUNE', 0, 0, 3, 0, 3, '2019-07-19 18:44:20', 3, '2019-07-19 18:44:20'),
(107, 83, 1, '10 LTR RO, PRESSURE TANK', 0, 0, 3, 0, 3, '2019-07-19 18:46:50', 3, '2019-07-19 18:46:50'),
(108, 84, 1, 'DOLPHIN RO', 0, 0, 3, 0, 3, '2019-07-19 18:48:41', 3, '2019-07-19 18:48:41'),
(109, 85, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-19 18:50:56', 3, '2019-07-19 18:50:56'),
(110, 86, 1, 'WALLMOUNT PRESSURE TANK', 0, 0, 3, 0, 3, '2019-07-19 18:53:06', 3, '2019-07-19 18:53:06'),
(111, 87, 1, 'DOLPHIN RO', 0, 0, 3, 0, 3, '2019-07-19 18:55:12', 3, '2019-07-19 18:55:12'),
(112, 88, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-19 18:58:30', 3, '2019-07-19 18:58:30'),
(113, 88, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-19 18:58:30', 3, '2019-07-19 18:58:30'),
(114, 89, 1, 'ROYAL APPLE', 0, 0, 3, 0, 3, '2019-07-20 13:00:10', 3, '2019-07-20 13:00:10'),
(115, 90, 1, 'AQUA ANJET', 0, 0, 3, 0, 3, '2019-07-20 13:02:17', 3, '2019-07-20 13:02:17'),
(116, 91, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-20 13:06:25', 3, '2019-07-20 13:06:25'),
(117, 92, 1, 'APPLE', 0, 0, 3, 0, 3, '2019-07-20 13:08:09', 3, '2019-07-20 13:08:09'),
(118, 93, 1, '10 LTR RO, PRESSURE TANK', 0, 0, 3, 0, 3, '2019-07-20 13:10:22', 3, '2019-07-20 13:10:22'),
(119, 94, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-20 13:12:32', 3, '2019-07-20 13:12:32'),
(120, 95, 1, 'APPLE', 0, 0, 3, 0, 3, '2019-07-20 13:14:10', 3, '2019-07-20 13:14:10'),
(121, 96, 1, 'SAFE WATER', 0, 0, 3, 0, 3, '2019-07-20 13:18:06', 3, '2019-07-20 13:18:06'),
(122, 97, 1, 'AQUAGRAND ALTIS', 0, 0, 3, 0, 3, '2019-07-20 13:19:57', 3, '2019-07-20 13:19:57'),
(123, 98, 1, '100 LTR RO', 0, 0, 3, 0, 3, '2019-07-20 13:22:26', 3, '2019-07-20 13:22:26'),
(124, 99, 1, 'AQUATIV', 0, 0, 3, 0, 3, '2019-07-20 13:24:45', 3, '2019-07-20 13:24:45'),
(125, 100, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-20 13:29:58', 3, '2019-07-20 13:29:58'),
(126, 101, 1, 'AQUA LIZA', 0, 0, 3, 0, 3, '2019-07-20 13:37:07', 3, '2019-07-20 13:37:07'),
(127, 102, 1, 'AQUA LIZA', 0, 0, 3, 0, 3, '2019-07-20 13:39:48', 3, '2019-07-20 13:39:48'),
(128, 103, 1, 'AQUA LIZA', 0, 0, 3, 0, 3, '2019-07-20 13:43:09', 3, '2019-07-20 13:43:09'),
(129, 104, 1, 'SAFE WATER', 0, 0, 3, 0, 3, '2019-07-20 13:46:27', 3, '2019-07-20 13:46:27'),
(130, 105, 1, 'ALTIS', 0, 0, 3, 0, 3, '2019-07-20 13:48:40', 3, '2019-07-20 13:48:40'),
(131, 106, 1, '', 0, 0, 3, 0, 3, '2019-07-20 13:50:42', 3, '2019-07-20 13:50:42'),
(132, 107, 1, 'DOLPHIN RO', 0, 0, 3, 0, 3, '2019-07-20 13:53:12', 3, '2019-07-20 13:53:12'),
(133, 108, 1, 'ELITE RO', 0, 0, 3, 0, 3, '2019-07-20 13:57:27', 3, '2019-07-20 13:57:27'),
(134, 108, 1, '25 LITRE RO', 0, 0, 3, 0, 3, '2019-07-20 14:07:15', 3, '2019-07-20 14:07:15'),
(135, 109, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-20 14:12:24', 3, '2019-07-20 14:12:24'),
(136, 110, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-20 14:15:23', 3, '2019-07-20 14:15:23'),
(137, 111, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-20 14:17:23', 3, '2019-07-20 14:17:23'),
(138, 112, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-20 14:19:55', 3, '2019-07-20 14:19:55'),
(139, 113, 1, '50 LTR RO', 0, 0, 3, 0, 3, '2019-07-20 14:23:23', 3, '2019-07-20 14:23:23'),
(140, 114, 1, '25 LITRE RO', 0, 0, 3, 0, 3, '2019-07-22 16:51:17', 3, '2019-07-22 16:51:17'),
(141, 115, 1, '25 LITRE RO', 0, 0, 3, 0, 3, '2019-07-22 16:54:43', 3, '2019-07-22 16:54:43'),
(142, 116, 1, '25 LITRE RO', 0, 0, 3, 0, 3, '2019-07-22 17:12:50', 3, '2019-07-22 17:12:50'),
(143, 117, 1, '25 LITRE RO', 0, 0, 3, 0, 3, '2019-07-22 17:19:58', 3, '2019-07-22 17:19:58'),
(144, 118, 1, '25 LITRE RO', 0, 0, 0, 0, 3, '2019-07-22 17:24:11', 3, '2019-07-22 17:24:11'),
(145, 118, 1, '10 LITRE RO', 0, 0, 3, 0, 3, '2019-07-22 17:25:59', 3, '2019-07-22 17:25:59'),
(146, 119, 1, '100 LTR RO', 0, 0, 3, 0, 3, '2019-07-22 17:29:04', 3, '2019-07-22 17:29:04'),
(147, 120, 1, '50 LTR RO', 0, 0, 3, 0, 3, '2019-07-22 17:32:42', 3, '2019-07-22 17:32:42'),
(148, 121, 1, 'ALTIS', 0, 0, 3, 0, 3, '2019-07-22 17:35:53', 3, '2019-07-22 17:35:53'),
(149, 122, 1, '50 LTR PURIFIER', 0, 0, 3, 0, 3, '2019-07-22 17:38:42', 3, '2019-07-22 17:38:42'),
(150, 123, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-22 17:40:19', 3, '2019-07-22 17:40:19'),
(151, 124, 1, '50 LTR RO', 0, 0, 3, 0, 3, '2019-07-22 17:43:36', 3, '2019-07-22 17:43:36'),
(152, 125, 1, '50 LTR PURIFIER', 0, 0, 3, 0, 3, '2019-07-22 17:46:27', 3, '2019-07-22 17:46:27'),
(153, 126, 1, '50 LTR RO', 0, 0, 3, 0, 3, '2019-07-22 17:48:01', 3, '2019-07-22 17:48:01'),
(154, 127, 1, '25 LITRE RO', 0, 0, 3, 0, 3, '2019-07-22 17:51:46', 3, '2019-07-22 17:51:46'),
(155, 128, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-22 17:58:05', 3, '2019-07-22 17:58:05'),
(156, 129, 1, '', 0, 0, 3, 0, 3, '2019-07-27 12:46:51', 3, '2019-07-27 12:46:51'),
(157, 130, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-27 12:51:02', 3, '2019-07-27 12:51:02'),
(158, 131, 1, 'lexpure RO', 0, 0, 3, 0, 3, '2019-07-27 12:58:54', 3, '2019-07-27 12:58:54'),
(159, 132, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-27 13:01:03', 3, '2019-07-27 13:01:03'),
(160, 133, 1, 'LEXPURE', 0, 0, 3, 0, 3, '2019-07-27 13:03:45', 3, '2019-07-27 13:03:45'),
(161, 134, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-27 13:05:31', 3, '2019-07-27 13:05:31'),
(162, 135, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-27 13:10:28', 3, '2019-07-27 13:10:28'),
(163, 136, 1, 'DOLTIN', 0, 0, 3, 0, 3, '2019-07-27 13:24:41', 3, '2019-07-27 13:24:41'),
(164, 137, 1, 'NEPTUNE', 0, 0, 3, 0, 3, '2019-07-27 13:27:26', 3, '2019-07-27 13:27:26'),
(165, 138, 1, 'DOLPHIN RO', 0, 0, 3, 0, 3, '2019-07-27 13:30:19', 3, '2019-07-27 13:30:19'),
(166, 139, 1, '50 LTR RO', 0, 0, 3, 0, 3, '2019-07-27 13:36:31', 3, '2019-07-27 13:36:31'),
(168, 140, 1, 'AQUA LIZA', 1, 0, 3, 0, 1, '2019-08-13 18:58:09', 1, '2019-08-13 18:58:09'),
(169, 141, 1, 'ALTIS', 1, 0, 3, 0, 1, '2019-08-13 19:00:46', 1, '2019-08-13 19:00:46'),
(170, 142, 1, '', 1, 0, 3, 0, 1, '2019-08-13 19:03:06', 1, '2019-08-13 19:03:06'),
(171, 143, 1, 'AQUA ALTIS', 1, 0, 3, 0, 1, '2019-08-13 19:05:43', 1, '2019-08-13 19:05:43'),
(172, 144, 1, 'ELITE RO', 1, 0, 3, 0, 1, '2019-08-13 19:08:47', 1, '2019-08-13 19:08:47'),
(173, 145, 1, 'LEXPURE RO', 0, 0, 3, 0, 1, '2019-08-13 19:11:00', 1, '2019-08-13 19:11:00'),
(174, 146, 1, 'das', 1, 1, 2, 2, 8, '2019-10-15 15:50:56', 8, '2019-10-15 15:50:56'),
(175, 146, 1, 'ds', 1, 1, 1, 1, 8, '2019-10-15 15:51:15', 8, '2019-10-15 15:51:15');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_master`
--

DROP TABLE IF EXISTS `supplier_master`;
CREATE TABLE IF NOT EXISTS `supplier_master` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_first_name` varchar(45) DEFAULT NULL,
  `sup_middle_name` varchar(45) DEFAULT NULL,
  `sup_last_name` varchar(45) DEFAULT NULL,
  `sup_business_name` varchar(100) NOT NULL,
  `sup_gst_no` varchar(100) DEFAULT NULL,
  `sup_primary_ctn` varchar(12) NOT NULL,
  `sup_second_ctn` varchar(12) DEFAULT NULL,
  `sup_third_ctn` varchar(12) DEFAULT NULL,
  `sup_email` varchar(100) DEFAULT NULL,
  `sup_address` varchar(150) DEFAULT NULL,
  `sup_city_village` varchar(45) DEFAULT NULL,
  `sup_pincode` varchar(11) DEFAULT NULL,
  `sup_insrid` int(11) DEFAULT NULL,
  `sup_insdt` datetime DEFAULT NULL,
  `sup_logrid` int(11) DEFAULT NULL,
  `sup_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`sup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_master`
--

INSERT INTO `supplier_master` (`sup_id`, `sup_first_name`, `sup_middle_name`, `sup_last_name`, `sup_business_name`, `sup_gst_no`, `sup_primary_ctn`, `sup_second_ctn`, `sup_third_ctn`, `sup_email`, `sup_address`, `sup_city_village`, `sup_pincode`, `sup_insrid`, `sup_insdt`, `sup_logrid`, `sup_logdt`) VALUES
(31, '', '', '', 'tech jimish', '', '9825874136', '', '', '', '', '', '', 8, '2019-09-23 12:54:33', 8, '2019-09-23 12:54:33'),
(33, '', '', '', 'tech akash', '', '8888888888', '', '', '', '', '', '', 8, '2019-09-23 12:54:54', 8, '2019-09-23 12:54:54'),
(34, 'd', '', '', 'jimisdh', '', '7417417414', '', '', '', '', '', '', 8, '2019-09-28 21:03:31', 8, '2019-09-28 21:03:44');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_purchase_bill_detail`
--

DROP TABLE IF EXISTS `supplier_purchase_bill_detail`;
CREATE TABLE IF NOT EXISTS `supplier_purchase_bill_detail` (
  `spbd_id` int(11) NOT NULL AUTO_INCREMENT,
  `spbd_bill_id` int(11) DEFAULT NULL COMMENT 'bll_id from supplier_purchase_bill_master id',
  `spbd_product_id` int(10) DEFAULT NULL COMMENT 'this is  product_vartiation_name_master id--> prvm_id',
  `spbd_product_price` float DEFAULT NULL COMMENT 'product billing price',
  `spbd_product_actual_price` float DEFAULT NULL COMMENT 'product actual price',
  `spbd_quentity` int(10) DEFAULT NULL COMMENT 'product billing quentity',
  `spbd_actual_quentity` int(10) DEFAULT NULL COMMENT 'product actual quentity',
  `spbd_total` float DEFAULT NULL COMMENT 'total billing price',
  `spbd_actual_total` float DEFAULT NULL COMMENT 'total actual price',
  `spbd_discount` float DEFAULT NULL COMMENT 'discount on product in %',
  `spbd_discount_amount` float DEFAULT NULL COMMENT 'discount amount on product ',
  `spbd_cgst` float DEFAULT NULL COMMENT 'cgst in %',
  `spbd_sgst` float DEFAULT NULL COMMENT 'sgst in %',
  `spbd_igst` float DEFAULT NULL COMMENT 'igst in %',
  `spbd_insrid` int(10) DEFAULT NULL,
  `spbd_insdt` datetime DEFAULT NULL,
  `spbd_logrid` int(10) DEFAULT NULL,
  `spbd_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`spbd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_purchase_bill_detail`
--

INSERT INTO `supplier_purchase_bill_detail` (`spbd_id`, `spbd_bill_id`, `spbd_product_id`, `spbd_product_price`, `spbd_product_actual_price`, `spbd_quentity`, `spbd_actual_quentity`, `spbd_total`, `spbd_actual_total`, `spbd_discount`, `spbd_discount_amount`, `spbd_cgst`, `spbd_sgst`, `spbd_igst`, `spbd_insrid`, `spbd_insdt`, `spbd_logrid`, `spbd_logdt`) VALUES
(1, 1, 2, 100, 100, 34, 34, 3400, 3400, 0, 0, 0, 0, 0, 8, '2019-11-21 19:09:45', 8, '2019-11-21 19:09:45'),
(2, 2, 2, 100, 100, 20, 20, 2000, 2000, 0, 0, 0, 0, 0, 8, '2020-01-18 17:26:46', 8, '2020-01-18 17:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_purchase_bill_master`
--

DROP TABLE IF EXISTS `supplier_purchase_bill_master`;
CREATE TABLE IF NOT EXISTS `supplier_purchase_bill_master` (
  `spb_id` int(11) NOT NULL AUTO_INCREMENT,
  `spb_supplier_id` int(10) DEFAULT NULL,
  `spb_purchase_bill_id` varchar(45) DEFAULT NULL COMMENT 'supplier purchase bill id which is inserted by user manually',
  `spb_purchse_date` datetime DEFAULT NULL COMMENT 'date which is inserted by user manually which shows when the product purchased.',
  `spb_total_amount` int(20) DEFAULT NULL COMMENT 'total amout sum of all product total billing price ',
  `spb_total_actual_amount` int(20) DEFAULT NULL COMMENT 'total amout sum of all product total actuall price ',
  `spb_status` tinyint(10) DEFAULT NULL COMMENT 'status 1 or 0!',
  `spb_financial_year` varchar(20) DEFAULT NULL,
  `spb_mode_of_payment` int(10) DEFAULT NULL,
  `spb_insrid` int(10) DEFAULT NULL,
  `spb_insdt` datetime DEFAULT NULL,
  `spb_logrid` int(10) DEFAULT NULL,
  `spb_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`spb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_purchase_bill_master`
--

INSERT INTO `supplier_purchase_bill_master` (`spb_id`, `spb_supplier_id`, `spb_purchase_bill_id`, `spb_purchse_date`, `spb_total_amount`, `spb_total_actual_amount`, `spb_status`, `spb_financial_year`, `spb_mode_of_payment`, `spb_insrid`, `spb_insdt`, `spb_logrid`, `spb_logdt`) VALUES
(1, 31, 'JIMISH', '2019-11-21 00:00:00', 3400, 3400, 1, '2018 - 2019', 2, 8, '2019-11-21 19:09:45', 8, '2019-11-21 19:09:45'),
(2, 34, 'DEMO PURCHASE BILL', '2020-01-18 00:00:00', 2000, 2000, 1, '2020 - 2021', 3, 8, '2020-01-18 17:26:46', 8, '2020-01-18 17:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_purchase_bill_payment`
--

DROP TABLE IF EXISTS `supplier_purchase_bill_payment`;
CREATE TABLE IF NOT EXISTS `supplier_purchase_bill_payment` (
  `spbp_id` int(11) NOT NULL AUTO_INCREMENT,
  `spbp_bill_id` int(10) DEFAULT NULL,
  `spbp_mod_of_payment` int(10) DEFAULT NULL,
  `spbp_date_of_payment` datetime DEFAULT NULL,
  `spbp_amount` int(10) DEFAULT NULL,
  `spbp_insrid` int(10) DEFAULT NULL,
  `spbp_insdt` datetime DEFAULT NULL,
  `spbp_logrid` int(10) DEFAULT NULL,
  `spbp_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`spbp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_purchase_bill_payment`
--

INSERT INTO `supplier_purchase_bill_payment` (`spbp_id`, `spbp_bill_id`, `spbp_mod_of_payment`, `spbp_date_of_payment`, `spbp_amount`, `spbp_insrid`, `spbp_insdt`, `spbp_logrid`, `spbp_logdt`) VALUES
(1, 1, 1, '2019-11-21 00:00:00', 400, 8, '2019-11-21 19:09:45', 8, '2019-11-21 19:09:45'),
(2, 2, 1, '2020-01-18 17:26:46', 0, 8, '2020-01-18 17:26:46', 8, '2020-01-18 17:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `tax_code_master`
--

DROP TABLE IF EXISTS `tax_code_master`;
CREATE TABLE IF NOT EXISTS `tax_code_master` (
  `txcd_id` int(11) NOT NULL AUTO_INCREMENT,
  `txcd_name` varchar(45) NOT NULL,
  `txcd_cgst` float NOT NULL,
  `txcd_sgst` float NOT NULL,
  `txcd_igst` float NOT NULL,
  `txcd_insrid` int(12) NOT NULL,
  `txcd_insdt` datetime NOT NULL,
  `txcd_logrid` int(12) NOT NULL,
  `txcd_logdt` datetime NOT NULL,
  PRIMARY KEY (`txcd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax_code_master`
--

INSERT INTO `tax_code_master` (`txcd_id`, `txcd_name`, `txcd_cgst`, `txcd_sgst`, `txcd_igst`, `txcd_insrid`, `txcd_insdt`, `txcd_logrid`, `txcd_logdt`) VALUES
(0, 'EXEMPTED', 0, 0, 0, 1, '2019-07-27 17:31:49', 1, '2019-07-27 17:31:49'),
(1, 'GST_05', 2.5, 2.5, 2.5, 1, '2019-07-27 17:31:49', 8, '2019-09-23 18:29:36'),
(2, 'GST_12', 6, 6, 5, 1, '2019-07-27 17:49:41', 1, '2019-09-03 20:37:58'),
(3, 'GST_18', 9, 9, 18, 1, '2019-07-27 17:49:53', 1, '2019-07-27 17:49:53'),
(4, 'GST_28', 14, 14, 28, 1, '2019-07-27 17:50:03', 8, '2019-09-23 18:29:45');

-- --------------------------------------------------------

--
-- Table structure for table `unit_master`
--

DROP TABLE IF EXISTS `unit_master`;
CREATE TABLE IF NOT EXISTS `unit_master` (
  `um_id` int(11) NOT NULL AUTO_INCREMENT,
  `um_name` varchar(45) NOT NULL,
  `um_insrid` int(11) NOT NULL,
  `um_insdt` datetime NOT NULL,
  `um_logrid` int(11) NOT NULL,
  `um_logdt` datetime NOT NULL,
  PRIMARY KEY (`um_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_master`
--

INSERT INTO `unit_master` (`um_id`, `um_name`, `um_insrid`, `um_insdt`, `um_logrid`, `um_logdt`) VALUES
(1, 'NOS', 1, '2019-07-27 17:51:41', 1, '2019-07-27 17:51:41'),
(6, 'LITRE', 1, '2019-07-27 17:51:36', 1, '2019-07-27 17:51:36'),
(7, 'INCH', 1, '2019-08-14 10:20:44', 1, '2019-08-14 10:20:44'),
(8, 'MTR', 1, '2019-08-14 10:45:19', 1, '2019-08-14 10:45:19'),
(9, 'VOLT', 1, '2019-08-18 19:36:28', 1, '2019-08-18 19:36:28'),
(10, 'AMP', 1, '2019-08-18 19:36:35', 1, '2019-08-18 19:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `voucher_master`
--

DROP TABLE IF EXISTS `voucher_master`;
CREATE TABLE IF NOT EXISTS `voucher_master` (
  `vm_id` int(11) NOT NULL AUTO_INCREMENT,
  `vm_vnm_id` int(10) DEFAULT NULL,
  `vm_name` varchar(45) DEFAULT NULL,
  `vm_person_name` varchar(45) DEFAULT NULL,
  `vm_phone_num` varchar(45) DEFAULT NULL,
  `vm_amount` int(10) DEFAULT NULL,
  `vm_date` datetime DEFAULT NULL,
  `vm_financial_year` varchar(40) DEFAULT NULL,
  `vm_insrid` int(10) DEFAULT NULL,
  `vm_insdt` datetime DEFAULT NULL,
  `vm_logrid` int(10) DEFAULT NULL,
  `vm_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`vm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucher_master`
--

INSERT INTO `voucher_master` (`vm_id`, `vm_vnm_id`, `vm_name`, `vm_person_name`, `vm_phone_num`, `vm_amount`, `vm_date`, `vm_financial_year`, `vm_insrid`, `vm_insdt`, `vm_logrid`, `vm_logdt`) VALUES
(1, 7, 'jimish', 'jimish', 'jimsih', 100, '2019-01-31 00:00:00', '2018 - 2019', 8, '2019-11-21 19:11:14', 8, '2019-11-21 19:11:14'),
(2, 8, 'jimish', 'jimish', 'jimsih', 132, '2019-02-02 00:00:00', '2018 - 2019', 8, '2019-11-21 19:11:30', 8, '2019-11-21 19:11:30'),
(3, 7, 'demo', 'demo', '8888885241', 100, '2020-01-10 00:00:00', '2020 - 2021', 8, '2020-01-18 17:34:16', 8, '2020-01-18 17:34:16');

-- --------------------------------------------------------

--
-- Table structure for table `voucher_name_master`
--

DROP TABLE IF EXISTS `voucher_name_master`;
CREATE TABLE IF NOT EXISTS `voucher_name_master` (
  `vm_id` int(11) NOT NULL AUTO_INCREMENT,
  `vm_name` varchar(45) DEFAULT NULL,
  `vm_insrid` int(10) DEFAULT NULL,
  `vm_insdt` datetime DEFAULT NULL,
  `vm_logrid` int(10) DEFAULT NULL,
  `vm_logdt` datetime DEFAULT NULL,
  PRIMARY KEY (`vm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucher_name_master`
--

INSERT INTO `voucher_name_master` (`vm_id`, `vm_name`, `vm_insrid`, `vm_insdt`, `vm_logrid`, `vm_logdt`) VALUES
(7, 'GENERAL', 1, '2019-09-18 14:58:17', 1, '2019-09-18 14:58:17'),
(8, 'DEMO', 8, '2019-09-26 17:09:05', 8, '2019-09-26 17:09:05'),
(9, 'DEMO A', 8, '2019-09-26 17:09:09', 8, '2019-09-26 17:09:09'),
(10, 'DEMO B', 8, '2019-09-26 17:09:13', 8, '2019-09-26 17:09:13'),
(11, 'DEMO C', 8, '2019-09-26 17:09:16', 8, '2019-09-26 17:09:16');

-- --------------------------------------------------------

--
-- Structure for view `get_all_product_details`
--
DROP TABLE IF EXISTS `get_all_product_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_all_product_details`  AS  select `pm`.`prdm_id` AS `prdm_id`,`pm`.`prdm_name` AS `prdm_name`,`pm`.`prdm_cat_id` AS `prdm_cat_id`,`pm`.`prdm_brand_id` AS `prdm_brand_id`,`pm`.`prdm_unit_id` AS `prdm_unit_id`,`pm`.`prdm_photo_link` AS `prdm_photo_link`,`pm`.`prdm_insrid` AS `prdm_insrid`,`pm`.`prdm_ldt` AS `prdm_ldt`,`pm`.`prdm_logrid` AS `prdm_logrid`,`pm`.`prdm_logdt` AS `prdm_logdt`,`um`.`um_id` AS `um_id`,`um`.`um_name` AS `um_name`,`um`.`um_insrid` AS `um_insrid`,`um`.`um_insdt` AS `um_insdt`,`um`.`um_logrid` AS `um_logrid`,`um`.`um_logdt` AS `um_logdt`,`cm`.`cat_id` AS `cat_id`,`cm`.`cat_name` AS `cat_name`,`cm`.`cat_insrid` AS `cat_insrid`,`cm`.`cat_insdt` AS `cat_insdt`,`cm`.`cat_logrid` AS `cat_logrid`,`cm`.`cat_logdt` AS `cat_logdt`,`bm`.`bm_rid` AS `bm_rid`,`bm`.`bm_name` AS `bm_name`,`bm`.`bm_insrid` AS `bm_insrid`,`bm`.`bm_insdt` AS `bm_insdt`,`bm`.`bm_logrid` AS `bm_logrid`,`bm`.`bm_logdt` AS `bm_logdt`,`pvnm`.`prvm_id` AS `prvm_id`,`pvnm`.`prvm_pdrm_id` AS `prvm_pdrm_id`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`pvnm`.`prvm_tax_code_id` AS `prvm_tax_code_id`,`pvnm`.`prvm_low_stock` AS `prvm_low_stock`,`pvnm`.`prvm_insrid` AS `prvm_insrid`,`pvnm`.`prvm_insdt` AS `prvm_insdt`,`pvnm`.`prvm_logdt` AS `prvm_logdt`,`pvnm`.`prvm_logrid` AS `prvm_logrid`,`pssm`.`pssm_id` AS `pssm_id`,`pssm`.`pssm_prdm_id` AS `pssm_prdm_id`,`pssm`.`pssm_pvnm_id` AS `pssm_pvnm_id`,`pssm`.`pssm_starting_qty` AS `pssm_starting_qty`,`pssm`.`pssm_starting_price` AS `pssm_starting_price`,`pssm`.`pssm_financial_year` AS `pssm_financial_year`,`pssm`.`pssm_insrid` AS `pssm_insrid`,`pssm`.`pssm_insdt` AS `pssm_insdt`,`pssm`.`pssm_logrid` AS `pssm_logrid`,`pssm`.`pssm_logdt` AS `pssm_logdt`,`psm`.`prd_spe_id` AS `prd_spe_id`,`psm`.`prd_spe_prdm_id` AS `prd_spe_prdm_id`,`psm`.`prd_spe_pvnm_id` AS `prd_spe_pvnm_id`,`psm`.`prd_spe_oth_cat_id` AS `prd_spe_oth_cat_id`,`psm`.`prd_spe_oth_cat_val` AS `prd_spe_oth_cat_val`,`psm`.`prd_spe_insrid` AS `prd_spe_insrid`,`psm`.`prd_spe_insdt` AS `prd_spe_insdt`,`psm`.`prd_spe_logrid` AS `prd_spe_logrid`,`psm`.`prd_spe_logdt` AS `prd_spe_logdt`,`ocm`.`oth_cat_id` AS `oth_cat_id`,`ocm`.`oth_cat_name` AS `oth_cat_name`,`ocm`.`oth_cat_is_unit` AS `oth_cat_is_unit`,`ocm`.`oth_cat_unit_id` AS `oth_cat_unit_id`,`ocm`.`oth_cat_insrid` AS `oth_cat_insrid`,`ocm`.`oth_cat_insdt` AS `oth_cat_insdt`,`ocm`.`oth_cat_logrid` AS `oth_cat_logrid`,`ocm`.`oth_cat_logdt` AS `oth_cat_logdt`,`tcm`.`txcd_id` AS `txcd_id`,`tcm`.`txcd_name` AS `txcd_name`,`tcm`.`txcd_cgst` AS `txcd_cgst`,`tcm`.`txcd_sgst` AS `txcd_sgst`,`tcm`.`txcd_igst` AS `txcd_igst`,`tcm`.`txcd_insrid` AS `txcd_insrid`,`tcm`.`txcd_insdt` AS `txcd_insdt`,`tcm`.`txcd_logrid` AS `txcd_logrid`,`tcm`.`txcd_logdt` AS `txcd_logdt`,`isp`.`idle_sell_id` AS `idle_sell_id`,`isp`.`idle_prod_var_id` AS `idle_prod_var_id`,`isp`.`idle_prod_var_name` AS `idle_prod_var_name`,`isp`.`idle_prod_selling_price` AS `idle_prod_selling_price`,`isp`.`idle_insrid` AS `idle_insrid`,`isp`.`idle_insdt` AS `idle_insdt`,`isp`.`idle_logrid` AS `idle_logrid`,`isp`.`idle_logdt` AS `idle_logdt` from (((((((((`product_master` `pm` left join `unit_master` `um` on((`pm`.`prdm_unit_id` = `um`.`um_id`))) left join `category_master` `cm` on((`cm`.`cat_id` = `pm`.`prdm_cat_id`))) left join `brand_master` `bm` on((`pm`.`prdm_brand_id` = `bm`.`bm_rid`))) left join `product_variation_name_master` `pvnm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `product_starting_stock_master` `pssm` on((`pssm`.`pssm_pvnm_id` = `pvnm`.`prvm_id`))) left join `product_specification_master` `psm` on((`psm`.`prd_spe_pvnm_id` = `pvnm`.`prvm_id`))) left join `other_category_master` `ocm` on((`ocm`.`oth_cat_id` = `psm`.`prd_spe_oth_cat_id`))) left join `tax_code_master` `tcm` on((`tcm`.`txcd_id` = `pvnm`.`prvm_tax_code_id`))) left join `idle_selling_price` `isp` on((`isp`.`idle_prod_var_id` = `pvnm`.`prvm_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_bill_detail_for_list_view`
--
DROP TABLE IF EXISTS `get_bill_detail_for_list_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_bill_detail_for_list_view`  AS  select `spbm`.`spb_id` AS `spb_id`,`spbm`.`spb_purchase_bill_id` AS `spb_purchase_bill_id`,`spbm`.`spb_financial_year` AS `spb_financial_year`,`spbd`.`spbd_id` AS `spbd_id`,`spbd`.`spbd_product_price` AS `spbd_product_price`,`spbd`.`spbd_quentity` AS `spbd_quentity`,(`spbd`.`spbd_product_price` * `spbd`.`spbd_quentity`) AS `price_each_product`,`spbd`.`spbd_product_id` AS `spbd_product_id`,`spbd`.`spbd_product_actual_price` AS `spbd_product_actual_price`,`spbd`.`spbd_actual_quentity` AS `spbd_actual_quentity`,`spbd`.`spbd_actual_total` AS `spbd_actual_total`,`spbd`.`spbd_discount` AS `spbd_discount`,`spbd`.`spbd_discount_amount` AS `spbd_discount_amount`,`spbm`.`spb_purchse_date` AS `spb_purchse_date`,`spbm`.`spb_total_amount` AS `spb_total_amount`,`spbm`.`spb_total_actual_amount` AS `spb_total_actual_amount`,`spbm`.`spb_status` AS `spb_status`,`sm`.`sup_business_name` AS `sup_business_name`,`sm`.`sup_id` AS `sup_id`,`sm`.`sup_primary_ctn` AS `sup_primary_ctn`,`spbd`.`spbd_bill_id` AS `spbd_bill_id`,`spbp`.`spbp_amount` AS `spbp_amount`,`mop`.`mop_id` AS `mop_id`,`mop`.`mop_name` AS `mop_name`,`tcm`.`txcd_name` AS `txcd_name`,`tcm`.`txcd_cgst` AS `txcd_cgst`,`tcm`.`txcd_sgst` AS `txcd_sgst`,`tcm`.`txcd_igst` AS `txcd_igst`,`cm`.`cust_id` AS `cust_id`,`cm`.`cust_first_name` AS `cust_first_name`,`cm`.`cust_middle_name` AS `cust_middle_name`,`cm`.`cust_last_name` AS `cust_last_name`,`cm`.`cust_primary_ctn` AS `cust_primary_ctn`,(case when isnull((select sum(`supplier_purchase_bill_payment`.`spbp_amount`) from `supplier_purchase_bill_payment` where (`supplier_purchase_bill_payment`.`spbp_bill_id` = `spbm`.`spb_id`))) then 0 else (select sum(`supplier_purchase_bill_payment`.`spbp_amount`) from `supplier_purchase_bill_payment` where (`supplier_purchase_bill_payment`.`spbp_bill_id` = `spbm`.`spb_id`)) end) AS `paidamount`,(case when isnull((`spbm`.`spb_total_actual_amount` - (select sum(`supplier_purchase_bill_payment`.`spbp_amount`) from `supplier_purchase_bill_payment` where (`supplier_purchase_bill_payment`.`spbp_bill_id` = `spbm`.`spb_id`)))) then `spbm`.`spb_total_actual_amount` else (`spbm`.`spb_total_actual_amount` - (select sum(`supplier_purchase_bill_payment`.`spbp_amount`) from `supplier_purchase_bill_payment` where (`supplier_purchase_bill_payment`.`spbp_bill_id` = `spbm`.`spb_id`))) end) AS `unpaidamount`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name` from ((((((((`supplier_purchase_bill_master` `spbm` left join `supplier_purchase_bill_detail` `spbd` on((`spbm`.`spb_id` = `spbd`.`spbd_bill_id`))) left join `supplier_purchase_bill_payment` `spbp` on((`spbp`.`spbp_bill_id` = `spbm`.`spb_id`))) left join `supplier_master` `sm` on((`sm`.`sup_id` = `spbm`.`spb_supplier_id`))) left join `product_variation_name_master` `pvnm` on((`pvnm`.`prvm_id` = `spbd`.`spbd_product_id`))) left join `product_master` `pm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `tax_code_master` `tcm` on((`tcm`.`txcd_id` = `pvnm`.`prvm_tax_code_id`))) left join `mode_of_payment` `mop` on((`mop`.`mop_id` = `spbp`.`spbp_mod_of_payment`))) left join `customer_master` `cm` on((`cm`.`cust_id` = `spbm`.`spb_supplier_id`))) where (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) ;

-- --------------------------------------------------------

--
-- Structure for view `get_customer_search_details`
--
DROP TABLE IF EXISTS `get_customer_search_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_customer_search_details`  AS  select `sbm`.`sbm_id` AS `sbm_id`,`sbm`.`customer_id` AS `customer_id`,`sbm`.`sbm_sales_bill_id` AS `sbm_sales_bill_id`,`sbm`.`sbm_sales_date` AS `sbm_sales_date`,`sbm`.`sbm_total_amount` AS `sbm_total_amount`,`sbm`.`sbm_total_actual_amount` AS `sbm_total_actual_amount`,`sbm`.`sbm_status` AS `sbm_status`,`sbm`.`sbm_financial_year` AS `sbm_financial_year`,`sbm`.`sbm_mode_of_payment` AS `mop_id`,`sbm`.`sbm_insrid` AS `sbm_insrid`,`sbm`.`sbm_insdt` AS `sbm_insdt`,`sbm`.`sbm_logrid` AS `sbm_logrid`,`sbm`.`sbm_logdt` AS `sbm_logdt`,`sbd`.`sbd_id` AS `sbd_id`,`sbd`.`sbd_bill_id` AS `sbd_bill_id`,`sbd`.`sbd_product_id` AS `sbd_product_id`,`sbd`.`sbd_product_price` AS `sbd_product_price`,`sbd`.`sbd_product_actual_price` AS `sbd_product_actual_price`,`sbd`.`sbd_quentity` AS `sbd_quentity`,`sbd`.`sbd_actual_quentity` AS `sbd_actual_quentity`,`sbd`.`sbd_total` AS `sbd_total`,`sbd`.`sbd_actual_total` AS `sbd_actual_total`,`sbd`.`sbd_discount` AS `sbd_discount`,`sbd`.`sbd_discount_amount` AS `sbd_discount_amount`,`sbd`.`sbd_cgst` AS `sbd_cgst`,`sbd`.`sbd_sgst` AS `sbd_sgst`,`sbd`.`sbd_igst` AS `sbd_igst`,`sbd`.`sbd_insrid` AS `sbd_insrid`,`sbd`.`sbd_insdt` AS `sbd_insdt`,`sbd`.`sbd_logrid` AS `sbd_logrid`,`sbd`.`sbd_logdt` AS `sbd_logdt`,`sbp`.`sbp_id` AS `sbp_id`,`sbp`.`sbp_bill_id` AS `sbp_bill_id`,`sbp`.`sbp_mod_of_payment` AS `sbp_mod_of_payment`,`sbp`.`sbp_date_of_payment` AS `sbp_date_of_payment`,`sbp`.`sbp_amount` AS `sbp_amount`,`sbp`.`sbp_insrid` AS `sbp_insrid`,`sbp`.`sbp_insdt` AS `sbp_insdt`,`sbp`.`sbp_logrid` AS `sbp_logrid`,`sbp`.`sbp_logdt` AS `sbp_logdt`,`cm`.`cust_id` AS `cust_id`,`cm`.`cust_first_name` AS `cust_first_name`,`cm`.`cust_middle_name` AS `cust_middle_name`,`cm`.`cust_last_name` AS `cust_last_name`,`cm`.`cust_gender` AS `cust_gender`,`cm`.`cust_city_village` AS `cust_city_village`,`cm`.`cust_pincode` AS `cust_pincode`,`cm`.`cust_address` AS `cust_address`,`cm`.`cust_primary_ctn` AS `cust_primary_ctn`,`cm`.`cust_whats_app_ctn` AS `cust_whats_app_ctn`,`cm`.`cust_second_ctn` AS `cust_second_ctn`,`cm`.`cust_third_ctn` AS `cust_third_ctn`,`cm`.`cust_insrid` AS `cust_insrid`,`cm`.`cust_insdt` AS `cust_insdt`,`cm`.`cust_logrid` AS `cust_logrid`,`cm`.`cust_logdt` AS `cust_logdt`,`cm`.`cust_email` AS `cust_email`,`pvnm`.`prvm_id` AS `prvm_id`,`pvnm`.`prvm_pdrm_id` AS `prvm_pdrm_id`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`pvnm`.`prvm_tax_code_id` AS `prvm_tax_code_id`,`pvnm`.`prvm_insrid` AS `prvm_insrid`,`pvnm`.`prvm_insdt` AS `prvm_insdt`,`pvnm`.`prvm_logdt` AS `prvm_logdt`,`pvnm`.`prvm_logrid` AS `prvm_logrid`,`pm`.`prdm_id` AS `prdm_id`,`pm`.`prdm_name` AS `prdm_name`,`pm`.`prdm_cat_id` AS `prdm_cat_id`,`pm`.`prdm_brand_id` AS `prdm_brand_id`,`pm`.`prdm_unit_id` AS `prdm_unit_id`,`pm`.`prdm_photo_link` AS `prdm_photo_link`,`pm`.`prdm_insrid` AS `prdm_insrid`,`pm`.`prdm_ldt` AS `prdm_ldt`,`pm`.`prdm_logrid` AS `prdm_logrid`,`pm`.`prdm_logdt` AS `prdm_logdt`,`tcm`.`txcd_id` AS `txcd_id`,`tcm`.`txcd_name` AS `txcd_name`,`tcm`.`txcd_cgst` AS `txcd_cgst`,`tcm`.`txcd_sgst` AS `txcd_sgst`,`tcm`.`txcd_igst` AS `txcd_igst`,`tcm`.`txcd_insrid` AS `txcd_insrid`,`tcm`.`txcd_insdt` AS `txcd_insdt`,`tcm`.`txcd_logrid` AS `txcd_logrid`,`tcm`.`txcd_logdt` AS `txcd_logdt`,`mop`.`mop_name` AS `mop_name` from (((((((`sales_bill_master` `sbm` left join `sales_bill_detail` `sbd` on((`sbm`.`sbm_id` = `sbd`.`sbd_bill_id`))) left join `sales_bill_payment` `sbp` on((`sbp`.`sbp_bill_id` = `sbm`.`sbm_id`))) left join `customer_master` `cm` on((`cm`.`cust_id` = `sbm`.`customer_id`))) left join `product_variation_name_master` `pvnm` on((`pvnm`.`prvm_id` = `sbd`.`sbd_product_id`))) left join `product_master` `pm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `tax_code_master` `tcm` on((`tcm`.`txcd_id` = `pvnm`.`prvm_tax_code_id`))) left join `mode_of_payment` `mop` on((`mop`.`mop_id` = `sbp`.`sbp_mod_of_payment`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_low_stock_alert`
--
DROP TABLE IF EXISTS `get_low_stock_alert`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_low_stock_alert`  AS  select `rpvn`.`pssm_pvnm_id` AS `pssm_pvnm_id`,`rpvn`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`rpvn`.`current_quentity` AS `current_quentity`,`pvnm`.`prvm_low_stock` AS `prvm_low_stock` from (`report_product_var_name` `rpvn` left join `product_variation_name_master` `pvnm` on((`rpvn`.`pssm_pvnm_id` = `pvnm`.`prvm_id`))) where ((`rpvn`.`current_quentity` <= `pvnm`.`prvm_low_stock`) and (`pvnm`.`prvm_low_stock` <> 0)) ;

-- --------------------------------------------------------

--
-- Structure for view `get_other_cat_unit_name`
--
DROP TABLE IF EXISTS `get_other_cat_unit_name`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_other_cat_unit_name`  AS  select `ocm`.`oth_cat_id` AS `oth_cat_id`,`ocm`.`oth_cat_name` AS `oth_cat_name`,`ocm`.`oth_cat_is_unit` AS `oth_cat_is_unit`,`ocm`.`oth_cat_unit_id` AS `oth_cat_unit_id`,`ocm`.`oth_cat_insrid` AS `oth_cat_insrid`,`ocm`.`oth_cat_insdt` AS `oth_cat_insdt`,`ocm`.`oth_cat_logrid` AS `oth_cat_logrid`,`ocm`.`oth_cat_logdt` AS `oth_cat_logdt`,`um`.`um_id` AS `um_id`,(case when (`um`.`um_name` <> '0') then `um`.`um_name` else 'No Unit' end) AS `um_name`,`um`.`um_insrid` AS `um_insrid`,`um`.`um_insdt` AS `um_insdt`,`um`.`um_logrid` AS `um_logrid`,`um`.`um_logdt` AS `um_logdt` from (`other_category_master` `ocm` left join `unit_master` `um` on((`ocm`.`oth_cat_unit_id` = `um`.`um_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_product_list_bill_payment`
--
DROP TABLE IF EXISTS `get_product_list_bill_payment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_product_list_bill_payment`  AS  select `spbd`.`spbd_bill_id` AS `spbd_bill_id`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`spbd`.`spbd_product_price` AS `spbd_product_price`,`spbd`.`spbd_product_actual_price` AS `spbd_product_actual_price`,`spbd`.`spbd_quentity` AS `spbd_quentity`,`spbd`.`spbd_actual_quentity` AS `spbd_actual_quentity`,`spbd`.`spbd_total` AS `spbd_total`,`spbd`.`spbd_actual_total` AS `spbd_actual_total`,`spbd`.`spbd_igst` AS `spbd_igst`,`spbd`.`spbd_discount` AS `spbd_discount` from (((`supplier_purchase_bill_detail` `spbd` left join `product_variation_name_master` `pvnm` on((`spbd`.`spbd_product_id` = `pvnm`.`prvm_id`))) left join `supplier_purchase_bill_master` `spbm` on((`spbm`.`spb_id` = `spbd`.`spbd_bill_id`))) left join `supplier_master` `sm` on((`sm`.`sup_id` = `spbm`.`spb_supplier_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_product_list_for_filter`
--
DROP TABLE IF EXISTS `get_product_list_for_filter`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_product_list_for_filter`  AS  select `pm`.`prdm_id` AS `prdm_id`,`pm`.`prdm_name` AS `product_name`,sum(`pssm`.`pssm_starting_qty`) AS `total_quentity`,min(`pssm`.`pssm_starting_price`) AS `starting_price` from (`product_master` `pm` left join `product_starting_stock_master` `pssm` on((`pm`.`prdm_id` = `pssm`.`pssm_prdm_id`))) group by `pm`.`prdm_id` ;

-- --------------------------------------------------------

--
-- Structure for view `get_product_list_sales_bill_payment`
--
DROP TABLE IF EXISTS `get_product_list_sales_bill_payment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_product_list_sales_bill_payment`  AS  select `sbd`.`sbd_id` AS `sbd_id`,`sbd`.`sbd_bill_id` AS `sbd_bill_id`,`sbd`.`sbd_product_id` AS `sbd_product_id`,`sbd`.`sbd_product_price` AS `sbd_product_price`,`sbd`.`sbd_product_actual_price` AS `sbd_product_actual_price`,`sbd`.`sbd_quentity` AS `sbd_quentity`,`sbd`.`sbd_actual_quentity` AS `sbd_actual_quentity`,`sbd`.`sbd_total` AS `sbd_total`,`sbd`.`sbd_actual_total` AS `sbd_actual_total`,`sbd`.`sbd_discount` AS `sbd_discount`,`sbd`.`sbd_discount_amount` AS `sbd_discount_amount`,`sbd`.`sbd_cgst` AS `sbd_cgst`,`sbd`.`sbd_sgst` AS `sbd_sgst`,`sbd`.`sbd_igst` AS `sbd_igst`,`sbd`.`sbd_insrid` AS `sbd_insrid`,`sbd`.`sbd_insdt` AS `sbd_insdt`,`sbd`.`sbd_logrid` AS `sbd_logrid`,`sbd`.`sbd_logdt` AS `sbd_logdt`,`pvnm`.`prvm_id` AS `prvm_id`,`pvnm`.`prvm_pdrm_id` AS `prvm_pdrm_id`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`pvnm`.`prvm_tax_code_id` AS `prvm_tax_code_id`,`pvnm`.`prvm_low_stock` AS `prvm_low_stock`,`pvnm`.`prvm_insrid` AS `prvm_insrid`,`pvnm`.`prvm_insdt` AS `prvm_insdt`,`pvnm`.`prvm_logdt` AS `prvm_logdt`,`pvnm`.`prvm_logrid` AS `prvm_logrid`,`sbm`.`sbm_id` AS `sbm_id`,`sbm`.`customer_id` AS `customer_id`,`sbm`.`sbm_sales_bill_id` AS `sbm_sales_bill_id`,`sbm`.`sbm_sales_date` AS `sbm_sales_date`,`sbm`.`sbm_total_amount` AS `sbm_total_amount`,`sbm`.`sbm_total_actual_amount` AS `sbm_total_actual_amount`,`sbm`.`sbm_status` AS `sbm_status`,`sbm`.`sbm_financial_year` AS `sbm_financial_year`,`sbm`.`sbm_mode_of_payment` AS `sbm_mode_of_payment`,`sbm`.`sbm_insrid` AS `sbm_insrid`,`sbm`.`sbm_insdt` AS `sbm_insdt`,`sbm`.`sbm_logrid` AS `sbm_logrid`,`sbm`.`sbm_logdt` AS `sbm_logdt`,`cm`.`cust_id` AS `cust_id`,`cm`.`cust_first_name` AS `cust_first_name`,`cm`.`cust_middle_name` AS `cust_middle_name`,`cm`.`cust_last_name` AS `cust_last_name`,`cm`.`cust_gender` AS `cust_gender`,`cm`.`cust_city_village` AS `cust_city_village`,`cm`.`cust_pincode` AS `cust_pincode`,`cm`.`cust_address` AS `cust_address`,`cm`.`cust_primary_ctn` AS `cust_primary_ctn`,`cm`.`cust_whats_app_ctn` AS `cust_whats_app_ctn`,`cm`.`cust_second_ctn` AS `cust_second_ctn`,`cm`.`cust_third_ctn` AS `cust_third_ctn`,`cm`.`cust_insrid` AS `cust_insrid`,`cm`.`cust_insdt` AS `cust_insdt`,`cm`.`cust_logrid` AS `cust_logrid`,`cm`.`cust_logdt` AS `cust_logdt`,`cm`.`cust_email` AS `cust_email` from (((`sales_bill_detail` `sbd` left join `product_variation_name_master` `pvnm` on((`pvnm`.`prvm_id` = `sbd`.`sbd_product_id`))) left join `sales_bill_master` `sbm` on((`sbm`.`sbm_id` = `sbd`.`sbd_bill_id`))) left join `customer_master` `cm` on((`cm`.`cust_id` = `sbm`.`customer_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_product_variation_edit_page`
--
DROP TABLE IF EXISTS `get_product_variation_edit_page`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_product_variation_edit_page`  AS  select `pvnm`.`prvm_id` AS `prvm_id`,`pvnm`.`prvm_pdrm_id` AS `prvm_pdrm_id`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`pvnm`.`prvm_tax_code_id` AS `prvm_tax_code_id`,`pvnm`.`prvm_insrid` AS `prvm_insrid`,`pvnm`.`prvm_insdt` AS `prvm_insdt`,`pvnm`.`prvm_logdt` AS `prvm_logdt`,`pvnm`.`prvm_logrid` AS `prvm_logrid`,`pssm`.`pssm_id` AS `pssm_id`,`pssm`.`pssm_prdm_id` AS `pssm_prdm_id`,`pssm`.`pssm_pvnm_id` AS `pssm_pvnm_id`,`pssm`.`pssm_starting_qty` AS `pssm_starting_qty`,`pssm`.`pssm_starting_price` AS `pssm_starting_price`,`pssm`.`pssm_financial_year` AS `pssm_financial_year`,`pssm`.`pssm_insrid` AS `pssm_insrid`,`pssm`.`pssm_insdt` AS `pssm_insdt`,`pssm`.`pssm_logrid` AS `pssm_logrid`,`pssm`.`pssm_logdt` AS `pssm_logdt`,`pm`.`prdm_id` AS `prdm_id`,`pm`.`prdm_name` AS `prdm_name`,`pm`.`prdm_cat_id` AS `prdm_cat_id`,`pm`.`prdm_brand_id` AS `prdm_brand_id`,`pm`.`prdm_unit_id` AS `prdm_unit_id`,`pm`.`prdm_photo_link` AS `prdm_photo_link`,`pm`.`prdm_insrid` AS `prdm_insrid`,`pm`.`prdm_ldt` AS `prdm_ldt`,`pm`.`prdm_logrid` AS `prdm_logrid`,`pm`.`prdm_logdt` AS `prdm_logdt`,`psm`.`prd_spe_id` AS `prd_spe_id`,`psm`.`prd_spe_prdm_id` AS `prd_spe_prdm_id`,`psm`.`prd_spe_pvnm_id` AS `prd_spe_pvnm_id`,`psm`.`prd_spe_oth_cat_id` AS `prd_spe_oth_cat_id`,`psm`.`prd_spe_oth_cat_val` AS `prd_spe_oth_cat_val`,`psm`.`prd_spe_insrid` AS `prd_spe_insrid`,`psm`.`prd_spe_insdt` AS `prd_spe_insdt`,`psm`.`prd_spe_logrid` AS `prd_spe_logrid`,`psm`.`prd_spe_logdt` AS `prd_spe_logdt`,`ocm`.`oth_cat_id` AS `oth_cat_id`,`ocm`.`oth_cat_name` AS `oth_cat_name`,`ocm`.`oth_cat_is_unit` AS `oth_cat_is_unit`,`ocm`.`oth_cat_unit_id` AS `oth_cat_unit_id`,`ocm`.`oth_cat_insrid` AS `oth_cat_insrid`,`ocm`.`oth_cat_insdt` AS `oth_cat_insdt`,`ocm`.`oth_cat_logrid` AS `oth_cat_logrid`,`ocm`.`oth_cat_logdt` AS `oth_cat_logdt` from ((((`product_variation_name_master` `pvnm` left join `product_starting_stock_master` `pssm` on((`pvnm`.`prvm_id` = `pssm`.`pssm_pvnm_id`))) left join `product_master` `pm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `product_specification_master` `psm` on((`psm`.`prd_spe_prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `other_category_master` `ocm` on((`ocm`.`oth_cat_id` = `psm`.`prd_spe_oth_cat_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_reminder`
--
DROP TABLE IF EXISTS `get_reminder`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_reminder`  AS  select `cm`.`cust_id` AS `cust_id`,`cm`.`cust_first_name` AS `cust_first_name`,`cm`.`cust_middle_name` AS `cust_middle_name`,`cm`.`cust_last_name` AS `cust_last_name`,concat(`cm`.`cust_first_name`,' ',`cm`.`cust_middle_name`,' ',`cm`.`cust_last_name`) AS `customer_name`,`cm`.`cust_busines_name` AS `cust_busines_name`,`cm`.`cust_gender` AS `cust_gender`,`cm`.`cust_city_village` AS `cust_city_village`,`cm`.`cust_pincode` AS `cust_pincode`,`cm`.`cust_address` AS `cust_address`,`cm`.`cust_primary_ctn` AS `cust_primary_ctn`,`cm`.`cust_whats_app_ctn` AS `cust_whats_app_ctn`,`cm`.`cust_second_ctn` AS `cust_second_ctn`,`cm`.`cust_third_ctn` AS `cust_third_ctn`,`cm`.`cust_insrid` AS `cust_insrid`,`cm`.`cust_insdt` AS `cust_insdt`,`cm`.`cust_logrid` AS `cust_logrid`,`cm`.`cust_logdt` AS `cust_logdt`,`cm`.`cust_email` AS `cust_email`,`sdm`.`sdm_id` AS `sdm_id`,`sdm`.`sdm_cust_id` AS `sdm_cust_id`,`sdm`.`sdm_repeat` AS `sdm_repeat`,`sdm`.`sdm_comment` AS `sdm_comment`,`sdm`.`sdm_continuity` AS `sdm_continuity`,`sdm`.`sdm_interval_days` AS `sdm_interval_days`,`sdm`.`sdm_interval_months` AS `sdm_interval_months`,`sdm`.`sdm_interval_year` AS `sdm_interval_year`,`sdm`.`sdm_insrid` AS `sdm_insrid`,`sdm`.`sdm_insdt` AS `sdm_insdt`,`sdm`.`sdm_logrid` AS `sdm_logrid`,`sdm`.`sdm_logdt` AS `sdm_logdt`,`sdtm`.`sdtm_id` AS `sdtm_id`,`sdtm`.`sdtm_cust_id` AS `sdtm_cust_id`,`sdtm`.`sdtm_sdm_id` AS `sdtm_sdm_id`,`sdtm`.`sdtm_date` AS `sdtm_date`,`sdtm`.`sdtm_service_man_id` AS `sdtm_service_man_id`,`sdtm`.`sdtm_status` AS `sdtm_status`,`sdtm`.`sdtm_insrid` AS `sdtm_insrid`,`sdtm`.`sdtm_insdt` AS `sdtm_insdt`,`sdtm`.`sdtm_logrid` AS `sdtm_logrid`,`sdtm`.`sdtm_logdt` AS `sdtm_logdt`,concat(`admnreg`.`admn_usr_first_name`,' ',`admnreg`.`admn_usr_father_name`,' ',`admnreg`.`admn_usr_sur_name`) AS `service_person_name`,`admnreg`.`admn_usr_mobile_no` AS `admn_usr_mobile_no` from (((`customer_master` `cm` left join `service_details_master` `sdm` on((`sdm`.`sdm_cust_id` = `cm`.`cust_id`))) left join `service_date_master` `sdtm` on((`sdtm`.`sdtm_sdm_id` = `sdm`.`sdm_id`))) left join `admin_registration_master` `admnreg` on((`sdtm`.`sdtm_service_man_id` = `admnreg`.`admn_usr_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_sell_detail_for_list_view`
--
DROP TABLE IF EXISTS `get_sell_detail_for_list_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_sell_detail_for_list_view`  AS  select `sbm`.`sbm_id` AS `sbm_id`,`sbm`.`customer_id` AS `customer_id`,`sbm`.`sbm_sales_bill_id` AS `sbm_sales_bill_id`,`sbm`.`sbm_sales_date` AS `sbm_sales_date`,`sbm`.`sbm_total_amount` AS `sbm_total_amount`,`sbm`.`sbm_total_actual_amount` AS `sbm_total_actual_amount`,`sbm`.`sbm_status` AS `sbm_status`,`sbm`.`sbm_insrid` AS `sbm_insrid`,`sbm`.`sbm_insdt` AS `sbm_insdt`,`sbm`.`sbm_logrid` AS `sbm_logrid`,`sbm`.`sbm_logdt` AS `sbm_logdt`,`sbd`.`sbd_id` AS `sbd_id`,`sbd`.`sbd_bill_id` AS `sbd_bill_id`,`sbd`.`sbd_product_id` AS `sbd_product_id`,`sbd`.`sbd_product_price` AS `sbd_product_price`,`sbd`.`sbd_product_actual_price` AS `sbd_product_actual_price`,`sbd`.`sbd_quentity` AS `sbd_quentity`,`sbd`.`sbd_actual_quentity` AS `sbd_actual_quentity`,`sbd`.`sbd_total` AS `sbd_total`,`sbd`.`sbd_actual_total` AS `sbd_actual_total`,`sbd`.`sbd_discount` AS `sbd_discount`,`sbd`.`sbd_discount_amount` AS `sbd_discount_amount`,`sbd`.`sbd_cgst` AS `sbd_cgst`,`sbd`.`sbd_sgst` AS `sbd_sgst`,`sbd`.`sbd_igst` AS `sbd_igst`,`sbd`.`sbd_insrid` AS `sbd_insrid`,`sbd`.`sbd_insdt` AS `sbd_insdt`,`sbd`.`sbd_logrid` AS `sbd_logrid`,`sbd`.`sbd_logdt` AS `sbd_logdt`,`sbp`.`sbp_id` AS `sbp_id`,`sbp`.`sbp_bill_id` AS `sbp_bill_id`,`sbp`.`sbp_mod_of_payment` AS `sbp_mod_of_payment`,`sbp`.`sbp_date_of_payment` AS `sbp_date_of_payment`,`sbp`.`sbp_amount` AS `sbp_amount`,`sbp`.`sbp_insrid` AS `sbp_insrid`,`sbp`.`sbp_insdt` AS `sbp_insdt`,`sbp`.`sbp_logrid` AS `sbp_logrid`,`sbp`.`sbp_logdt` AS `sbp_logdt`,`cm`.`cust_id` AS `cust_id`,`cm`.`cust_first_name` AS `cust_first_name`,`cm`.`cust_middle_name` AS `cust_middle_name`,`cm`.`cust_last_name` AS `cust_last_name`,`cm`.`cust_gender` AS `cust_gender`,`cm`.`cust_city_village` AS `cust_city_village`,`cm`.`cust_pincode` AS `cust_pincode`,`cm`.`cust_address` AS `cust_address`,`cm`.`cust_primary_ctn` AS `cust_primary_ctn`,`cm`.`cust_whats_app_ctn` AS `cust_whats_app_ctn`,`cm`.`cust_second_ctn` AS `cust_second_ctn`,`cm`.`cust_third_ctn` AS `cust_third_ctn`,`cm`.`cust_insrid` AS `cust_insrid`,`cm`.`cust_insdt` AS `cust_insdt`,`cm`.`cust_logrid` AS `cust_logrid`,`cm`.`cust_logdt` AS `cust_logdt`,`cm`.`cust_email` AS `cust_email`,`pvnm`.`prvm_id` AS `prvm_id`,`pvnm`.`prvm_pdrm_id` AS `prvm_pdrm_id`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`pvnm`.`prvm_tax_code_id` AS `prvm_tax_code_id`,`pvnm`.`prvm_insrid` AS `prvm_insrid`,`pvnm`.`prvm_insdt` AS `prvm_insdt`,`pvnm`.`prvm_logdt` AS `prvm_logdt`,`pvnm`.`prvm_logrid` AS `prvm_logrid`,`pm`.`prdm_id` AS `prdm_id`,`pm`.`prdm_name` AS `prdm_name`,`pm`.`prdm_cat_id` AS `prdm_cat_id`,`pm`.`prdm_brand_id` AS `prdm_brand_id`,`pm`.`prdm_unit_id` AS `prdm_unit_id`,`pm`.`prdm_photo_link` AS `prdm_photo_link`,`pm`.`prdm_insrid` AS `prdm_insrid`,`pm`.`prdm_ldt` AS `prdm_ldt`,`pm`.`prdm_logrid` AS `prdm_logrid`,`pm`.`prdm_logdt` AS `prdm_logdt`,`tcm`.`txcd_id` AS `txcd_id`,`tcm`.`txcd_name` AS `txcd_name`,`tcm`.`txcd_cgst` AS `txcd_cgst`,`tcm`.`txcd_sgst` AS `txcd_sgst`,`tcm`.`txcd_igst` AS `txcd_igst`,`tcm`.`txcd_insrid` AS `txcd_insrid`,`tcm`.`txcd_insdt` AS `txcd_insdt`,`tcm`.`txcd_logrid` AS `txcd_logrid`,`tcm`.`txcd_logdt` AS `txcd_logdt`,`mop`.`mop_id` AS `mop_id`,`mop`.`mop_name` AS `mop_name`,(case when isnull((select sum(`sales_bill_payment`.`sbp_amount`) from `sales_bill_payment` where (`sales_bill_payment`.`sbp_bill_id` = `sbm`.`sbm_id`))) then 0 else (select sum(`sales_bill_payment`.`sbp_amount`) from `sales_bill_payment` where (`sales_bill_payment`.`sbp_bill_id` = `sbm`.`sbm_id`)) end) AS `paidamount`,(case when isnull((`sbm`.`sbm_total_actual_amount` - (select sum(`sales_bill_payment`.`sbp_amount`) from `sales_bill_payment` where (`sales_bill_payment`.`sbp_bill_id` = `sbm`.`sbm_id`)))) then `sbm`.`sbm_total_amount` else (`sbm`.`sbm_total_actual_amount` - (select sum(`sales_bill_payment`.`sbp_amount`) from `sales_bill_payment` where (`sales_bill_payment`.`sbp_bill_id` = `sbm`.`sbm_id`))) end) AS `unpaidamount` from (((((((`sales_bill_master` `sbm` left join `sales_bill_detail` `sbd` on((`sbm`.`sbm_id` = `sbd`.`sbd_bill_id`))) left join `sales_bill_payment` `sbp` on((`sbp`.`sbp_bill_id` = `sbm`.`sbm_id`))) left join `customer_master` `cm` on((`cm`.`cust_id` = `sbm`.`customer_id`))) left join `product_variation_name_master` `pvnm` on((`pvnm`.`prvm_id` = `sbd`.`sbd_product_id`))) left join `product_master` `pm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `tax_code_master` `tcm` on((`tcm`.`txcd_id` = `pvnm`.`prvm_tax_code_id`))) left join `mode_of_payment` `mop` on((`mop`.`mop_id` = `sbp`.`sbp_mod_of_payment`))) where (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) ;

-- --------------------------------------------------------

--
-- Structure for view `get_specification_edit_page`
--
DROP TABLE IF EXISTS `get_specification_edit_page`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_specification_edit_page`  AS  select `pm`.`prdm_id` AS `prdm_id`,`pm`.`prdm_name` AS `prdm_name`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name`,`ocm`.`oth_cat_name` AS `oth_cat_name`,`ocm`.`oth_cat_id` AS `oth_cat_id` from (((`product_master` `pm` left join `product_variation_name_master` `pvnm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `product_specification_master` `psm` on((`psm`.`prd_spe_prdm_id` = `pm`.`prdm_id`))) left join `other_category_master` `ocm` on((`ocm`.`oth_cat_id` = `psm`.`prd_spe_oth_cat_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_supplier_search_details`
--
DROP TABLE IF EXISTS `get_supplier_search_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_supplier_search_details`  AS  select `spbm`.`spb_id` AS `spb_id`,`spbm`.`spb_purchase_bill_id` AS `spb_purchase_bill_id`,`spbm`.`spb_financial_year` AS `spb_financial_year`,`spbm`.`spb_mode_of_payment` AS `mop_id`,`spbd`.`spbd_id` AS `spbd_id`,`spbd`.`spbd_product_price` AS `spbd_product_price`,`spbd`.`spbd_quentity` AS `spbd_quentity`,`spbd`.`spbd_total` AS `price_each_product`,`spbd`.`spbd_product_id` AS `spbd_product_id`,`spbd`.`spbd_product_actual_price` AS `spbd_product_actual_price`,`spbd`.`spbd_actual_quentity` AS `spbd_actual_quentity`,`spbd`.`spbd_actual_total` AS `spbd_actual_total`,`spbd`.`spbd_discount` AS `spbd_discount`,`spbd`.`spbd_discount_amount` AS `spbd_discount_amount`,`spbm`.`spb_purchse_date` AS `spb_purchse_date`,`spbm`.`spb_total_amount` AS `spb_total_amount`,`sm`.`sup_business_name` AS `sup_business_name`,`sm`.`sup_id` AS `sup_id`,`sm`.`sup_primary_ctn` AS `sup_primary_ctn`,`spbd`.`spbd_bill_id` AS `spbd_bill_id`,`spbp`.`spbp_amount` AS `spbd_amount`,`mop`.`mop_name` AS `mop_name`,`tcm`.`txcd_name` AS `txcd_name`,`tcm`.`txcd_cgst` AS `txcd_cgst`,`tcm`.`txcd_sgst` AS `txcd_sgst`,`tcm`.`txcd_igst` AS `txcd_igst`,`pvnm`.`prvm_product_variation_name` AS `prvm_product_variation_name` from (((((((`supplier_purchase_bill_master` `spbm` left join `supplier_purchase_bill_detail` `spbd` on((`spbm`.`spb_id` = `spbd`.`spbd_bill_id`))) left join `supplier_purchase_bill_payment` `spbp` on((`spbp`.`spbp_bill_id` = `spbm`.`spb_id`))) left join `supplier_master` `sm` on((`sm`.`sup_id` = `spbm`.`spb_supplier_id`))) left join `product_variation_name_master` `pvnm` on((`pvnm`.`prvm_id` = `spbd`.`spbd_product_id`))) left join `product_master` `pm` on((`pm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `tax_code_master` `tcm` on((`tcm`.`txcd_id` = `pvnm`.`prvm_tax_code_id`))) left join `mode_of_payment` `mop` on((`mop`.`mop_id` = `spbp`.`spbp_mod_of_payment`))) ;

-- --------------------------------------------------------

--
-- Structure for view `get_todays_reminder`
--
DROP TABLE IF EXISTS `get_todays_reminder`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `get_todays_reminder`  AS  select `cm`.`cust_id` AS `cust_id`,`cm`.`cust_first_name` AS `cust_first_name`,`cm`.`cust_middle_name` AS `cust_middle_name`,`cm`.`cust_last_name` AS `cust_last_name`,`cm`.`cust_busines_name` AS `cust_busines_name`,`cm`.`cust_gender` AS `cust_gender`,`cm`.`cust_city_village` AS `cust_city_village`,`cm`.`cust_pincode` AS `cust_pincode`,`cm`.`cust_address` AS `cust_address`,`cm`.`cust_primary_ctn` AS `cust_primary_ctn`,`cm`.`cust_whats_app_ctn` AS `cust_whats_app_ctn`,`cm`.`cust_second_ctn` AS `cust_second_ctn`,`cm`.`cust_third_ctn` AS `cust_third_ctn`,`cm`.`cust_insrid` AS `cust_insrid`,`cm`.`cust_insdt` AS `cust_insdt`,`cm`.`cust_logrid` AS `cust_logrid`,`cm`.`cust_logdt` AS `cust_logdt`,`cm`.`cust_email` AS `cust_email`,`sdm`.`sdm_id` AS `sdm_id`,`sdm`.`sdm_cust_id` AS `sdm_cust_id`,`sdm`.`sdm_repeat` AS `sdm_repeat`,`sdm`.`sdm_interval_days` AS `sdm_interval_days`,`sdm`.`sdm_interval_months` AS `sdm_interval_months`,`sdm`.`sdm_interval_year` AS `sdm_interval_year`,`sdm`.`sdm_insrid` AS `sdm_insrid`,`sdm`.`sdm_insdt` AS `sdm_insdt`,`sdm`.`sdm_logrid` AS `sdm_logrid`,`sdm`.`sdm_logdt` AS `sdm_logdt`,`sdtm`.`sdtm_id` AS `sdtm_id`,`sdtm`.`sdtm_cust_id` AS `sdtm_cust_id`,`sdtm`.`sdtm_date` AS `sdtm_date`,`sdtm`.`sdtm_sdm_id` AS `sdtm_sdm_id`,`sdtm`.`sdtm_insrid` AS `sdtm_insrid`,`sdtm`.`sdtm_insdt` AS `sdtm_insdt`,`sdtm`.`sdtm_logrid` AS `sdtm_logrid`,`sdtm`.`sdtm_logdt` AS `sdtm_logdt`,`sdtm`.`sdtm_service_man_id` AS `sdtm_service_man_id` from ((`customer_master` `cm` left join `service_details_master` `sdm` on((`sdm`.`sdm_cust_id` = `cm`.`cust_id`))) left join `service_date_master` `sdtm` on((`sdtm`.`sdtm_sdm_id` = `sdm`.`sdm_id`))) where (`sdtm`.`sdtm_date` = curdate()) ;

-- --------------------------------------------------------

--
-- Structure for view `report_product_name`
--
DROP TABLE IF EXISTS `report_product_name`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `report_product_name`  AS  select min(`prdm`.`prdm_id`) AS `prdm_id`,min(`prdm`.`prdm_name`) AS `prdm_name`,min(`pssm`.`pssm_starting_qty`) AS `pssm_starting_qty`,(case when isnull((select sum(`spbd`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` `spbd1` left join `supplier_purchase_bill_master` `spbm` on((`spbd1`.`spbd_bill_id` = `spbm`.`spb_id`))) where (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `spbd`.`spbd_product_id`)) then 0 else (select sum(`spbd1`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` `spbd1` left join `supplier_purchase_bill_master` `spbm` on((`spbd1`.`spbd_bill_id` = `spbm`.`spb_id`))) where ((`spbd1`.`spbd_product_id` = `spbd`.`spbd_product_id`) and (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)))) end) AS `purchased_quentity`,(case when isnull((select sum(`sbd`.`sbd_actual_quentity`) from (`sales_bill_detail` `sbd1` left join `sales_bill_master` `sbm` on((`sbm`.`sbm_id` = `sbd1`.`sbd_bill_id`))) where (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `sbd`.`sbd_product_id`)) then 0 else (select sum(`sbd`.`sbd_actual_quentity`) from (`sales_bill_detail` `sbd1` join `sales_bill_master` `sbm` on((`sbm`.`sbm_id` = `sbd1`.`sbd_bill_id`))) where ((`sbd1`.`sbd_product_id` = `sbd`.`sbd_product_id`) and (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `sbd`.`sbd_product_id`) end) AS `sell_quantity`,(((case when isnull((select sum(`spbd`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` `spbd1` left join `supplier_purchase_bill_master` `spbm` on((`spbd1`.`spbd_bill_id` = `spbm`.`spb_id`))) where (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `spbd`.`spbd_product_id`)) then 0 else (select sum(`spbd1`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` `spbd1` left join `supplier_purchase_bill_master` `spbm` on((`spbd1`.`spbd_bill_id` = `spbm`.`spb_id`))) where ((`spbd1`.`spbd_product_id` = `spbd`.`spbd_product_id`) and (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)))) end) + min(`pssm`.`pssm_starting_qty`)) - (case when isnull((select sum(`sbd`.`sbd_actual_quentity`) from (`sales_bill_detail` `sbd1` left join `sales_bill_master` `sbm` on((`sbm`.`sbm_id` = `sbd1`.`sbd_bill_id`))) where (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `sbd`.`sbd_product_id`)) then 0 else (select sum(`sbd1`.`sbd_actual_quentity`) from (`sales_bill_detail` `sbd1` left join `sales_bill_master` `sbm` on((`sbm`.`sbm_id` = `sbd1`.`sbd_bill_id`))) where ((`sbd1`.`sbd_product_id` = `sbd`.`sbd_product_id`) and (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)))) end)) AS `total_out_standing_quantity` from (((((`product_master` `prdm` left join `product_variation_name_master` `pvnm` on((`prdm`.`prdm_id` = `pvnm`.`prvm_pdrm_id`))) left join `product_starting_stock_master` `pssm` on((`pssm`.`pssm_pvnm_id` = `pvnm`.`prvm_id`))) left join `product_specification_master` `pspem` on((`pspem`.`prd_spe_pvnm_id` = `pvnm`.`prvm_id`))) left join `sales_bill_detail` `sbd` on((`sbd`.`sbd_product_id` = `pvnm`.`prvm_id`))) left join `supplier_purchase_bill_detail` `spbd` on((`spbd`.`spbd_product_id` = `pvnm`.`prvm_id`))) where (`pssm`.`pssm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `pvnm`.`prvm_id` ;

-- --------------------------------------------------------

--
-- Structure for view `report_product_var_name`
--
DROP TABLE IF EXISTS `report_product_var_name`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `report_product_var_name`  AS  select min(`pssm`.`pssm_pvnm_id`) AS `pssm_pvnm_id`,min(`pvnm`.`prvm_product_variation_name`) AS `prvm_product_variation_name`,min(`pssm`.`pssm_starting_qty`) AS `pssm_starting_qty`,(case when isnull((select min(`supplier_purchase_bill_detail`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` left join `supplier_purchase_bill_master` `spbm` on((`supplier_purchase_bill_detail`.`spbd_bill_id` = `spbm`.`spb_id`))) where ((`supplier_purchase_bill_detail`.`spbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `supplier_purchase_bill_detail`.`spbd_product_id`)) then 0 else (select sum(`supplier_purchase_bill_detail`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` left join `supplier_purchase_bill_master` `spbm` on((`supplier_purchase_bill_detail`.`spbd_bill_id` = `spbm`.`spb_id`))) where ((`supplier_purchase_bill_detail`.`spbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `supplier_purchase_bill_detail`.`spbd_product_id`) end) AS `purchased_quentity`,(case when isnull((select min(`sales_bill_detail`.`sbd_actual_quentity`) from (`sales_bill_detail` left join `sales_bill_master` `sbm` on((`sales_bill_detail`.`sbd_bill_id` = `sbm`.`sbm_id`))) where ((`sales_bill_detail`.`sbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `sales_bill_detail`.`sbd_product_id`)) then 0 else (select min(`sales_bill_detail`.`sbd_actual_quentity`) from (`sales_bill_detail` left join `sales_bill_master` `sbm` on((`sales_bill_detail`.`sbd_bill_id` = `sbm`.`sbm_id`))) where ((`sales_bill_detail`.`sbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `sales_bill_detail`.`sbd_product_id`) end) AS `sold_quentity`,((min(`pssm`.`pssm_starting_qty`) + (case when isnull((select min(`supplier_purchase_bill_detail`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` left join `supplier_purchase_bill_master` `spbm` on((`supplier_purchase_bill_detail`.`spbd_bill_id` = `spbm`.`spb_id`))) where ((`supplier_purchase_bill_detail`.`spbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `supplier_purchase_bill_detail`.`spbd_product_id`)) then 0 else (select sum(`supplier_purchase_bill_detail`.`spbd_actual_quentity`) from (`supplier_purchase_bill_detail` left join `supplier_purchase_bill_master` `spbm` on((`supplier_purchase_bill_detail`.`spbd_bill_id` = `spbm`.`spb_id`))) where ((`supplier_purchase_bill_detail`.`spbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`spbm`.`spb_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `supplier_purchase_bill_detail`.`spbd_product_id`) end)) - (case when isnull((select min(`sales_bill_detail`.`sbd_actual_quentity`) from (`sales_bill_detail` left join `sales_bill_master` `sbm` on((`sales_bill_detail`.`sbd_bill_id` = `sbm`.`sbm_id`))) where ((`sales_bill_detail`.`sbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `sales_bill_detail`.`sbd_product_id`)) then 0 else (select min(`sales_bill_detail`.`sbd_actual_quentity`) from (`sales_bill_detail` left join `sales_bill_master` `sbm` on((`sales_bill_detail`.`sbd_bill_id` = `sbm`.`sbm_id`))) where ((`sales_bill_detail`.`sbd_product_id` = `pssm`.`pssm_pvnm_id`) and (`sbm`.`sbm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`))) group by `sales_bill_detail`.`sbd_product_id`) end)) AS `current_quentity` from (((`product_starting_stock_master` `pssm` left join `supplier_purchase_bill_detail` `spbd` on((`pssm`.`pssm_pvnm_id` = `spbd`.`spbd_product_id`))) left join `sales_bill_detail` `sbd` on((`sbd`.`sbd_product_id` = `spbd`.`spbd_product_id`))) left join `product_variation_name_master` `pvnm` on((`pssm`.`pssm_prdm_id` = `pvnm`.`prvm_pdrm_id`))) where (`pssm`.`pssm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `pssm`.`pssm_pvnm_id` ;

-- --------------------------------------------------------

--
-- Structure for view `report_voucher`
--
DROP TABLE IF EXISTS `report_voucher`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `report_voucher`  AS  select `vm`.`vm_vnm_id` AS `vm_vnm_id`,`vnm`.`vm_name` AS `voucher_type`,(select count(`vmm`.`vm_vnm_id`) from `voucher_master` `vmm` where (`vmm`.`vm_vnm_id` = `vm`.`vm_vnm_id`)) AS `total_voucher`,(select sum(`vmm`.`vm_amount`) from `voucher_master` `vmm` where (`vmm`.`vm_vnm_id` = `vm`.`vm_vnm_id`)) AS `total_voucher_amount` from (`voucher_master` `vm` left join `voucher_name_master` `vnm` on((`vm`.`vm_vnm_id` = `vnm`.`vm_id`))) where (`vm`.`vm_financial_year` = (select `current_financial_year_master`.`current_financial_year` from `current_financial_year_master`)) group by `vm`.`vm_vnm_id` ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
