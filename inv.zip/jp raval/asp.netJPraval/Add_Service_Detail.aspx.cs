﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Add_Service_Detail : System.Web.UI.Page
{
    public DateTime NextMonth(DateTime date, int days, int months)
    {
        if (date.Day != DateTime.DaysInMonth(date.Year, date.Month))
            return date.AddDays(days).AddMonths(months);

        else
            return date.AddDays(days).AddMonths(months).AddDays(-1);
    }
    void loaddatemonth()
    {
        DateTime NowTime = DateTime.Now;
        int year = NowTime.Year;
        for (int i = 0; i < 10; i++)
        {

            dryear.Items.Add((i + 1).ToString());

        }
        for (int i = 0; i < 12; i++)
        {

            drmonth.Items.Add((i + 1).ToString());

        }
        for (int i = 0; i < 31; i++)
        {

            drday.Items.Add((i + 1).ToString());

        }
        dryear.Items.Insert(0, "Select Years");
        drmonth.Items.Insert(0, "Select Months");
        drday.Items.Insert(0, "Select Days");
        dryear.Items[0].Value = "0";
        drmonth.Items[0].Value = "0";
        drday.Items[0].Value = "0";

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login_admin"] != null)
        {


            if (!IsPostBack)
            {
                if (Request.QueryString["cuid"] == "")
                {
                    Response.Redirect("Customer_List.aspx");
                }
                loaddatemonth();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (rdoonetim.Checked == false && rdorepeat.Checked == false)
        {
            Response.Write("<script>alert('Please choose service type')</script>");

        }
        else
        {
            service_details_masterBAL sdmBAL = new service_details_masterBAL();
            sdmBAL.sdm_cust_id = Convert.ToInt32(Request.QueryString["cuid"].ToString());
            if (rdorepeat.Checked == true)
            {
                sdmBAL.sdm_repeat = 1;
            }
            else if (rdoonetim.Checked == true)
            {
                sdmBAL.sdm_repeat = 0;
            }
            sdmBAL.sdm_comment = txtmachinename.Text.Trim().Replace('-',' ');
            sdmBAL.sdm_interval_days = Convert.ToInt16(drday.SelectedItem.Value);
            sdmBAL.sdm_interval_months = Convert.ToInt16(drmonth.SelectedItem.Value);
            sdmBAL.sdm_interval_year = Convert.ToInt16(dryear.SelectedItem.Value);
            sdmBAL.sdm_insrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdm_insdt = System.DateTime.Now;
            sdmBAL.sdm_logrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdm_logdt = System.DateTime.Now;
            sdmBAL.sdtm_cust_id = Convert.ToInt32(Request.QueryString["cuid"].ToString());
            if (txtstartdate.Text != "")
            {
                DateTime dtformated = Convert.ToDateTime(txtstartdate.Text + " " + "00:00:00");
                //  sdmBAL.sdtm_date = dtformated.ToString("yyyy/MM/dd");
                sdmBAL.sdtm_date = NextMonth(Convert.ToDateTime(dtformated), Convert.ToInt16(drday.SelectedItem.Value.ToString()), Convert.ToInt16(drmonth.SelectedItem.Value.ToString())).ToString();
            }
            sdmBAL.sdtm_insrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdtm_insdt = System.DateTime.Now;
            sdmBAL.sdtm_logrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdtm_logdt = System.DateTime.Now;
            service_details_masterDAL sdmDAL = new service_details_masterDAL();
            int val = sdmDAL.insert_into_service_details_master(sdmBAL);
            if (val == 2)
            {
                Response.Redirect("Filter_Customer.aspx?data=service");
            }
            else if (val == 3)
            {
                Response.Write("<script>alert('Service Details Updated Successfully.')</script>");
            }
        }
    }
    protected void rdorepeat_CheckedChanged(object sender, EventArgs e)
    {

        pnlinterval.Visible = true;
    }
    protected void rdoonetim_CheckedChanged(object sender, EventArgs e)
    {
        pnlinterval.Visible = false;
    }
    protected void btnexpiredservice_Click(object sender, EventArgs e)
    {
        if (rdoonetim.Checked == false && rdorepeat.Checked == false)
        {
            Response.Write("<script>alert('Please choose service type')</script>");

        }
        else
        {
            service_details_masterBAL sdmBAL = new service_details_masterBAL();
            sdmBAL.sdm_cust_id = Convert.ToInt32(Request.QueryString["cuid"].ToString());
            if (rdorepeat.Checked == true)
            {
                sdmBAL.sdm_repeat = 1;
            }
            else if (rdoonetim.Checked == true)
            {
                sdmBAL.sdm_repeat = 0;
            }
            sdmBAL.sdm_comment = txtmachinename.Text.Trim().Replace('-',' ');
            sdmBAL.sdm_interval_days = Convert.ToInt16(drday.SelectedItem.Value);
            sdmBAL.sdm_interval_months = Convert.ToInt16(drmonth.SelectedItem.Value);
            sdmBAL.sdm_interval_year = Convert.ToInt16(dryear.SelectedItem.Value);
            sdmBAL.sdm_insrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdm_insdt = System.DateTime.Now;
            sdmBAL.sdm_logrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdm_logdt = System.DateTime.Now;
            sdmBAL.sdtm_cust_id = Convert.ToInt32(Request.QueryString["cuid"].ToString());
            if (txtstartdate.Text != "")
            {
                DateTime dtformated = Convert.ToDateTime(txtstartdate.Text + " " + "00:00:00");
                sdmBAL.sdtm_date = dtformated.ToString("yyyy/MM/dd");
            }
            sdmBAL.sdtm_insrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdtm_insdt = System.DateTime.Now;
            sdmBAL.sdtm_logrid = Convert.ToInt32(Session["login"].ToString());
            sdmBAL.sdtm_logdt = System.DateTime.Now;
            service_details_masterDAL sdmDAL = new service_details_masterDAL();
            int val = sdmDAL.insert_into_service_details_master_expired(sdmBAL);
            if (val == 2)
            {
                Response.Redirect("Filter_Customer.aspx?data=service");
            }
            else if (val == 3)
            {
                Response.Write("<script>alert('Service Details Updated Successfully.')</script>");
            }
        }
    }
}