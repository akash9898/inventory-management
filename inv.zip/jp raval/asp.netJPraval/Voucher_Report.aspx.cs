﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Voucher_Report : System.Web.UI.Page
{
    //for count of total voucher and sum of voucher price
    public void total_voucher_price()
    {
        inventiry_reportDAL irDAL = new inventiry_reportDAL();
        DataSet ds = irDAL.get_voucher_total();

        //total voucher
        lbltotalvoucher.Text = ds.Tables[0].Rows[0]["total_voucher"].ToString();

        //total sum of voucher
        lblvoucheramount.Text ="₹ " + ds.Tables[0].Rows[0]["total_voucher_amount"].ToString();
    }

    //total voucher name,total voucher,total amount each vocher
    public void voucher_price_name_total()
    {
        inventiry_reportDAL irDAL = new inventiry_reportDAL();
        DataSet ds = irDAL.get_voucher_name_total_price();

        if (ds.Tables[0].Rows.Count > 0)
        {
            grdvoucherreport.DataSource = ds;
            grdvoucherreport.DataBind();
        }
        else
        {
            grdvoucherreport.DataSource = null;
            grdvoucherreport.DataBind();
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Session["login"] != null)
            {

                //total voucher price
                total_voucher_price();

                //voucher price name total
                voucher_price_name_total();


            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }

        }
    }

    protected void grdvoucherreport_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}