﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Add_Update_Other_Category : System.Web.UI.Page
{
    public void Loadunit()
    {
        unit_masterDAL umDAL = new unit_masterDAL();
        DataSet ds = umDAL.get_unit_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drunit.DataSource = ds;
            drunit.DataTextField = "um_name";
            drunit.DataValueField = "um_id";
            drunit.DataBind();
            drunit.Items.Insert(0, "--- Select Unit ---");
        }
    }

    public void fillunitgrid()
    {
        other_category_masterDAL otmDAL = new other_category_masterDAL();
        DataSet ds = otmDAL.get_other_category_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                fillunitgrid();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        other_category_masterBAL otmBAL = new other_category_masterBAL();

        if (hfotcatid.Value.ToString() == "")
        {
            otmBAL.oth_cat_id = 0;
        }
        else if (hfotcatid.Value.ToString() != "")
        {
            otmBAL.oth_cat_id = Convert.ToInt16(hfotcatid.Value.ToString());
        }
        otmBAL.oth_cat_name = txtcategory.Text.ToString().Trim().ToUpper().Replace('-', '~');
        if (chkbxisunit.Checked == true)
        {
            otmBAL.oth_cat_is_unit = 1;
            otmBAL.oth_cat_unit_id = Convert.ToInt16(drunit.SelectedItem.Value.ToString());
        }
        else if (chkbxisunit.Checked == false)
        {
            otmBAL.oth_cat_is_unit = 0;
            otmBAL.oth_cat_unit_id = 0;
        }
        otmBAL.oth_cat_insrid = Convert.ToInt16(Session["login"]);
        otmBAL.oth_cat_insdt = System.DateTime.Now;
        otmBAL.oth_cat_logrid = Convert.ToInt16(Session["login"]);
        otmBAL.oth_cat_logdt = System.DateTime.Now;

        other_category_masterDAL otmDAL = new other_category_masterDAL();
        int val = otmDAL.insert_other_category(otmBAL);

        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('Category Alredy Exists Please Enter Another Category.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('Succesfully Inserted Category.')</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('Category Updated Successfully.')</script>");
        }

        hfotcatid.Value = "";
        txtcategory.Text = "";
        chkbxisunit.Checked = false;
        drunit.Visible = false;
        fillunitgrid();
    }

    protected void Is_Unit_CheckEvent(object sender, EventArgs e)
    {
        if (drunit.Visible == false)
        {
            drunit.Visible = true;
            Loadunit();
        }
        else if (drunit.Visible == true)
        {
            drunit.Visible = false;
        }
    }

    protected void gridrepeater_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnview")
        {
            other_category_masterBAL catBAL = new other_category_masterBAL();
            catBAL.oth_cat_id = Convert.ToInt16(e.CommandArgument.ToString());
            other_category_masterDAL catDAL = new other_category_masterDAL();
            DataSet ds = catDAL.get_another_category_for_edit(catBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfotcatid.Value = ds.Tables[0].Rows[0]["oth_cat_id"].ToString();
                txtcategory.Text = ds.Tables[0].Rows[0]["oth_cat_name"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Sorry data does not exists');</script>");
            }
        }
        //else if (e.CommandName.ToString() == "btndelete")
        //{
        //    string id = e.CommandArgument.ToString();
        //    other_category_masterBAL catBAL = new other_category_masterBAL();
        //    catBAL.oth_cat_id = Convert.ToInt32(id);
        //    other_category_masterDAL catDAL = new other_category_masterDAL();
        //    catDAL.delete_another_category(catBAL);
        //    fillunitgrid();
        //}
    }
}