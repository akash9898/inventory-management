﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Expired_AMC : System.Web.UI.Page
{
    public void fill_expired_amc()
    {

        service_details_masterDAL sdmDAL = new service_details_masterDAL();
        DataSet ds = sdmDAL.get_expired_amc();
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptr_expired_amc.DataSource = ds;
            rptr_expired_amc.DataBind();
        }
        else
        {
            rptr_expired_amc.DataSource = null;
            rptr_expired_amc.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                fill_expired_amc();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }
    protected void rptr_expired_amc_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}