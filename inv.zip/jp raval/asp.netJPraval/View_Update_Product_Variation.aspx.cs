﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class View_Update_Product_Variation : System.Web.UI.Page
{
    public void load_brand_drop()
    {
        brand_masterDAL brd_masDAL = new brand_masterDAL();
        DataSet ds = brd_masDAL.get_brand_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drbrand.DataSource = ds;
            drbrand.DataTextField = "bm_name";
            drbrand.DataValueField = "bm_rid";
            drbrand.DataBind();
            drbrand.Items.Insert(0, "--- Select Brand ---");
        }
    }

    public void load_category_drop()
    {
        category_masterDAL catDAL = new category_masterDAL();
        DataSet ds = catDAL.get_category_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            catdrop.DataSource = ds;
            catdrop.DataTextField = "cat_name";
            catdrop.DataValueField = "cat_id";
            catdrop.DataBind();
            catdrop.Items.Insert(0, "--- Select Category ---");
        }

    }

    public void load_unit_drop()
    {
        unit_masterDAL umDAL = new unit_masterDAL();
        DataSet ds = umDAL.get_unit_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            umdrop.DataSource = ds;
            umdrop.DataTextField = "um_name";
            umdrop.DataValueField = "um_id";
            umdrop.DataBind();
            umdrop.Items.Insert(0, "--- Select Unit ---");
        }
    }


    public void load_grid_for_list()
    {
        String id = Request.QueryString["prd_id"].ToString();
        product_masterBAL pmBAL = new product_masterBAL();
        pmBAL.prdm_id = Convert.ToInt32(id);

        product_masterDAL pmDAL = new product_masterDAL();
        DataSet ds = pmDAL.get_product_variation_list(pmBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {
            Repeater1.DataSource = ds;
            Repeater1.DataBind();
        }
        else
        {
            Repeater1.DataSource = null;
            Repeater1.DataBind();
        }
    }


    public void load_gst_drop()
    {
        product_masterDAL pmDAL = new product_masterDAL();
        DataSet ds = pmDAL.get_product_tax_code();
        if (ds.Tables[0].Rows.Count > 0)
        {

            drpgstno.DataSource = ds;
            drpgstno.DataTextField = "txcd_name";
            drpgstno.DataValueField = "txcd_id";
            drpgstno.DataBind();
            drpgstno.Items.Insert(0, "--- Select GST Name ---");
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {

                if (Request.QueryString["prd_id"] != null && Request.QueryString["prd_id"].ToString() != null)
                {
                    load_brand_drop();
                    load_category_drop();
                    load_grid_for_list();
                    load_unit_drop();
                    load_gst_drop();

                    product_masterBAL pmBAL = new product_masterBAL();
                    pmBAL.prdm_id = Convert.ToInt16(Request.QueryString["prd_id"].ToString());
                    product_masterDAL pmDAL = new product_masterDAL();
                    DataSet ds = pmDAL.get_product_details(pmBAL);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtfprdname.Text = ds.Tables[0].Rows[0]["prdm_name"].ToString();
                        drbrand.SelectedValue = ds.Tables[0].Rows[0]["prdm_brand_id"].ToString();
                        catdrop.SelectedValue = ds.Tables[0].Rows[0]["prdm_cat_id"].ToString();
                        prdPhoto.ImageUrl = ds.Tables[0].Rows[0]["prdm_photo_link"].ToString();
                        hfoldname.Value = ds.Tables[0].Rows[0]["prdm_photo_link"].ToString(); ;
                        umdrop.SelectedValue = ds.Tables[0].Rows[0]["um_id"].ToString();
                        drpgstno.SelectedValue = ds.Tables[0].Rows[0]["txcd_id"].ToString();
                    }



                }


                else
                {
                    Response.Redirect("Admin_Registration.aspx");
                }


            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }


    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnview")
        {

            int id = Convert.ToInt32(e.CommandArgument.ToString());
            Response.Redirect("Edit_Product_Variation.aspx?prd_var_id=" + id);
        }

    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        txtfprdname.Enabled = true;
        drbrand.Enabled = true;
        catdrop.Enabled = true;

        umdrop.Enabled = true;
        drpgstno.Enabled = true;
        btnupdate.Visible = false;

        btnaddvariation.Visible = true;
    }

    protected void btnaddvariation_Click(object sender, EventArgs e)
    {

        product_masterBAL pmBAL = new product_masterBAL();
        pmBAL.prdm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());
        pmBAL.prdm_name = txtfprdname.Text.Trim().ToUpper();
        pmBAL.prdm_brand_id = drbrand.SelectedIndex;

        if (fuimportfile.HasFile)
        {
            Guid a = Guid.NewGuid();
            hfextension.Value = Path.GetExtension(fuimportfile.FileName);
            hffilenewname.Value = a.ToString() + hfextension.Value;
            fuimportfile.SaveAs(Server.MapPath("~/product_photo/" + hffilenewname.Value));
            pmBAL.prdm_photo_link = "~/product_photo/" + hffilenewname.Value;

        }
        else
        {
            pmBAL.prdm_photo_link = hfoldname.Value;
        }

        pmBAL.prdm_unit_id = umdrop.SelectedIndex;
        pmBAL.prdm_cat_id = catdrop.SelectedIndex;
        pmBAL.prdm_logrid = Convert.ToInt32(Session["login"].ToString());
        pmBAL.prdm_logdt = System.DateTime.Now;

        product_masterDAL pmDAL = new product_masterDAL();
        pmDAL.update_product_details(pmBAL);

        //Response.Write("<script>alert('Product Details Update Successfully.');window.location.href='View_Update_Product_Variation.aspx?prd_id" + Convert.ToInt32(Request.QueryString["prd_id"].ToString()) + "';</script>");
        Response.Write("<script>alert('Product Details Update Successfully.');window.location.href='View_Update_Product_Variation.aspx?prd_id=" + Convert.ToInt32(Request.QueryString["prd_id"].ToString()) + "';</script>");

    }



    protected void btnchngprdvar_Click(object sender, EventArgs e)
    {

        Response.Redirect("Add_Product_Variation.aspx?prd_id=" + Convert.ToInt32(Request.QueryString["prd_id"].ToString()));

    }
}