﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Voucher_Category : System.Web.UI.Page
{
    void loadvouchergrid()
    {
        voucher_masterDAL vmDAL = new voucher_masterDAL();
        DataSet ds = vmDAL.get_voucher_name_master_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeatervoucher.DataSource = ds;
            gridrepeatervoucher.DataBind();
        }
        else
        {
            gridrepeatervoucher.DataSource = ds;
            gridrepeatervoucher.DataBind();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                loadvouchergrid();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }



    protected void btnsave_Click(object sender, EventArgs e)
    {
        voucher_name_masterBAL vnmBAL = new voucher_name_masterBAL();
        if (hfvnmid.Value.ToString() == "")
        {
            vnmBAL.vm_id = 0;
        }
        else if (hfvnmid.Value.ToString() != "")
        {
            vnmBAL.vm_id = Convert.ToInt32(hfvnmid.Value.ToString());
        }

        vnmBAL.vm_name = txtvoucher.Text.Trim().Replace('-','~').ToUpper();
        vnmBAL.vm_insrid = Convert.ToInt32(Session["login"].ToString());
        vnmBAL.vm_insdt = System.DateTime.Now;
        vnmBAL.vm_logrid = Convert.ToInt32(Session["login"].ToString());
        vnmBAL.vm_logdt = System.DateTime.Now;


        voucher_masterDAL vmDAL = new voucher_masterDAL();
        int val = vmDAL.insert_voucher_name_master(vnmBAL);

        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('Voucher Name Already Exists Please Enter Another.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('Succesfully Inserted Voucher.')</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('Voucher Updated Successfully.')</script>");
        }

        hfvnmid.Value = "";
        txtvoucher.Text = "";
        loadvouchergrid();

    }


    protected void gridrepeatervoucher_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnview")
        {
            voucher_name_masterBAL vnmBAL = new voucher_name_masterBAL();
            vnmBAL.vm_id = Convert.ToInt16(e.CommandArgument.ToString());

            voucher_masterDAL vmDAL = new voucher_masterDAL();
            DataSet ds = vmDAL.get_voucher_name_master_for_edit(vnmBAL);

            if (ds.Tables[0].Rows.Count > 0)
            {
                hfvnmid.Value = ds.Tables[0].Rows[0]["vm_id"].ToString();
                txtvoucher.Text = ds.Tables[0].Rows[0]["vm_name"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Sorry data does not exists');</script>");

            }
        }
        else if (e.CommandName.ToString() == "btndelete")
        {
            string id = e.CommandArgument.ToString();
            voucher_name_masterBAL vnmBAL = new voucher_name_masterBAL();
            vnmBAL.vm_id = Convert.ToInt32(id);

            voucher_masterDAL vmDAL = new voucher_masterDAL();
            vmDAL.delete_voucher_name_master(vnmBAL);
            loadvouchergrid();
        }
    }


}