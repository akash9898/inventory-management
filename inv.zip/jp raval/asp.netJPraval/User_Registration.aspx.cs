﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class User_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["aduid"] != null && Request.QueryString["aduid"].ToString() != "")
                {
                    admin_userBAL aduBAL = new admin_userBAL();
                    aduBAL.admn_usr_id = Convert.ToInt16(Request.QueryString["aduid"].ToString());
                    admin_userDAL aduDAL = new admin_userDAL();
                    DataSet ds = aduDAL.get_admin_user_for_view(aduBAL);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        btnregister.Visible = false;
                        btnregister.Text = "Update";
                        btnupdate.Visible = true;
                        txtfirstname.Text = ds.Tables[0].Rows[0]["admn_usr_first_name"].ToString();
                        txtmiddlename.Text = ds.Tables[0].Rows[0]["admn_usr_father_name"].ToString();
                        txtsurname.Text = ds.Tables[0].Rows[0]["admn_usr_sur_name"].ToString();
                        txtctn.Text = ds.Tables[0].Rows[0]["admn_usr_mobile_no"].ToString();
                        txtemail.Text = ds.Tables[0].Rows[0]["admn_usr_email"].ToString();
                        if (ds.Tables[0].Rows[0]["admn_usr_gender"].ToString() == "Male")
                        {
                            rdomale.Checked = true;
                        }
                        else if (ds.Tables[0].Rows[0]["admn_usr_gender"].ToString() == "Female")
                        {
                            rdofemale.Checked = true;
                        }

                        drrole.Text = ds.Tables[0].Rows[0]["admn_usr_role"].ToString();

                        if (ds.Tables[0].Rows[0]["admn_usr_status"].ToString() == "Active")
                        {
                            rdoactive.Checked = true;
                        }
                        else if (ds.Tables[0].Rows[0]["admn_usr_status"].ToString() == "Deactive")
                        {
                            rdodeactive.Checked = true;
                        }
                        txtfirstname.Enabled = false;
                        txtmiddlename.Enabled = false;
                        txtsurname.Enabled = false;
                        txtctn.Enabled = false;
                        txtemail.Enabled = false;
                        //  rdomale.Checked = false;
                        //  rdofemale.Checked = false;
                        //  rdomarried.Checked = false;
                        //rdounmarried.Checked = false;
                        drrole.Enabled = false;
                    }
                }

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
        if (rdomale.Checked == false && rdofemale.Checked == false)
        {
            Response.Write("<script>alert('Select Gender');</script>");
        }
        else
        {
            admin_userBAL aduBAL = new admin_userBAL();

            if (Request.QueryString["aduid"] != null && Request.QueryString["aduid"].ToString() != "")
            {
                aduBAL.admn_usr_id = Convert.ToInt16(Request.QueryString["aduid"].ToString());
            }
            else
            {
                aduBAL.admn_usr_id = 0;
            }
            aduBAL.admn_usr_first_name = txtfirstname.Text.Trim().Replace('-',' ');
            aduBAL.admn_usr_father_name = txtmiddlename.Text.Trim().Replace('-',' ');
            aduBAL.admn_usr_sur_name = txtsurname.Text.Trim().Replace('-',' ');
            if (rdomale.Checked == true)
            {
                aduBAL.admn_usr_gender = "Male";
            }
            else if (rdofemale.Checked == true)
            {
                aduBAL.admn_usr_gender = "Female";
            }
            aduBAL.admn_usr_mobile_no = txtctn.Text.Trim().Replace('-',' ');
            aduBAL.admn_usr_email = txtemail.Text.Trim().Replace('-',' ');
            aduBAL.admn_usr_password = txtpassword.Text.Trim().Replace('-',' ');


            aduBAL.admn_usr_role = Convert.ToInt16(drrole.SelectedItem.Value);
            if (rdoactive.Checked == true)
            {
                aduBAL.admn_usr_status = 1;
            }
            else if (rdodeactive.Checked == true)
            {
                aduBAL.admn_usr_status = 0;
            }
            aduBAL.admn_usr_last_login = System.DateTime.Now;
            aduBAL.admn_usr_last_logout = System.DateTime.Now;
            aduBAL.admn_usr_insdt = System.DateTime.Now;
            aduBAL.admn_usr_insrid = Convert.ToInt16(Session["login"].ToString());
            aduBAL.admn_usr_logdt = System.DateTime.Now;
            aduBAL.admn_usr_logrid = Convert.ToInt16(Session["login"].ToString());
            admin_userDAL aduDAL = new admin_userDAL();
            int ret_val = aduDAL.admin_user_addupdate(aduBAL);
            if (ret_val == 0)
            {
                Response.Write("<script>alert('Please wait server is busy right now.');</script>");
            }
            else if (ret_val == 1 || ret_val == 2 || ret_val == 3)
            {
                Response.Write("<script>alert('This system admin user member already exists in database try to change moblie number or email address');</script>");
            }

            else if (ret_val == 4)
            {
                Response.Write("<script>alert('System admin user member added successfully');</script>");
                txtfirstname.Text = "";
                txtmiddlename.Text = "";
                txtsurname.Text = "";
                txtctn.Text = "";
                txtemail.Text = "";
                txtpassword.Text = "";
                txtrepassword.Text = "";
                rdomale.Checked = false;
                rdofemale.Checked = false;
                drrole.SelectedIndex = 0;
            }
            else if (ret_val == 5)
            {
                Response.Write("<script>alert('System admin user member data updated successfully');</script>");
                txtfirstname.Text = "";
                txtmiddlename.Text = "";
                txtsurname.Text = "";
                txtctn.Text = "";
                txtemail.Text = "";
                txtpassword.Text = "";
                txtrepassword.Text = "";
                rdomale.Checked = false;
                rdofemale.Checked = false;
                drrole.SelectedIndex = 0;
            }
        }
    }
    protected void btnupdate_Click1(object sender, EventArgs e)
    {
        btnregister.Visible = true;
        btnupdate.Visible = false;
        txtfirstname.Enabled = true;
        txtmiddlename.Enabled = true;
        txtsurname.Enabled = true;
        txtctn.Enabled = true;
        txtemail.Enabled = true;
        //     rdomale.Checked = true;
        //   rdofemale.Checked = true;
        //   rdomarried.Checked = true;
        //   rdounmarried.Checked = true;
        drrole.Enabled = true;
    }
}