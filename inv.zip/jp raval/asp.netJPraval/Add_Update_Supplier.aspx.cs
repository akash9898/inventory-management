﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Supplier : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["login_admin"] != null)
            {
                if (Request.QueryString["supid"] != null && Request.QueryString["supid"].ToString() != "")
                {
                    supplier_masterBAL supBAL = new supplier_masterBAL();
                    supBAL.sup_id = Convert.ToInt32(Request.QueryString["supid"].ToString());

                    supplier_masterDAL supDAL = new supplier_masterDAL();
                    DataSet ds = supDAL.get_supplier_list_for_edit(supBAL);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtfirstname.Text = ds.Tables[0].Rows[0]["sup_first_name"].ToString();
                        txtmiddlename.Text = ds.Tables[0].Rows[0]["sup_middle_name"].ToString();
                        txtlastname.Text = ds.Tables[0].Rows[0]["sup_last_name"].ToString();
                        txtbusinessname.Text = ds.Tables[0].Rows[0]["sup_business_name"].ToString();
                        txtgstno.Text = ds.Tables[0].Rows[0]["sup_gst_no"].ToString();
                        txtprimaryctn.Text = ds.Tables[0].Rows[0]["sup_primary_ctn"].ToString();
                        txtsecondctn.Text = ds.Tables[0].Rows[0]["sup_second_ctn"].ToString();
                        txtthirdctn.Text = ds.Tables[0].Rows[0]["sup_third_ctn"].ToString();
                        txtemail.Text = ds.Tables[0].Rows[0]["sup_email"].ToString();
                        txtaddress.Text = ds.Tables[0].Rows[0]["sup_address"].ToString();
                        txtctvlg.Text = ds.Tables[0].Rows[0]["sup_city_village"].ToString();
                        txtpincode.Text = ds.Tables[0].Rows[0]["sup_pincode"].ToString();
                    }
                    txtfirstname.Enabled = false;
                    txtmiddlename.Enabled = false;
                    txtlastname.Enabled = false;
                    txtbusinessname.Enabled = false;
                    txtgstno.Enabled = false;
                    txtemail.Enabled = false;
                    txtprimaryctn.Enabled = false;
                    txtsecondctn.Enabled = false;
                    txtthirdctn.Enabled = false;
                    txtaddress.Enabled = false;
                    txtctvlg.Enabled = false;
                    txtpincode.Enabled = false;

                    btnupdate.Visible = true;
                    btnregister.Visible = false;
                }
            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
        supplier_masterBAL supBAL = new supplier_masterBAL();

        if (Request.QueryString["supid"] != null && Request.QueryString["supid"].ToString() != "")
        {
            supBAL.sup_id = Convert.ToInt32(Request.QueryString["supid"].ToString());
        }
        else
        {
            supBAL.sup_id = 0;

        }

        supBAL.sup_first_name = txtfirstname.Text.Trim().Replace('-',' ');
        supBAL.sup_middle_name = txtmiddlename.Text.Trim().Replace('-',' ');
        supBAL.sup_last_name = txtmiddlename.Text.Trim().Replace('-',' ');
        supBAL.sup_business_name = txtbusinessname.Text.Trim().Replace('-',' ');
        supBAL.sup_gst_no = txtgstno.Text.Trim().Replace('-',' ');
        supBAL.sup_primary_ctn = txtprimaryctn.Text;
        supBAL.sup_second_ctn = txtsecondctn.Text;
        supBAL.sup_third_ctn = txtthirdctn.Text;
        supBAL.sup_email = txtemail.Text.Trim().Replace('-',' ');
        supBAL.sup_address = txtaddress.Text.Trim().Replace('-',' ');
        supBAL.sup_city_village = txtctvlg.Text.Trim().Replace('-',' ');
        supBAL.sup_pincode = txtpincode.Text;
        supBAL.sup_insrid = Convert.ToInt32(Session["login"].ToString());
        supBAL.sup_insdt = System.DateTime.Now;
        supBAL.sup_logrid = Convert.ToInt32(Session["login"].ToString());
        supBAL.sup_logdt = System.DateTime.Now;

        supplier_masterDAL supDAL = new supplier_masterDAL();
        int ret_sup_val = supDAL.insert_into_supplier(supBAL);

        if (ret_sup_val == 2)
        {
            Response.Write("<script>alert('Supplier Details Inserted Succesfully!');window.location.href='Add_Update_Supplier.aspx';</script>");
        }

        else if (ret_sup_val == 1)
        {
            Response.Write("<script>alert('Supplier Business Name Alredy Exists!')</script>");
        }
        else if (ret_sup_val == 3)
        {
            Response.Write("<script>alert('Supplier Details Updated Succesfully!');window.location.href='Supplier_List.aspx';</script>");
        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        txtfirstname.Enabled = true;
        txtmiddlename.Enabled = true;
        txtlastname.Enabled = true;
        txtbusinessname.Enabled = true;
        txtgstno.Enabled = true;
        txtemail.Enabled = true;
        txtprimaryctn.Enabled = true;
        txtsecondctn.Enabled = true;
        txtthirdctn.Enabled = true;
        txtaddress.Enabled = true;
        txtctvlg.Enabled = true;
        txtpincode.Enabled = true;

        btnupdate.Visible = false;
        btnregister.Visible = true;
        btnregister.Text = "Update";
    }
}