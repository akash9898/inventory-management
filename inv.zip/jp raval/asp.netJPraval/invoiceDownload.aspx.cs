﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.xml;
using System.Xml;
using iTextSharp.text.html.simpleparser;
using System.IO;

public partial class invoiceDownload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {

                if (Request.QueryString["purchase_sales_billid"].ToString() == "1")
                {

                    prdsalesbill.Visible = false;

                    supplier_purchse_bill_masterBAL spbmBAL = new supplier_purchse_bill_masterBAL();
                    spbmBAL.spb_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                    DataSet ds = sbmDAL.get_supplier_product_list(spbmBAL);


                    lblname.Text = ds.Tables[0].Rows[0]["sup_business_name"].ToString();
                    lblmobileno.Text = ds.Tables[0].Rows[0]["sup_primary_ctn"].ToString();

                    //amount paid,all and unpaid
                    totalbill.Text = ds.Tables[0].Rows[0]["spb_total_amount"].ToString();
                    paidamolbl.Text = ds.Tables[0].Rows[0]["paidamount"].ToString();
                    unpaidamolbl.Text = ds.Tables[0].Rows[0]["unpaidamount"].ToString();




                    supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                    spbdBAL.spbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    bill_paymentDAL bpDAL = new bill_paymentDAL();
                    DataSet ds1 = bpDAL.get_product_list_bill_payment(spbdBAL);

                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        rptprdpurchasebill.DataSource = ds1;
                        rptprdpurchasebill.DataBind();
                    }
                    else
                    {
                        rptprdpurchasebill.DataSource = null;
                        rptprdpurchasebill.DataBind();
                    }

                    //pdf wokring
                    

                }

                else if (Request.QueryString["purchase_sales_billid"].ToString() == "2")
                {

                    prdpurchasebill.Visible = false;

                    sales_bill_masterBAL sbmBAL = new sales_bill_masterBAL();
                    sbmBAL.sbm_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
                    DataSet ds = sbmDAL.get_customer_product_list(sbmBAL);


                    lblname.Text = ds.Tables[0].Rows[0]["cust_first_name"].ToString() + ' ' + ds.Tables[0].Rows[0]["cust_middle_name"].ToString() + ' ' + ds.Tables[0].Rows[0]["cust_last_name"].ToString();
                    lblmobileno.Text = ds.Tables[0].Rows[0]["cust_primary_ctn"].ToString();


                    //amount paid,all and unpaid
                    totalbill.Text = ds.Tables[0].Rows[0]["sbm_total_amount"].ToString();
                    paidamolbl.Text = ds.Tables[0].Rows[0]["paidamount"].ToString();
                    unpaidamolbl.Text = ds.Tables[0].Rows[0]["unpaidamount"].ToString();


                    //sales bill dedtails for bill id
                    sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
                    sbdBAL.sbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    //sales bill payment product list
                    DataSet dsprd = sbmDAL.get_product_list_bill_payment(sbdBAL);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        rptprdsalesbill.DataSource = dsprd;
                        rptprdsalesbill.DataBind();
                    }
                    else
                    {
                        rptprdsalesbill.DataSource = null;
                        rptprdsalesbill.DataBind();
                    }


                    //for hide payment button and show list button
                    int total_amount = Convert.ToInt32(ds.Tables[0].Rows[0]["sbm_total_amount"].ToString());
                    int paid_amount = Convert.ToInt32(ds.Tables[0].Rows[0]["paidamount"].ToString());

                    if (total_amount == paid_amount)
                    {
                        //hide payment  date and label
                        paymentlbl.Visible = false;




                    }
                                    
                }

                string attachment = "attachment; filename=" + "abc" + ".pdf";

                //StyleSheet style = new StyleSheet();
                //style.LoadStyle();

                //Response.ClearContent();
                //Response.AddHeader("content-disposition", attachment);
                //Response.ContentType = "application/pdf";
                //StringWriter s_tw = new StringWriter();
                //HtmlTextWriter h_textw = new HtmlTextWriter(s_tw);
                //h_textw.AddStyleAttribute("font-size", "7pt");
                //h_textw.AddStyleAttribute("color", "Black");
                //Panel1.RenderControl(h_textw);//Name of the Panel
                //Document doc = new Document();
                //doc = new Document(PageSize.A4, 5, 5, 15, 5);
                //FontFactory.GetFont("Verdana", 80);
                //PdfWriter.GetInstance(doc, Response.OutputStream);
                //doc.Open();
                //StringReader s_tr = new StringReader(s_tw.ToString());
                //HTMLWorker html_worker = new HTMLWorker(doc);

                //html_worker.Parse(s_tr);
                ///*var logo = iTextSharp.text.Image.GetInstance(Server.MapPath("certi.png"));
                //logo.SetAbsolutePosition(0, 0);
                //doc.Add(logo);*/
                //doc.Close();
                //Response.Write(doc);
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }





    protected void rptprdsalesbill_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void rptprdpurchasebill_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}