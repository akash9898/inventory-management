﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class idle_selling_price : System.Web.UI.Page
{
    void gridsellingprice()
    {
        idle_selling_priceDAL ispDAL = new idle_selling_priceDAL();
        DataSet ds = ispDAL.get_product_variation_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeatersellingpricelist.DataSource = ds;
            gridrepeatersellingpricelist.DataBind();
        }
        else
        {
            gridrepeatersellingpricelist.DataSource = null;
            gridrepeatersellingpricelist.DataBind();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Session["login"] != null)
            {
                gridsellingprice();
            }
        }
    }

    protected void gridrepeatersellingpricelist_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnviewedit")
        {
            Response.Redirect("edit_idle_selling_price.aspx?prd_id=" + Convert.ToInt16(e.CommandArgument.ToString()));
        }
    }
}