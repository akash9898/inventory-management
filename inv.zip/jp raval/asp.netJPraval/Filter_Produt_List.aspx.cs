﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Filter_Produt_List : System.Web.UI.Page
{
    void loadproductgrid()
    {
        product_masterDAL pmDAL = new product_masterDAL();
        //DataSet ds = pmDAL.get_product_list();
        DataSet ds = pmDAL.get_product_list_for_filter();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["login"] != null)
        //{
        if (!IsPostBack)
        {
            loadproductgrid();
            //if(Request.QueryString[""]) 
        }
        //}
        //else
        //{
        //    Response.Redirect("User_Login.aspx");
        //}
    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnadd")
        {
            string id = e.CommandArgument.ToString();
            Response.Redirect("Edit_Product_Variation.aspx?prd_id=" + id);

        }
        else if (e.CommandName.ToString() == "btnview")
        {
            string id = e.CommandArgument.ToString();
            Response.Redirect("View_Update_Product_Variation.aspx?prd_id=" + id);
        }
    }
}