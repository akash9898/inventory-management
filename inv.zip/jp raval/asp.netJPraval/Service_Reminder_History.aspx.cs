﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Service_Reminder_History : System.Web.UI.Page
{
  

    public DateTime NextMonth(DateTime date, int days, int months)
    {
        if (date.Day != DateTime.DaysInMonth(date.Year, date.Month))
            return date.AddDays(days).AddMonths(months);

        else
            return date.AddDays(days).AddMonths(months).AddDays(-1);
    }
    void fill_service_man()
    {
        admin_userDAL aduDAL = new admin_userDAL();
        DataSet ds = aduDAL.get_service_man_list();
        foreach (RepeaterItem item in rptr_todays_all_reminder.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {

                var dropserviceman = (DropDownList)item.FindControl("drserviceman");
                dropserviceman.DataSource = ds;
                dropserviceman.DataTextField = "serviceman_name";
                dropserviceman.DataValueField = "admn_usr_id";
                dropserviceman.DataBind();
                dropserviceman.Items.Insert(0, "---Service Person ---");
                dropserviceman.Items[0].Value = "0";
            }
        }

        foreach (RepeaterItem item in rptr_get_assigned_reminder.Items)
        {

            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {

                var dropserviceman = (DropDownList)item.FindControl("drserviceman");
                dropserviceman.DataSource = ds;
                dropserviceman.DataTextField = "serviceman_name";
                dropserviceman.DataValueField = "admn_usr_id";
                dropserviceman.DataBind();
                dropserviceman.Items.Insert(0, "---Service Person ---");
                dropserviceman.Items[0].Value = "0";
            }
        }
    }
    public void fill_not_assigned_services(string startdat, string enddate)
    {
        service_date_masterBAL sdmBAL = new service_date_masterBAL();
        sdmBAL.sdtm_start_date = startdat;
        sdmBAL.sdtm_end_date = enddate;
        service_details_masterDAL sdmDAL = new service_details_masterDAL();
        DataSet ds = sdmDAL.get_not_assigned_service(sdmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptr_todays_all_reminder.DataSource = ds;
            rptr_todays_all_reminder.DataBind();
        }
        else
        {
            rptr_todays_all_reminder.DataSource = null;
            rptr_todays_all_reminder.DataBind();
        }
    }

    public void fill_assigned_services(string startdat, string enddate)
    {
        service_date_masterBAL sdmBAL = new service_date_masterBAL();
        sdmBAL.sdtm_start_date = startdat;
        sdmBAL.sdtm_end_date = enddate;
        if (Session["login_service"] != null)
        {
            sdmBAL.sdtm_service_man_id = Convert.ToInt16(Session["login_service"].ToString());
        }
        else if (Session["login_service"] != null)
        {
            sdmBAL.sdtm_service_man_id = 0;
        }
        sdmBAL.sdtm_status = 1;
        service_details_masterDAL sdmDAL = new service_details_masterDAL();
        DataSet ds = sdmDAL.get_assigned_service(sdmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptr_get_assigned_reminder.DataSource = ds;
            rptr_get_assigned_reminder.DataBind();
            if (Session["login_service"] != null)
            {
                columnserviceperson.Visible = false;
                foreach (RepeaterItem item in rptr_todays_all_reminder.Items)
                {
                    if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                    {
                        var btnassign = (Button)item.FindControl("btnassign");
                        var dropserviceman = (DropDownList)item.FindControl("drserviceman");
                        dropserviceman.Visible = false;
                        btnassign.Visible = false;
                    }
                }
            }
        }
        else
        {
            rptr_get_assigned_reminder.DataSource = null;
            rptr_get_assigned_reminder.DataBind();
        }
    }

    public void fill_closed_services(string startdat, string enddate)
    {
        service_date_masterBAL sdmBAL = new service_date_masterBAL();
        if (Session["login_service"] != null)
        {
            sdmBAL.sdtm_service_man_id = Convert.ToInt16(Session["login_service"].ToString());

        }
        else if (Session["login_service"] != null)
        {
            sdmBAL.sdtm_service_man_id = 0;
        }
        sdmBAL.sdtm_start_date = startdat;
        sdmBAL.sdtm_end_date = enddate;
        sdmBAL.sdtm_status = 2;
        service_details_masterDAL sdmDAL = new service_details_masterDAL();
        DataSet ds = sdmDAL.get_assigned_service(sdmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            get_closed_services.DataSource = ds;
            get_closed_services.DataBind();
        }
        else
        {
            get_closed_services.DataSource = null;
            get_closed_services.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["login_admin"] != null)
            {

                pnladminreminder.Visible = true;
            }

            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }
    protected void rptr_todays_all_reminder_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        HiddenField hfcustctn = (HiddenField)e.Item.FindControl("hfcustctn");
        HiddenField hfservicemanctn = (HiddenField)e.Item.FindControl("hfservicemanctn");

        HiddenField hfcustname = (HiddenField)e.Item.FindControl("hfcustname");

        DropDownList drdropsrvicman = (DropDownList)e.Item.FindControl("drserviceman");
        if (e.CommandName == "btnassign")
        {
            if (drdropsrvicman.SelectedItem.Value != "0")
            {
                service_date_masterBAL sdmBAL = new service_date_masterBAL();
                sdmBAL.sdtm_id = Convert.ToInt16(e.CommandArgument.ToString());
                sdmBAL.sdtm_service_man_id = Convert.ToInt16(drdropsrvicman.SelectedItem.Value);
                sdmBAL.sdtm_logrid = Convert.ToInt16(Session["login"]);
                sdmBAL.sdtm_logdt = System.DateTime.Now;
                service_date_masterDAL sdmDAL = new service_date_masterDAL();
                int rval = Convert.ToInt16(sdmDAL.update_service_man_details(sdmBAL));
                if (rval == 1)
                {
                  
                    Response.Write("<script>alert('Service person successfully assigned');</script>");
                }
                string startdate = "", enddate = "";
                if (txtstartdate.Text != "")
                {
                    DateTime dtformated = Convert.ToDateTime(txtenddate.Text + " " + "00:00:00");
                    startdate = dtformated.ToString("yyyy/MM/dd");
                }
                if (txtenddate.Text != "")
                {
                    DateTime dtformated = Convert.ToDateTime(txtenddate.Text + " " + "00:00:00");
                    enddate = dtformated.ToString("yyyy/MM/dd");
                }
                fill_not_assigned_services(startdate, enddate);
                fill_assigned_services(startdate, enddate);
                fill_closed_services(startdate, enddate);

                fill_service_man();

            }
            else
            {
                Response.Write("<script>alert('Please choose the service engineer');</script>");
            }

        }
    }
    protected void rptr_get_assigned_reminder_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        HiddenField hfsdtmid = (HiddenField)e.Item.FindControl("hfsdtmid");
        HiddenField hfcustname = (HiddenField)e.Item.FindControl("hfcustname");
        HiddenField hfcustctn = (HiddenField)e.Item.FindControl("hfcustctn");
        HiddenField hfservicemanctn = (HiddenField)e.Item.FindControl("hfservicemanctn");
        Button btnassign = (Button)e.Item.FindControl("btnassign");
        DropDownList drserviceman = (DropDownList)e.Item.FindControl("drserviceman");
        Button btncloseservice = (Button)e.Item.FindControl("btncloseservice");
        if (e.CommandName.ToString() == "btnassign")
        {
            if (btnassign.Text == "Assign to other")
            {
                btnassign.Text = "Assign";
                drserviceman.Visible = true;
            }
            else if (btnassign.Text == "Assign")
            {
                service_date_masterBAL sdmBAL = new service_date_masterBAL();
                sdmBAL.sdtm_id = Convert.ToInt16(e.CommandArgument.ToString());
                DropDownList drdropsrvicman = (DropDownList)e.Item.FindControl("drserviceman");
                sdmBAL.sdtm_service_man_id = Convert.ToInt16(drdropsrvicman.SelectedItem.Value);
                sdmBAL.sdtm_logrid = Convert.ToInt16(Session["login"]);
                sdmBAL.sdtm_logdt = System.DateTime.Now;
                service_date_masterDAL sdmDAL = new service_date_masterDAL();
                int rval = Convert.ToInt16(sdmDAL.update_service_man_details(sdmBAL));
                if (rval == 1)
                {
                   
                   
                    Response.Write("<script>alert('Service person successfully assigned');</script>");
                }
                btnassign.Text = "Assign to other";
                drserviceman.Visible = false;

            }

        }
        if (e.CommandName.ToString() == "btncloseservice")
        {
            TextBox txtcode = (TextBox)e.Item.FindControl("txtcode");
            btnassign.Visible = false;
            EncDec enc = new EncDec();

            //if (btncloseservice.Text == "Close")
            //{
            //    txtcode.Visible = true;
            //    string otp = enc.otpgenerate();
            //    HttpCookie advertdata = new HttpCookie("advertdataid");
            //    advertdata.Values.Add("advertdataval", enc.Encrypt(otp));
            //    advertdata.Expires = System.DateTime.Now.AddDays(1);
            //    Response.Cookies.Add(advertdata);
          
            //    btncloseservice.Text = "Vefity";

            //}
            //else if (btncloseservice.Text == "Vefity")
            //{
            //    if (enc.Encrypt(txtcode.Text.ToString().Trim()) == Request.Cookies["advertdataid"].Values["advertdataval"].ToString())
            //    {
            HiddenField hfservicedate = (HiddenField)e.Item.FindControl("hfservicedate");
            HiddenField hfrepeat = (HiddenField)e.Item.FindControl("hfrepeat");
            HiddenField hfcustid = (HiddenField)e.Item.FindControl("hfcustid");
            HiddenField hfsdmid = (HiddenField)e.Item.FindControl("hfsdmid");
            HiddenField hfsrvcdate = (HiddenField)e.Item.FindControl("hfsrvcdate");
            HiddenField hfday = (HiddenField)e.Item.FindControl("hfday");
            HiddenField hfmonth = (HiddenField)e.Item.FindControl("hfmonth");
            HiddenField hfyear = (HiddenField)e.Item.FindControl("hfyear");


            service_date_masterBAL sdmBAL = new service_date_masterBAL();
            sdmBAL.sdtm_id = Convert.ToInt16(e.CommandArgument.ToString());
            sdmBAL.sdtm_cust_id = Convert.ToInt16(hfcustid.Value);
            sdmBAL.sdtm_sdm_id = Convert.ToInt16(hfsdmid.Value);
            sdmBAL.sdtm_repeat = Convert.ToInt16(hfrepeat.Value);
            sdmBAL.sdtm_date = NextMonth(Convert.ToDateTime(hfsrvcdate.Value), Convert.ToInt16(hfday.Value), Convert.ToInt16(hfmonth.Value)).ToString("yyyy-MM-dd")+" 00:00:00";
            sdmBAL.sdtm_logrid = Convert.ToInt16(Session["login"]);
            sdmBAL.sdtm_logdt = System.DateTime.Now;
            service_date_masterDAL sdmDAL = new service_date_masterDAL();
            int rval = Convert.ToInt16(sdmDAL.update_service_to_close(sdmBAL));
            if (rval == 1)
            {
              
                Response.Write("<script>alert('Service closed successfully');</script>");
            }

            btncloseservice.Text = "Close";
            //    }
            //    else
            //    {
            //        Response.Write("<script>alert('Entered OTP does not match please re-enter OTP');</script>");
            //    }
            //}
        }
        string startdate = "", enddate = "";
        if (txtstartdate.Text != "")
        {
            DateTime dtformated = Convert.ToDateTime(txtenddate.Text + " " + "00:00:00");
            startdate = dtformated.ToString("yyyy/MM/dd");
        }
        if (txtenddate.Text != "")
        {
            DateTime dtformated = Convert.ToDateTime(txtenddate.Text + " " + "00:00:00");
            enddate = dtformated.ToString("yyyy/MM/dd");
        }
        fill_not_assigned_services(startdate, enddate);
        fill_assigned_services(startdate, enddate);
        fill_closed_services(startdate, enddate);

        fill_service_man();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        string startdate = "", enddate = "";
        if (txtstartdate.Text != "")
        {
            //DateTime dtformated = Convert.ToDateTime(txtstartdate.Text + " " + "00:00:00");
            //startdate = dtformated.ToString("yyyy/MM/dd");
            startdate = txtstartdate.Text;
        }
        if (txtenddate.Text != "")
        {
            //DateTime dtformated = Convert.ToDateTime(txtenddate.Text + " " + "00:00:00");
            //enddate = dtformated.ToString("yyyy/MM/dd");
            enddate = txtenddate.Text;
        }
        fill_not_assigned_services(startdate, enddate);
        fill_assigned_services(startdate, enddate);
        fill_closed_services(startdate, enddate);
        fill_service_man();
    }
    protected void drserviceman_SelectedIndexChanged(object sender, EventArgs e)
    {
        foreach (RepeaterItem item in rptr_todays_all_reminder.Items)
        {
            var drserviceman = (DropDownList)item.FindControl("drserviceman");
            var hfservicemanctn = (HiddenField)item.FindControl("hfservicemanctn");
            admin_userBAL aduBAL = new admin_userBAL();
            if (drserviceman.SelectedItem.Value != "0")
            {
                aduBAL.admn_usr_id = Convert.ToInt16(drserviceman.SelectedItem.Value.ToString());
                admin_userDAL aduDAL = new admin_userDAL();
                hfservicemanctn.Value = aduDAL.get_admin_user_contact_no(aduBAL);
            }


        }
    }
    protected void drserviceman_SelectedIndexChanged1(object sender, EventArgs e)
    {
        foreach (RepeaterItem item in rptr_todays_all_reminder.Items)
        {
            var drserviceman = (DropDownList)item.FindControl("drserviceman");
            var hfservicemanctn = (HiddenField)item.FindControl("hfservicemanctn");
            admin_userBAL aduBAL = new admin_userBAL();
            if (drserviceman.SelectedItem.Value != "0")
            {
                aduBAL.admn_usr_id = Convert.ToInt16(drserviceman.SelectedItem.Value.ToString());
                admin_userDAL aduDAL = new admin_userDAL();
                hfservicemanctn.Value = aduDAL.get_admin_user_contact_no(aduBAL);
            }
        }
    }
}