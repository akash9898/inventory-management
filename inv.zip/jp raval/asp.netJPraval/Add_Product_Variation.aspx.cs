﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Add_Product_Variation : System.Web.UI.Page
{
    public void filldrplist()
    {
        product_specification_masterBAL psmBAL = new product_specification_masterBAL();
        psmBAL.prd_spe_prdm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());

        add_product_variationDAL apvDAL = new add_product_variationDAL();
        DataSet ds = apvDAL.get_other_category_list_edit_page(psmBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {
            drpprdvarlist.DataSource = ds;
            drpprdvarlist.DataTextField = "oth_cat_name";
            drpprdvarlist.DataValueField = "oth_cat_id";
            drpprdvarlist.DataBind();
            drpprdvarlist.Items.Insert(0, "--- Select Other Category ---");
            drpprdvarlist.Items[0].Value = "0";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                filldrplist();

                product_masterBAL pmBAL = new product_masterBAL();
                pmBAL.prdm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());

                add_product_variationDAL apvDAL = new add_product_variationDAL();
                DataSet ds = apvDAL.get_product_name_variation_list(pmBAL);

                prdvarname.Text = ds.Tables[0].Rows[0]["prdm_name"].ToString();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    rptprdvarname.DataSource = ds;
                    rptprdvarname.DataBind();
                }
                else
                {
                    rptprdvarname.DataSource = null;
                    rptprdvarname.DataBind();
                }
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");

        }
    }

    protected void rptprdvarname_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

        if (e.CommandName == "btndelete")
        {

            product_specification_masterBAL psmBAL = new product_specification_masterBAL();
            psmBAL.prd_spe_prdm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());
            psmBAL.prd_spe_oth_cat_id = Convert.ToInt32(e.CommandArgument.ToString());

            add_product_variationDAL apvDAL = new add_product_variationDAL();
            apvDAL.detete_from_product_other_category_edit_page(psmBAL);

            // Response.Write("<script>alert('Other Category Deleted Succesfully.')</script>");

            Response.Redirect("Add_Product_Variation.aspx?prd_id=" + Convert.ToInt32(Request.QueryString["prd_id"].ToString()));
        }

    }

    protected void btnaddothcat_Click(object sender, EventArgs e)
    {
        product_masterBAL pmBAL = new product_masterBAL();
        pmBAL.prdm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());

        add_product_variationDAL apvDAL = new add_product_variationDAL();
        DataSet ds = apvDAL.get_product_variation_id(pmBAL);

        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            product_specification_masterBAL psmBAL = new product_specification_masterBAL();
            psmBAL.prd_spe_prdm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());
            psmBAL.prd_spe_pvnm_id = Convert.ToInt32(ds.Tables[0].Rows[i]["pssm_pvnm_id"].ToString());
            psmBAL.prd_spe_oth_cat_id = Convert.ToInt32(drpprdvarlist.SelectedValue.ToString());
            psmBAL.prd_spe_oth_cat_id = Convert.ToInt32(drpprdvarlist.SelectedValue.ToString());
            psmBAL.prd_spe_oth_cat_val = "Not Specified";
            psmBAL.prd_spe_insrid = Convert.ToInt32(Session["login"].ToString());
            psmBAL.prd_spe_insdt = System.DateTime.Now;
            psmBAL.prd_spe_logrid = Convert.ToInt32(Session["login"].ToString());
            psmBAL.prd_spe_logdt = System.DateTime.Now;
            add_product_variationDAL apviDAL = new add_product_variationDAL();
            apviDAL.insert_into_product_specification_edit_page(psmBAL);
        }
        Response.Redirect("Add_Product_Variation.aspx?prd_id=" + Convert.ToInt32(Request.QueryString["prd_id"].ToString()));
        // Response.Write("<script>alert('Product Variation Name Added Succesfully!');window.location.href='Add_Product_Variation.aspx?prd_id=''" +  Convert.ToInt32(Request.QueryString["prd_id"].ToString())  + "'</script>");

    }

}