﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Filter_Customer : System.Web.UI.Page
{
    public void loadgridview()
    {
        customer_masterDAL cuDAL = new customer_masterDAL();
        DataSet ds = cuDAL.get_customer_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();

        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["data"] != null && Request.QueryString["data"].ToString() != "")
                {
                    Response.Write("<script>alert('Service contract data registered successfully');</script>");
                }
                loadgridview();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "btnview")
        {
            Response.Redirect("Add_Update_Cust_Details.aspx?cuid=" + e.CommandArgument.ToString());
        }

        else if (e.CommandName == "btndelete")
        {
            string id = e.CommandArgument.ToString();
            customer_masterBAL cmBAL = new customer_masterBAL();
            cmBAL.cust_id = Convert.ToInt32(id);
            customer_masterDAL cmDAL = new customer_masterDAL();
            cmDAL.delete_customer(cmBAL);
            loadgridview();
        }
        else if (e.CommandName == "btnservice")
        {
            Response.Redirect("Add_Service_Detail.aspx?cuid=" + e.CommandArgument.ToString());
        }
    }
}