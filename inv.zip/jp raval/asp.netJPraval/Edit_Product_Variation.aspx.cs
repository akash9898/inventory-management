﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;




public partial class Edit_Product_Variation : System.Web.UI.Page
{
    //dropdown current financial year
    //public void loadfinyear()
    //{
    //    financial_year_masterDAL fymDAL = new financial_year_masterDAL();
    //    DataSet ds = fymDAL.get_all_financial_year();

    //    if (ds.Tables[0].Rows.Count > 0)
    //    {
    //        drpfinyear.DataSource = ds;
    //        drpfinyear.DataTextField = "financial_year";
    //        drpfinyear.DataValueField = "financial_year_id";
    //        drpfinyear.DataBind();
    //        drpfinyear.Items.Insert(0, "--- Select Financial Year ---");
    //        drpfinyear.Items[0].Value = "0";
    //    }
    //    else
    //    {
    //        drpfinyear.DataSource = null;
    //        drpfinyear.DataBind();
    //    }

    //}

    //select current financial year
    public void load_current_financial_year()
    {
        financial_year_masterDAL fmDAL = new financial_year_masterDAL();
        string value = fmDAL.get_current_financial_year();
        //drpfinyear.Items.FindByText(value).Selected = true;
        drpfinyear.Text = value.ToString();


    }


    public void load_brand_drop()
    {
        brand_masterDAL brd_masDAL = new brand_masterDAL();
        DataSet ds = brd_masDAL.get_brand_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drbrand.DataSource = ds;
            drbrand.DataTextField = "bm_name";
            drbrand.DataValueField = "bm_rid";
            drbrand.DataBind();
            drbrand.Items.Insert(0, "--- Select Brand ---");
        }
    }

    public void load_category_drop()
    {
        category_masterDAL catDAL = new category_masterDAL();
        DataSet ds = catDAL.get_category_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            catdrop.DataSource = ds;
            catdrop.DataTextField = "cat_name";
            catdrop.DataValueField = "cat_id";
            catdrop.DataBind();
            catdrop.Items.Insert(0, "--- Select Category ---");
        }

    }



    public void load_product_specification()
    {
        if (Request.QueryString["prd_id"] != null && Request.QueryString["prd_id"].ToString() != null)
        {
            int id = Convert.ToInt16(Request.QueryString["prd_id"].ToString());

            product_specification_masterBAL psmBAL = new product_specification_masterBAL();
            psmBAL.prd_spe_prdm_id = id;

            product_specification_masterDAL psmDAL = new product_specification_masterDAL();
            DataSet ds = psmDAL.get_product_spefication(psmBAL);

            if (ds.Tables[0].Rows.Count > 0)
            {
                gridrepeater.DataSource = ds;
                gridrepeater.DataBind();
            }
            else
            {

                gridrepeater.DataSource = null;
                gridrepeater.DataBind();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }


    public void load_product_specification_for_edit()
    {
        if (Request.QueryString["prd_var_id"] != null && Request.QueryString["prd_var_id"].ToString() != null)
        {
            int prd_var_id = Convert.ToInt16(Request.QueryString["prd_var_id"].ToString());

            product_masterBAL pmBAL = new product_masterBAL();
            pmBAL.prd_spe_pvnm_id = prd_var_id;

            product_masterDAL pmDAL = new product_masterDAL();
            DataSet ds = pmDAL.fill_product_variation_for_edit1(pmBAL);


            Repeater2.DataSource = ds;
            Repeater2.DataBind();



        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }



    public void load_tax_code()
    {
        product_masterDAL pmDAL = new product_masterDAL();
        DataSet ds = pmDAL.get_product_tax_code();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drptaxcode.DataSource = ds;
            drptaxcode.DataTextField = "txcd_name";
            drptaxcode.DataValueField = "txcd_id";
            drptaxcode.DataBind();
            drptaxcode.Items.Insert(0, "--- Select Tax Code ---");
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                //loadfinyear();
                load_current_financial_year();
                if (Request.QueryString["prd_id"] != null && Request.QueryString["prd_id"].ToString() != null)
                {
                  
                    addvarientgrid.Visible = true;
                    load_brand_drop();
                    load_category_drop();
                    load_product_specification();
                    load_tax_code();


                    //load_grid_for_list();
                    product_masterBAL pmBAL = new product_masterBAL();
                    pmBAL.prdm_id = Convert.ToInt16(Request.QueryString["prd_id"].ToString());
                    product_masterDAL pmDAL = new product_masterDAL();
                    DataSet ds = pmDAL.get_product_details(pmBAL);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtfprdname.Text = ds.Tables[0].Rows[0]["prdm_name"].ToString();
                        drbrand.SelectedValue = ds.Tables[0].Rows[0]["prdm_brand_id"].ToString();
                        catdrop.SelectedValue = ds.Tables[0].Rows[0]["prdm_cat_id"].ToString();
                        prdPhoto.ImageUrl = ds.Tables[0].Rows[0]["prdm_photo_link"].ToString();

                    }


                }

                else if (Request.QueryString["prd_var_id"] != null && Request.QueryString["prd_var_id"].ToString() != null)
                {

                    updatevarientgrid.Visible = true;
                    load_brand_drop();
                    load_category_drop();
                    load_product_specification_for_edit();
                    load_tax_code();

                    int pro_var_id = Convert.ToInt16(Request.QueryString["prd_var_id"].ToString());

                    product_masterBAL pmBAL = new product_masterBAL();
                    pmBAL.prvm_id = pro_var_id;

                    product_masterDAL pmDAL = new product_masterDAL();
                    DataSet ds = pmDAL.get_product_variaton_list_for_edit(pmBAL);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtfprdname.Text = ds.Tables[0].Rows[0]["prdm_name"].ToString();
                        drbrand.SelectedValue = ds.Tables[0].Rows[0]["prdm_brand_id"].ToString();
                        catdrop.SelectedValue = ds.Tables[0].Rows[0]["prdm_cat_id"].ToString();
                        prdPhoto.ImageUrl = ds.Tables[0].Rows[0]["prdm_photo_link"].ToString();

                        txtprdvar.Text = ds.Tables[0].Rows[0]["prvm_product_variation_name"].ToString();
                        drpfinyear.Text = ds.Tables[0].Rows[0]["pssm_financial_year"].ToString();
                        txtqty.Text = ds.Tables[0].Rows[0]["pssm_starting_qty"].ToString();
                        txtprice.Text = ds.Tables[0].Rows[0]["pssm_starting_price"].ToString();

                        drptaxcode.SelectedValue = ds.Tables[0].Rows[0]["prvm_tax_code_id"].ToString();

                        txtlowstock.Text = ds.Tables[0].Rows[0]["prvm_low_stock"].ToString();
                    }

                }

                else
                {
                    Response.Redirect("Admin_Registration.aspx");
                }


            }

        }


        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void btnaddvariation_Click(object sender, EventArgs e)
    {
        product_masterBAL pmBAL = new product_masterBAL();
        pmBAL.prvm_prdm_id = Convert.ToInt16(Request.QueryString["prd_id"].ToString());
        pmBAL.prvm_product_variation_name = txtprdvar.Text.Trim().ToUpper().Replace('-', '~');
        pmBAL.prvm_tax_code_id = Convert.ToInt32(drptaxcode.SelectedItem.Value);
        pmBAL.prvm_low_stock = Convert.ToInt32(txtlowstock.Text);
        pmBAL.prvm_insrid = Convert.ToInt16(Session["login"].ToString());
        pmBAL.prvm_insdt = System.DateTime.Now;
        pmBAL.prvm_logrid = Convert.ToInt16(Session["login"].ToString());
        pmBAL.prvm_logdt = System.DateTime.Now;
        pmBAL.pssm_starting_qty = Convert.ToInt16(txtqty.Text);
        pmBAL.pssm_starting_price = Convert.ToInt16(txtprice.Text);
        pmBAL.pssm_financial_year = Convert.ToString(drpfinyear.Text);
        pmBAL.pssm_insrid = Convert.ToInt16(Session["login"].ToString());
        pmBAL.pssm_insdt = System.DateTime.Now;
        pmBAL.pssm_logrid = Convert.ToInt16(Session["login"].ToString());
        pmBAL.pssm_logdt = System.DateTime.Now;
        product_masterDAL pmDAL = new product_masterDAL();
        String val = pmDAL.add_product_variation(pmBAL);
        string[] ret_val = val.Split('|');
        foreach (RepeaterItem ri in gridrepeater.Items)
        {
            Int32 prd_var_id = Convert.ToInt16(ret_val[1]);

            Label l1 = ri.FindControl("cnamelbl") as Label;
            TextBox txt = ri.FindControl("txtothcatvalue") as TextBox;
            HiddenField hfd = ri.FindControl("hfothercatid") as HiddenField;

            product_specification_masterBAL pssmBAL = new product_specification_masterBAL();



            pssmBAL.prd_spe_prdm_id = Convert.ToInt16(Request.QueryString["prd_id"].ToString());
            pssmBAL.prd_spe_pvnm_id = prd_var_id;
            pssmBAL.prd_spe_oth_cat_id = Convert.ToInt16(hfd.Value);
            pssmBAL.prd_spe_oth_cat_val = txt.Text.Replace('-', '~');
            pssmBAL.prd_spe_insrid = Convert.ToInt16(Session["login"].ToString());
            pssmBAL.prd_spe_insdt = System.DateTime.Now;
            pssmBAL.prd_spe_logrid = Convert.ToInt16(Session["login"].ToString());
            pssmBAL.prd_spe_logdt = System.DateTime.Now;


            product_specification_masterDAL pssmDAL = new product_specification_masterDAL();
            pssmDAL.insert_new_product_specification_Edit_page(pssmBAL);

        }

        if (ret_val[0] == "1")
        {
            Response.Write("<script>alert('Product Variation Name Already Exists.');</script>");
        }
        else if (ret_val[0] == "2")
        {
            Response.Write("<script>alert('Product Variation Name Inserted Succesfully.');window.location.href='Filter_Produt_List.aspx';</script>");
        }
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }


    protected void editgridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void btnupdateprdvar_Click(object sender, EventArgs e)
    {

        product_masterBAL pmBAL = new product_masterBAL();
        pmBAL.prvm_id = Convert.ToInt16(Request.QueryString["prd_var_id"].ToString());
        pmBAL.prvm_product_variation_name = txtprdvar.Text.Replace('-', '~');
        pmBAL.pssm_starting_qty = Convert.ToInt16(txtqty.Text);
        pmBAL.pssm_starting_price = Convert.ToInt16(txtprice.Text);
        pmBAL.pssm_financial_year = drpfinyear.Text;
        pmBAL.prvm_tax_code_id = Convert.ToInt32(drptaxcode.SelectedItem.Value);
        //low stock price update
        pmBAL.prvm_low_stock = Convert.ToInt32(txtlowstock.Text);

        product_masterDAL pmDAL = new product_masterDAL();
        pmDAL.update_product(pmBAL);

        foreach (RepeaterItem ri in Repeater2.Items)
        {
            Int32 prd_var_id = Convert.ToInt16(Request.QueryString["prd_var_id"].ToString());
            Label l1 = ri.FindControl("lbledittxt") as Label;
            TextBox txt = ri.FindControl("txteditothcatval") as TextBox;
            HiddenField hfd = ri.FindControl("hfothercatid") as HiddenField;
            HiddenField hf_prd_specification_id = ri.FindControl("hf_prd_specification_id") as HiddenField;


            product_specification_masterBAL pssmBAL = new product_specification_masterBAL();
            pssmBAL.prd_spe_id = Convert.ToInt16(hf_prd_specification_id.Value);
            pssmBAL.prd_spe_pvnm_id = prd_var_id;
            pssmBAL.prd_spe_oth_cat_id = Convert.ToInt16(hfd.Value);
            pssmBAL.prd_spe_oth_cat_val = txt.Text.Trim().Replace('-', '~');

            pssmBAL.prd_spe_logrid = Convert.ToInt16(Session["login"].ToString());
            pssmBAL.prd_spe_logdt = System.DateTime.Now;


            product_specification_masterDAL pssmDAL = new product_specification_masterDAL();
            pssmDAL.insert_new_product_specification_Edit_page(pssmBAL);

        }


        Response.Write("<script>alert('Product Variation Updated Succesfully');</script>");
    }


}
