﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Add_Update_Category : System.Web.UI.Page
{
    void loadgridview()
    {
        category_masterDAL camDAL = new category_masterDAL();
        DataSet ds = camDAL.get_category_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                loadgridview();


            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {

        category_masterBAL catBAL = new category_masterBAL();
        if (hfcatid.Value.ToString() == "")
        {
            catBAL.cat_id = 0;
        }
        else if (hfcatid.Value.ToString() != "")
        {
            catBAL.cat_id = Convert.ToInt16(hfcatid.Value.ToString());
        }
        catBAL.cat_name = txtcategory.Text.Trim().Replace('-','~').ToUpper();
        catBAL.cat_insrid = Convert.ToInt32(Session["login"].ToString());
        catBAL.cat_ldt = System.DateTime.Now;
        catBAL.cat_logrid = Convert.ToInt32(Session["login"].ToString());
        catBAL.cat_logdt = System.DateTime.Now;
        category_masterDAL catDAL = new category_masterDAL();
        int val = catDAL.insert_category(catBAL);

        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('Category Alredy Exists Please Enter Another Category.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('Succesfully Inserted Category.')</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('Category Updated Successfully.')</script>");
        }

        hfcatid.Value = "";
        txtcategory.Text = "";
        loadgridview();

    }



    protected void gridrepeater_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {

        if (e.CommandName.ToString() == "btnview")
        {
            category_masterBAL catmBAL = new category_masterBAL();
            catmBAL.cat_id = Convert.ToInt16(e.CommandArgument.ToString());
            category_masterDAL catmDAL = new category_masterDAL();
            DataSet ds = catmDAL.get_category_for_edit(catmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfcatid.Value = ds.Tables[0].Rows[0]["cat_id"].ToString();
                txtcategory.Text = ds.Tables[0].Rows[0]["cat_name"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Sorry data does not exists');</script>");
            }


        }
        //else if (e.CommandName.ToString() == "btndelete")
        //{
        //    string id = e.CommandArgument.ToString();
        //    category_masterBAL catBAL = new category_masterBAL();
        //    catBAL.cat_id = Convert.ToInt32(id);
        //    category_masterDAL catDAL = new category_masterDAL();
        //    catDAL.delete_category(catBAL);
        //    loadgridview();

        //}

    }
}