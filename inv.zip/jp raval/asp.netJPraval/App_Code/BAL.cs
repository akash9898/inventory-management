﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class financial_year_masterBAL
{
    public int financial_year_id { get; set; }
    public string financial_year { get; set; }
    public DateTime financial_year_insdt { get; set; }
    public int financial_year_rid { get; set; }
    public DateTime financial_year_logdt { get; set; }
    public int financial_year_logrid { get; set; }

}
public class admin_userBAL
{
    public int admn_usr_id { get; set; }
    public string admn_usr_first_name { get; set; }
    public string admn_usr_father_name { get; set; }
    public string admn_usr_sur_name { get; set; }
    public string admn_usr_gender { get; set; }
    public string admn_usr_mobile_no { get; set; }
    public string admn_usr_email { get; set; }
    public string admn_usr_password { get; set; }
    public int admn_usr_role { get; set; }
    public int admn_usr_status { get; set; }
    public DateTime admn_usr_last_login { get; set; }
    public DateTime admn_usr_last_logout { get; set; }
    public DateTime admn_usr_insdt { get; set; }
    public int admn_usr_insrid { get; set; }
    public DateTime admn_usr_logdt { get; set; }
    public int admn_usr_logrid { get; set; }
}
public class category_masterBAL
{
    public int cat_id { get; set; }
    public string cat_name { get; set; }
    public int cat_insrid { get; set; }
    public DateTime cat_ldt { get; set; }
    public int cat_logrid { get; set; }
    public DateTime cat_logdt { get; set; }
}
public class customer_masterBAL
{
    public int cust_id { get; set; }
    public string cust_first_name { get; set; }
    public string cust_middle_name { get; set; }
    public string cust_last_name { get; set; }
    public string cust_busines_name { get; set; }
    public string cust_primary_ctn { get; set; }
    public string cust_whatsapp_ctn { get; set; }
    public string cust_second_ctn { get; set; }
    public string cust_third_ctn { get; set; }
    public string cust_gender { get; set; }
    public string cust_email { get; set; }
    public string cust_address { get; set; }
    public string cust_city_village { get; set; }
    public int cust_pincode { get; set; }
    public int cust_insrid { get; set; }
    public DateTime cust_insdt { get; set; }
    public int cust_logrid { get; set; }
    public DateTime cust_logdt { get; set; }
}
public class other_cat_masterBAL
{
    public int oth_id { get; set; }
    public string oth_name { get; set; }
    public int oth_is_unit { get; set; }
    public int oth_unit_id { get; set; }
    public int oth_insrid { get; set; }
    public DateTime oth_insdt { get; set; }
    public int oth_logrid { get; set; }
}
public class unit_masterBAL
{
    public int um_id { get; set; }
    public string um_name { get; set; }
    public int um_insrid { get; set; }
    public DateTime um_insdt { get; set; }
    public int um_logrid { get; set; }
    public DateTime um_logdt { get; set; }
}

public class brand_masterBAL
{
    public int bm_rid { get; set; }
    public string bm_name { get; set; }
    public int bm_insrid { get; set; }
    public DateTime bm_insdt { get; set; }
    public int bm_logrid { get; set; }
    public DateTime bm_logdt { get; set; }
}

public class other_category_masterBAL
{
    public int oth_cat_id { get; set; }
    public string oth_cat_name { get; set; }
    public byte oth_cat_is_unit { get; set; }
    public int oth_cat_unit_id { get; set; }
    public int oth_cat_insrid { get; set; }
    public DateTime oth_cat_insdt { get; set; }
    public int oth_cat_logrid { get; set; }
    public DateTime oth_cat_logdt { get; set; }
}
public class service_details_masterBAL
{
    public int sdm_id { get; set; }
    public int sdm_cust_id { get; set; }
    public int sdm_repeat { get; set; }
    public string sdm_comment { get; set; }
    public int sdm_continuity { get; set; }
    public int sdm_interval_days { get; set; }
    public int sdm_interval_months { get; set; }
    public int sdm_interval_year { get; set; }

    public int sdm_insrid { get; set; }
    public DateTime sdm_insdt { get; set; }
    public int sdm_logrid { get; set; }
    public DateTime sdm_logdt { get; set; }
    public int sdtm_id { get; set; }
    public int sdtm_cust_id { get; set; }
    public int sdtm_sdm_id { get; set; }
    public string sdtm_date { get; set; }
    public int sdtm_status { get; set; }
    public int sdtm_insrid { get; set; }
    public DateTime sdtm_insdt { get; set; }
    public int sdtm_logrid { get; set; }
    public DateTime sdtm_logdt { get; set; }

}
public class service_date_masterBAL
{
    public int sdtm_id { get; set; }
    public int sdtm_cust_id { get; set; }
    public int sdtm_sdm_id { get; set; }
    public int sdtm_service_man_id { get; set; }
    public string sdtm_date { get; set; }
    public string sdtm_start_date { get; set; }
    public string sdtm_end_date { get; set; }
    public int sdtm_status { get; set; }
    public int sdtm_repeat { get; set; }
    public int sdtm_insrid { get; set; }
    public DateTime sdtm_insdt { get; set; }
    public int sdtm_logrid { get; set; }
    public DateTime sdtm_logdt { get; set; }
}
public class tax_code_masterBAL
{
    public int txcd_id { get; set; }
    public string txcd_name { get; set; }
    public float txcd_cgst { get; set; }
    public float txcd_sgst { get; set; }
    public float txcd_igst { get; set; }
    public int txcd_insrid { get; set; }
    public DateTime txcd_insdt { get; set; }
    public int txcd_logrid { get; set; }
    public DateTime txcd_logdt { get; set; }
}
public class supplier_masterBAL
{
    public int sup_id { get; set; }
    public string sup_first_name { get; set; }
    public string sup_middle_name { get; set; }
    public string sup_last_name { get; set; }
    public string sup_business_name { get; set; }
    public string sup_gst_no { get; set; }
    public string sup_primary_ctn { get; set; }
    public string sup_second_ctn { get; set; }
    public string sup_third_ctn { get; set; }
    public string sup_email { get; set; }
    public string sup_address { get; set; }
    public string sup_city_village { get; set; }
    public string sup_pincode { get; set; }
    public int sup_insrid { get; set; }
    public DateTime sup_insdt { get; set; }
    public int sup_logrid { get; set; }
    public DateTime sup_logdt { get; set; }
}

//Jimish Classes Starrts
public class bill_detailsBAL
{
    public int bld_id { get; set; }
    public int bld_bill_id { get; set; }
    public int bld_product_id { get; set; }
    public int bld_quentity { get; set; }
    public int bld_total { get; set; }
    public DateTime bld_insdt { get; set; }
    public int bld_insrid { get; set; }
    public DateTime bld_logdt { get; set; }
    public int bld_logrid { get; set; }
}
//Product master
public class product_masterBAL
{
    //Product_MasterBAL
    public int prdm_id { get; set; }
    public string prdm_name { get; set; }
    public int prdm_cat_id { get; set; }
    public int prdm_brand_id { get; set; }
    public int prdm_unit_id { get; set; }
    public string prdm_photo_link { get; set; }
    public int prdm_insrid { get; set; }
    public DateTime prdm_ldt { get; set; }
    public int prdm_logrid { get; set; }
    public DateTime prdm_logdt { get; set; }

    //product_variationname_masterBAL
    public int prvm_id { get; set; }
    public int prvm_prdm_id { get; set; }
    public string prvm_product_variation_name { get; set; }
    public int prvm_tax_code_id { get; set; }
    //new added column for low stock
    public int prvm_low_stock { get; set; }
    public int prvm_insrid { get; set; }
    public DateTime prvm_insdt { get; set; }
    public DateTime prvm_logdt { get; set; }
    public int prvm_logrid { get; set; }


    //product_starting_StockMasterBAL

    public int pssm_id { get; set; }
    public int pssm_prdm_id { get; set; }
    public int pssm_pvnm_id { get; set; }
    public int pssm_starting_qty { get; set; }
    public int pssm_starting_price { get; set; }
    public string pssm_financial_year { get; set; }
    public int pssm_insrid { get; set; }
    public DateTime pssm_insdt { get; set; }
    public int pssm_logrid { get; set; }
    public DateTime pssm_logdt { get; set; }


    public int prd_spe_id { get; set; }
    public int prd_spe_prdm_id { get; set; }
    public int prd_spe_pvnm_id { get; set; }
    public int prd_spe_oth_cat_id { get; set; }
    public string prd_spe_oth_cat_val { get; set; }
    public int prd_spe_insrid { get; set; }
    public DateTime prd_spe_insdt { get; set; }
    public int prd_spe_logrid { get; set; }
    public DateTime prd_spe_logdt { get; set; }


    //idle selling price
    public int idle_sell_id { get; set; }
    public int idle_prod_var_id { get; set; }
    public string idle_prod_var_name { get; set; }
    public int idle_prod_selling_price { get; set; }
    public int idle_insrid { get; set; }
    public DateTime idle_insdt { get; set; }
    public int idle_logrid { get; set; }
    public DateTime idle_logdt { get; set; }

}

public class product_specification_masterBAL
{
    //product_specification_MasterBAL
    public int prd_spe_id { get; set; }
    public int prd_spe_prdm_id { get; set; }
    public int prd_spe_pvnm_id { get; set; }
    public int prd_spe_oth_cat_id { get; set; }
    public string prd_spe_oth_cat_val { get; set; }
    public int prd_spe_insrid { get; set; }
    public DateTime prd_spe_insdt { get; set; }
    public int prd_spe_logrid { get; set; }
    public DateTime prd_spe_logdt { get; set; }

}

//supplier purchse bill master
public class supplier_purchse_bill_masterBAL
{
    public int spb_id { get; set; }
    //  public int spb_sales_purchase_id { get; set; }
    public int spb_supplier_id { get; set; }
    public string spb_purchase_bill_id { get; set; }
    public DateTime spb_purchase_date { get; set; }
    //billing total amount
    public float spb_total_amount { get; set; }
    //billing actuall amount

    public float spb_total_actual_amount { get; set; }

    public int spb_status { get; set; }

    //financial year
    public string spb_financial_year { get; set; }

    //mode of payment
    public int spb_mode_of_payment { get; set; }

    public int spb_insrid { get; set; }
    public DateTime spb_insdt { get; set; }
    public int spb_logrid { get; set; }
    public DateTime spb_logdt { get; set; }
    public string startdate { get; set; }
    public string enddate { get; set; }


}
//supplier purchase bill details
public class supplier_purchase_bill_detailBAL
{
    public int spbd_id { get; set; }
    public int spbd_bill_id { get; set; }
    public int spbd_product_id { get; set; }

    //product billing price
    public float spbd_product_price { get; set; }
    //product actual price
    public float spbd_product_actual_price { get; set; }


    //product billing quentity
    public int spbd_quentity { get; set; }
    //product actual quentity
    public int spbd_actual_quentity { get; set; }

    //product billing total
    public float spbd_total { get; set; }
    //product actuall total
    public float spbd_actual_total { get; set; }

    //discount
    public float spbd_discount { get; set; }
    //discount price
    public float spbd_discount_amount { get; set; }


    //gst values
    public float spbd_cgst { get; set; }
    public float spbd_sgst { get; set; }
    public float spbd_igst { get; set; }


    public int spbd_insrid { get; set; }
    public DateTime spbd_insdt { get; set; }
    public int spbd_logrid { get; set; }
    public DateTime spbd_logdt { get; set; }


}
//supplier purchase bill payment
public class supplier_purchse_bill_paymentBAL
{
    public int spbp_id { get; set; }
    public int spbp_bill_id { get; set; }
    public int spbp_mod_of_payment { get; set; }
    public DateTime spbp_date_of_payment { get; set; }
    public int spbp_amount { get; set; }
    public int spbp_insrid { get; set; }
    public DateTime spbp_insdt { get; set; }
    public int spbp_logrid { get; set; }
    public DateTime spbp_logdt { get; set; }
}
//sales bill master
public class sales_bill_masterBAL
{
    public int sbm_id { get; set; }
    public int customer_id { get; set; }
    public string sbm_sales_bill_id { get; set; }
    public DateTime sbm_sales_date { get; set; }
    public float sbm_total_amount { get; set; }
    public float sbm_total_actual_amount { get; set; }
    public int sbm_status { get; set; }
    public string sbm_financial_year { get; set; }
    public int sbm_mode_of_payment { get; set; }
    public int sbm_insrid { get; set; }
    public DateTime sbm_insdt { get; set; }
    public int sbm_logrid { get; set; }
    public DateTime sbm_logdt { get; set; }
    public string startdate { get; set; }
    public string enddate { get; set; }

}
//sales bill details
public class sales_bill_detailBAL
{
    public int sbd_id { get; set; }
    public int sbd_bill_id { get; set; }
    public int sbd_product_id { get; set; }

    //product billing price
    public float sbd_product_price { get; set; }
    //product actual price
    public float sbd_product_actual_price { get; set; }


    //product billing quentity
    public int sbd_quentity { get; set; }
    //product actual quentity
    public int sbd_actual_quentity { get; set; }

    //product billing total
    public float sbd_total { get; set; }
    //product actuall total
    public float sbd_actual_total { get; set; }

    //discount
    public float sbd_discount { get; set; }
    //discount price
    public float sbd_discount_amount { get; set; }


    //gst values
    public float sbd_cgst { get; set; }
    public float sbd_sgst { get; set; }
    public float sbd_igst { get; set; }


    public int sbd_insrid { get; set; }
    public DateTime sbd_insdt { get; set; }
    public int sbd_logrid { get; set; }
    public DateTime sbd_logdt { get; set; }

}
//sales bill payment
public class sales_bill_paymentBAL
{
    public int sbp_id { get; set; }
    public int sbp_bill_id { get; set; }
    public int sbp_mod_of_payment { get; set; }
    public DateTime sbp_date_of_payment { get; set; }
    public int sbp_amount { get; set; }
    public int sbp_insrid { get; set; }
    public DateTime sbp_insdt { get; set; }
    public int sbp_logrid { get; set; }
    public DateTime sbp_logdt { get; set; }
}

//mode  of payment
public class mode_of_paymentBAL
{
    public int mop_id { get; set; }
    public string mop_name { get; set; }
    public int mop_insrid { get; set; }
    public DateTime mop_insdt { get; set; }
    public int mop_logrid { get; set; }
    public DateTime mop_logdt { get; set; }

}

//productEntryclass store all data from supplier_purhcase_bill.aspx page 
public class productEntry
{

    public string pName { get; set; }
    public decimal pPrice { get; set; }
    public decimal pQty { get; set; }
    public decimal pTotal { get; set; }

    //product variation id
    public int productVarId { get; set; }

    public int supId { get; set; }
    public int mopVal { get; set; }
    public string gstVAL { get; set; }
    public string mopAMO { get; set; }
    public string purchase_date { get; set; }
    public string sup_billid { get; set; }
    public float product_price { get; set; }
    public string sup_name { get; set; }
    public string sup_mob_no { get; set; }
    public int sup_id { get; set; }

    //supplier bill details id
    public int spb_bill_det_id { get; set; }

    //supplier purchase bill master id
    public int spb_mas_id { get; set; }

    //gst values
    public float cgst { get; set; }
    public float sgst { get; set; }
    public float igst { get; set; }

    //purchase sales bill id
    public int purchase_sales_billid { get; set; }

    //customer bill details
    public string cust_name { get; set; }

    //actual price sum of product actual price
    public float product_actual_total_amount { get; set; }

    //actual price per product
    public float product_actual_price { get; set; }
    public int product_actual_quentity { get; set; }


    //discount
    public float product_discount { get; set; }
    //public float product_discount_amount { get; set; }

    public float product_each_price { get; set; }

    //customer id
    public int cust_id { get; set; }
    public string cust_mob_no { get; set; }

    //current financial year id
    public int financial_year_id { get; set; }

    //current financial year new added column for supplier purchase bill master
    public string financial_year { get; set; }

}
//voucher master
public class voucher_masterBAL
{
    public int vm_id { get; set; }
    public int vm_vnm_id { get; set; }
    public string vm_name { get; set; }
    public string vm_person_name { get; set; }
    public string vm_phone_num { get; set; }
    public int vm_amount { get; set; }
    public DateTime vm_date { get; set; }
    public string vm_financial_year { get; set; }
    public int vm_insrid { get; set; }
    public DateTime vm_insdt { get; set; }
    public int vm_logrid { get; set; }
    public DateTime vm_logdt { get; set; }
}
//voucher name master
public class voucher_name_masterBAL
{
    public int vm_id { get; set; }
    public string vm_name { get; set; }
    public int vm_insrid { get; set; }
    public DateTime vm_insdt { get; set; }
    public int vm_logrid { get; set; }
    public DateTime vm_logdt { get; set; }
}
//idle selling price
public class idle_selleing_priceBAL
{
    public int idle_sell_id { get; set; }
    public int idle_prod_var_id { get; set; }
    public string idle_prod_var_name { get; set; }
    public int idle_prod_selling_price { get; set; }
    public int idle_insrid { get; set; }
    public DateTime idle_insdt { get; set; }
    public int idle_logrid { get; set; }
    public DateTime idle_logdt { get; set; }
}

//change in product current financial year
public class product_starting_stock_masterBAL
{
    public int pssm_id { get; set; }
    public int pssm_prdm_id { get; set; }
    public int pssm_pvnm_id { get; set; }
    public int pssm_starting_qty { get; set; }
    public int pssm_starting_price { get; set; }
    public string pssm_financial_year { get; set; }
    public int pssm_insrid { get; set; }
    public DateTime pssm_insdt { get; set; }
    public int pssm_logrid { get; set; }
    public DateTime pssm_logdt { get; set; }
}
