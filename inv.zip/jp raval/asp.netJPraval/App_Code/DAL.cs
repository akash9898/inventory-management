﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;

public class connection
{
    public MySqlCommand cmd;
    public MySqlConnection con;
    public MySqlDataAdapter da;
    public DataSet ds;

    public void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }
}



public class admin_userDAL
{
    connection con = new connection();
    public int admin_user_addupdate(admin_userBAL aduBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("admin_user_add_update", con.con);
        con.cmd.CommandType = CommandType.StoredProcedure;
        con.cmd.Parameters.AddWithValue("@_admn_usr_id", aduBAL.admn_usr_id);
        con.cmd.Parameters.AddWithValue("@_admn_usr_first_name", aduBAL.admn_usr_first_name);
        con.cmd.Parameters.AddWithValue("@_admn_usr_father_name", aduBAL.admn_usr_father_name);
        con.cmd.Parameters.AddWithValue("@_admn_usr_sur_name", aduBAL.admn_usr_sur_name);
        con.cmd.Parameters.AddWithValue("@_admn_usr_gender", aduBAL.admn_usr_gender);
        con.cmd.Parameters.AddWithValue("@_admn_usr_mobile_no", aduBAL.admn_usr_mobile_no);
        con.cmd.Parameters.AddWithValue("@_admn_usr_email", aduBAL.admn_usr_email);
        con.cmd.Parameters.AddWithValue("@_admn_usr_password", aduBAL.admn_usr_password);
        con.cmd.Parameters.AddWithValue("@_admn_usr_role", aduBAL.admn_usr_role);
        con.cmd.Parameters.AddWithValue("@_admn_usr_status", aduBAL.admn_usr_status);
        con.cmd.Parameters.AddWithValue("@_admn_usr_last_login", aduBAL.admn_usr_last_login);
        con.cmd.Parameters.AddWithValue("@_admn_usr_last_logout", aduBAL.admn_usr_last_logout);
        con.cmd.Parameters.AddWithValue("@_admn_usr_insdt", aduBAL.admn_usr_insdt);
        con.cmd.Parameters.AddWithValue("@_admn_usr_insrid", aduBAL.admn_usr_insrid);
        con.cmd.Parameters.AddWithValue("@_admn_usr_logdt", aduBAL.admn_usr_logdt);
        con.cmd.Parameters.AddWithValue("@_admn_usr_logrid", aduBAL.admn_usr_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        con.cmd.Parameters.Add(returnval);
        con.cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.con.Close();
        con.con.Dispose();
        return id;
    }

    public DataSet get_service_man_list()
    {
        con.mycon();
        con.cmd = new MySqlCommand("select concat(admn_usr_first_name,' ',admn_usr_father_name,' ',admn_usr_sur_name) as serviceman_name,admn_usr_id from admin_registration_master where admn_usr_role=3", con.con);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }
    public string admin_user_login(admin_userBAL aduBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("system_admin_Login", con.con);
        con.cmd.CommandType = CommandType.StoredProcedure;
        con.cmd.Parameters.AddWithValue("@_admn_usr_mobile_no", aduBAL.admn_usr_mobile_no);
        con.cmd.Parameters.AddWithValue("@_admn_usr_password", aduBAL.admn_usr_password);

        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;

        MySqlParameter return_uid = new MySqlParameter("@_user_id", SqlDbType.Int);
        return_uid.Direction = ParameterDirection.Output;

        MySqlParameter returnrole = new MySqlParameter("@_user_role", SqlDbType.TinyInt);
        returnrole.Direction = ParameterDirection.Output;

        con.cmd.Parameters.Add(return_uid);
        con.cmd.Parameters.Add(returnval);
        con.cmd.Parameters.Add(returnrole);

        con.cmd.ExecuteNonQuery();

        int returnvalue = (int)returnval.Value;
        int uid = (int)return_uid.Value;
        int urole = 0;
        if (returnvalue == 2)
        {

            urole = (int)returnrole.Value;
        }
        con.con.Close();
        con.con.Dispose();
        return returnvalue + "|" + uid + "|" + urole;
    }

    public DataSet get_admin_user_list()
    {
        con.mycon();
        con.cmd = new MySqlCommand("select * from admin_registration_master", con.con);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }
    public string get_admin_user_contact_no(admin_userBAL aduBAl)
    {
        con.mycon();
        con.cmd = new MySqlCommand("select admn_usr_mobile_no from admin_registration_master where admn_usr_id=@aduid", con.con);
        con.cmd.Parameters.AddWithValue("@aduid", aduBAl.admn_usr_id);
        string mobileno = con.cmd.ExecuteScalar().ToString();
        con.con.Close();
        con.con.Dispose();
        return mobileno;
    }

    public DataSet get_admin_user_for_view(admin_userBAL aduBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("select * from admin_registration_master where admn_usr_id=@aduid", con.con);
        con.cmd.Parameters.AddWithValue("@aduid", aduBAL.admn_usr_id);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }


}

public class category_masterDAL
{
    connection con = new connection();

    public int insert_category(category_masterBAL catbal)
    {
        con.mycon();
        con.cmd = new MySqlCommand("add_update_category", con.con);
        con.cmd.CommandType = CommandType.StoredProcedure;
        con.cmd.Parameters.AddWithValue("@_cat_id", catbal.cat_id);
        con.cmd.Parameters.AddWithValue("@_cat_name", catbal.cat_name);
        con.cmd.Parameters.AddWithValue("@_cat_insrid", catbal.cat_insrid);
        con.cmd.Parameters.AddWithValue("@_cat_insdt", catbal.cat_ldt);
        con.cmd.Parameters.AddWithValue("@_cat_logrid", catbal.cat_logrid);
        con.cmd.Parameters.AddWithValue("@_cat_logdt", catbal.cat_logdt);
        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        con.cmd.Parameters.Add(sp);
        con.cmd.ExecuteNonQuery();
        Byte retval = Convert.ToByte(con.cmd.Parameters["_ret"].Value.ToString());
        con.con.Close();
        return retval;

    }

    public DataSet get_category_list()
    {
        con.mycon();
        con.cmd = new MySqlCommand("select cat_id,cat_name from category_master", con.con);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);


        con.con.Close();
        con.con.Dispose();
        return con.ds;

    }

    public DataSet get_category_for_edit(category_masterBAL catBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("select * from category_master where  cat_id=@cid", con.con);
        con.cmd.Parameters.AddWithValue("@cid", catBAL.cat_id);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }

    public void delete_category(category_masterBAL catBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("delete from category_master where cat_id=@cid", con.con);
        con.cmd.Parameters.AddWithValue("@cid", catBAL.cat_id);
        con.cmd.ExecuteNonQuery();
        con.con.Close();
        con.con.Dispose();
    }
}

public class unit_masterDAL : connection
{

    public int insert_unit(unit_masterBAL umBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_unit", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_um_id", umBAL.um_id);
        cmd.Parameters.AddWithValue("@_um_name", umBAL.um_name);
        cmd.Parameters.AddWithValue("@_um_insrid", umBAL.um_insrid);
        cmd.Parameters.AddWithValue("@_um_insdt", umBAL.um_insdt);
        cmd.Parameters.AddWithValue("@_um_logrid", umBAL.um_logrid);
        cmd.Parameters.AddWithValue("@_um_logdt", umBAL.um_logdt);
        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();
        Byte flg_value = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        return flg_value;
    }

    public DataSet get_unit_list()
    {

        mycon();
        cmd = new MySqlCommand("select * from unit_master", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    public DataSet get_unit_for_edit(unit_masterBAL umBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from unit_master where  um_id=@uid", con);
        cmd.Parameters.AddWithValue("@uid", umBAL.um_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public void delete_unit(unit_masterBAL umBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from unit_master where um_id=@uid", con);
        cmd.Parameters.AddWithValue("@uid", umBAL.um_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }


}

public class brand_masterDAL : connection
{
    public int insert_brand(brand_masterBAL bmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_brand", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_bm_rid", bmBAL.bm_rid);
        cmd.Parameters.AddWithValue("@_bm_name", bmBAL.bm_name);
        cmd.Parameters.AddWithValue("@_bm_insrid", bmBAL.bm_insrid);
        cmd.Parameters.AddWithValue("@_bm_insdt", bmBAL.bm_insdt);
        cmd.Parameters.AddWithValue("@_bm_logrid", bmBAL.bm_logrid);
        cmd.Parameters.AddWithValue("@_bm_logdt", bmBAL.bm_logdt);
        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();
        Byte flg_value = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        return flg_value;
    }

    public DataSet get_brand_list()
    {

        mycon();
        cmd = new MySqlCommand("select bm_rid,bm_name from brand_master", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    public DataSet get_brand_for_edit(brand_masterBAL bmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from brand_master where  bm_rid=@bid", con);
        cmd.Parameters.AddWithValue("@bid", bmBAL.bm_rid);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public void delete_brand(brand_masterBAL bmBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from brand_master where bm_rid=@bid", con);
        cmd.Parameters.AddWithValue("@bid", bmBAL.bm_rid);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }
}

public class customer_masterDAL : connection
{
    public int insert_customer(customer_masterBAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_customer", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_cust_id", cmBAL.cust_id);
        cmd.Parameters.AddWithValue("@_cust_first_name", cmBAL.cust_first_name);
        cmd.Parameters.AddWithValue("@_cust_middle_name", cmBAL.cust_middle_name);
        cmd.Parameters.AddWithValue("@_cust_last_name", cmBAL.cust_last_name);
        cmd.Parameters.AddWithValue("@_cust_busines_name", cmBAL.cust_busines_name);
        cmd.Parameters.AddWithValue("@_cust_primary_ctn", cmBAL.cust_primary_ctn);
        cmd.Parameters.AddWithValue("@_cust_whats_app_ctn", cmBAL.cust_whatsapp_ctn);
        cmd.Parameters.AddWithValue("@_cust_second_ctn", cmBAL.cust_second_ctn);
        cmd.Parameters.AddWithValue("@_cust_third_ctn", cmBAL.cust_third_ctn);
        cmd.Parameters.AddWithValue("@_cust_gender", cmBAL.cust_gender);
        cmd.Parameters.AddWithValue("@_cust_email", cmBAL.cust_email);
        cmd.Parameters.AddWithValue("@_cust_address", cmBAL.cust_address);
        cmd.Parameters.AddWithValue("@_cust_city_village", cmBAL.cust_city_village);
        cmd.Parameters.AddWithValue("@_cust_pincode", cmBAL.cust_pincode);
        cmd.Parameters.AddWithValue("@_cust_insrid", cmBAL.cust_insrid);
        cmd.Parameters.AddWithValue("@_cust_insdt", cmBAL.cust_insdt);
        cmd.Parameters.AddWithValue("@_cust_logrid", cmBAL.cust_logrid);
        cmd.Parameters.AddWithValue("@_cust_logdt", cmBAL.cust_logdt);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.Int);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;

    }

    public DataSet get_customer_list()
    {
        mycon();
        cmd = new MySqlCommand("select cust_id,cust_first_name,cust_middle_name,cust_last_name,cust_primary_ctn,cust_email from customer_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;

    }

    public DataSet get_customer_list_for_edit(customer_masterBAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from customer_master where cust_id=@cuid", con);
        cmd.Parameters.AddWithValue("@cuid", cmBAL.cust_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }




    public void delete_customer(customer_masterBAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from customer_master where cust_id=@cid", con);
        cmd.Parameters.AddWithValue("@cid", cmBAL.cust_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }
}

public class financial_year_masterDAL
{
    connection con = new connection();
    public string insert_financial_year(financial_year_masterBAL fnnclBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("insert into financial_year_master values (NULL,@acdmcy,@insdt,@rid,@ldt,@lrid)", con.con);
        con.cmd.Parameters.AddWithValue("@acdmcy", fnnclBAL.financial_year);
        con.cmd.Parameters.AddWithValue("@insdt", fnnclBAL.financial_year_insdt);
        con.cmd.Parameters.AddWithValue("@rid", fnnclBAL.financial_year_rid);
        con.cmd.Parameters.AddWithValue("@ldt", fnnclBAL.financial_year_logdt);
        con.cmd.Parameters.AddWithValue("@lrid", fnnclBAL.financial_year_logrid);
        con.cmd.ExecuteNonQuery();
        con.con.Close();
        con.con.Dispose();
        return "Inserted";
    }

    public string update_financial_year(financial_year_masterBAL fnnclBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("update financial_year_master set financial_year=@acdmcy, financial_year_logdt=@ldt, financial_year_logrid=@lrid where financial_year_id=@acdmyrid", con.con);
        con.cmd.Parameters.AddWithValue("@acdmyrid", fnnclBAL.financial_year_id);
        con.cmd.Parameters.AddWithValue("@acdmcy", fnnclBAL.financial_year);
        con.cmd.Parameters.AddWithValue("@insdt", fnnclBAL.financial_year_insdt);
        con.cmd.Parameters.AddWithValue("@rid", fnnclBAL.financial_year_rid);
        con.cmd.Parameters.AddWithValue("@ldt", fnnclBAL.financial_year_logdt);
        con.cmd.Parameters.AddWithValue("@lrid", fnnclBAL.financial_year_logrid);
        con.cmd.ExecuteNonQuery();
        con.con.Close();
        con.con.Dispose();
        return "Updated";
    }
    public DataSet dup_check_financial_year(financial_year_masterBAL fnnclBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("select financial_year_id from financial_year_master where financial_year=@acdmcy", con.con);
        con.cmd.Parameters.AddWithValue("@acdmcy", fnnclBAL.financial_year);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }

    public DataSet edit_fill_financial_year(financial_year_masterBAL fnnclBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("select * from financial_year_master where financial_year_id=@acyrid", con.con);
        con.cmd.Parameters.AddWithValue("@acyrid", fnnclBAL.financial_year_id);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }

    public DataSet get_all_financial_year()
    {
        con.mycon();
        con.cmd = new MySqlCommand("select * from financial_year_master", con.con);
        con.da = new MySqlDataAdapter(con.cmd);
        con.ds = new DataSet();
        con.da.Fill(con.ds);
        con.con.Close();
        con.con.Dispose();
        return con.ds;
    }

    public string update_current_financial_year(financial_year_masterBAL fnnclBAL)
    {
        con.mycon();
        con.cmd = new MySqlCommand("update current_financial_year_master set current_financial_year=@acdmcy, current_financial_year_logdt=@ldt, current_financial_year_logrid=@lrid where current_financial_year_id=1", con.con);
        con.cmd.Parameters.AddWithValue("@acdmcy", fnnclBAL.financial_year);
        con.cmd.Parameters.AddWithValue("@insdt", fnnclBAL.financial_year_insdt);
        con.cmd.Parameters.AddWithValue("@rid", fnnclBAL.financial_year_rid);
        con.cmd.Parameters.AddWithValue("@ldt", fnnclBAL.financial_year_logdt);
        con.cmd.Parameters.AddWithValue("@lrid", fnnclBAL.financial_year_logrid);
        con.cmd.ExecuteNonQuery();
        con.con.Close();
        con.con.Dispose();
        return "Updated";
    }

    public string get_current_financial_year()
    {
        con.mycon();
        con.cmd = new MySqlCommand("select current_financial_year from current_financial_year_master where current_financial_year_id=1", con.con);
        string currentyear = con.cmd.ExecuteScalar().ToString();
        con.con.Close();
        con.con.Dispose();
        return currentyear;
    }
}

public class other_category_masterDAL : connection
{
    public int insert_other_category(other_category_masterBAL otmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_other_category", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_oth_cat_id", otmBAL.oth_cat_id);
        cmd.Parameters.AddWithValue("@_oth_cat_name", otmBAL.oth_cat_name);
        cmd.Parameters.AddWithValue("@_oth_cat_is_unit", otmBAL.oth_cat_is_unit);
        cmd.Parameters.AddWithValue("@_oth_cat_unit_id", otmBAL.oth_cat_unit_id);
        cmd.Parameters.AddWithValue("@_oth_cat_insdt", otmBAL.oth_cat_insdt);
        cmd.Parameters.AddWithValue("@_oth_cat_insrid", otmBAL.oth_cat_insrid);
        cmd.Parameters.AddWithValue("@_oth_cat_logdt", otmBAL.oth_cat_logdt);
        cmd.Parameters.AddWithValue("@_oth_cat_logrid", otmBAL.oth_cat_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }

    public DataSet get_other_category_list()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_other_cat_unit_name", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_another_category_for_edit(other_category_masterBAL catBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from other_category_master where oth_cat_id=@catid", con);
        cmd.Parameters.AddWithValue("@catid", catBAL.oth_cat_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public void delete_another_category(other_category_masterBAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from other_category_master where oth_cat_id=@catid", con);
        cmd.Parameters.AddWithValue("@catid", cmBAL.oth_cat_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

}
public class service_details_masterDAL : connection
{
    public int insert_into_service_details_master(service_details_masterBAL sdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_service_details", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sdm_id", sdmBAL.sdm_id);
        cmd.Parameters.AddWithValue("@_sdm_cust_id", sdmBAL.sdm_cust_id);
        cmd.Parameters.AddWithValue("@_sdm_repeat", sdmBAL.sdm_repeat);
        cmd.Parameters.AddWithValue("@_sdm_comment", sdmBAL.sdm_comment);
        cmd.Parameters.AddWithValue("@_sdm_interval_days", sdmBAL.sdm_interval_days);
        cmd.Parameters.AddWithValue("@_sdm_interval_months", sdmBAL.sdm_interval_months);
        cmd.Parameters.AddWithValue("@_sdm_interval_year", sdmBAL.sdm_interval_year);
        cmd.Parameters.AddWithValue("@_sdm_insrid", sdmBAL.sdm_insrid);
        cmd.Parameters.AddWithValue("@_sdm_insdt", sdmBAL.sdm_insdt);
        cmd.Parameters.AddWithValue("@_sdm_logrid", sdmBAL.sdtm_logrid);
        cmd.Parameters.AddWithValue("@_sdm_logdt", sdmBAL.sdm_logdt);

        cmd.Parameters.AddWithValue("@_sdtm_id", sdmBAL.sdtm_id);
        cmd.Parameters.AddWithValue("@_sdtm_cust_id", sdmBAL.sdtm_cust_id);
        cmd.Parameters.AddWithValue("@_sdtm_sdm_id", sdmBAL.sdtm_sdm_id);
        cmd.Parameters.AddWithValue("@_sdtm_date", sdmBAL.sdtm_date);
        cmd.Parameters.AddWithValue("@_sdtm_insrid", sdmBAL.sdtm_insrid);
        cmd.Parameters.AddWithValue("@_sdtm_insdt", sdmBAL.sdtm_insdt);
        cmd.Parameters.AddWithValue("@_sdtm_logrid", sdmBAL.sdtm_logrid);
        cmd.Parameters.AddWithValue("@_sdtm_logdt", sdmBAL.sdtm_logdt);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }

    public int insert_into_service_details_master_expired(service_details_masterBAL sdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_expired_card", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sdm_id", sdmBAL.sdm_id);
        cmd.Parameters.AddWithValue("@_sdm_cust_id", sdmBAL.sdm_cust_id);
        cmd.Parameters.AddWithValue("@_sdm_repeat", sdmBAL.sdm_repeat);
        cmd.Parameters.AddWithValue("@_sdm_comment", sdmBAL.sdm_comment);
        cmd.Parameters.AddWithValue("@_sdm_interval_days", sdmBAL.sdm_interval_days);
        cmd.Parameters.AddWithValue("@_sdm_interval_months", sdmBAL.sdm_interval_months);
        cmd.Parameters.AddWithValue("@_sdm_interval_year", sdmBAL.sdm_interval_year);
        cmd.Parameters.AddWithValue("@_sdm_insrid", sdmBAL.sdm_insrid);
        cmd.Parameters.AddWithValue("@_sdm_insdt", sdmBAL.sdm_insdt);
        cmd.Parameters.AddWithValue("@_sdm_logrid", sdmBAL.sdtm_logrid);
        cmd.Parameters.AddWithValue("@_sdm_logdt", sdmBAL.sdm_logdt);

        cmd.Parameters.AddWithValue("@_sdtm_id", sdmBAL.sdtm_id);
        cmd.Parameters.AddWithValue("@_sdtm_cust_id", sdmBAL.sdtm_cust_id);
        cmd.Parameters.AddWithValue("@_sdtm_sdm_id", sdmBAL.sdtm_sdm_id);
        cmd.Parameters.AddWithValue("@_sdtm_date", sdmBAL.sdtm_date);
        cmd.Parameters.AddWithValue("@_sdtm_insrid", sdmBAL.sdtm_insrid);
        cmd.Parameters.AddWithValue("@_sdtm_insdt", sdmBAL.sdtm_insdt);
        cmd.Parameters.AddWithValue("@_sdtm_logrid", sdmBAL.sdtm_logrid);
        cmd.Parameters.AddWithValue("@_sdtm_logdt", sdmBAL.sdtm_logdt);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_expired_amc()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_reminder where sdm_continuity=0", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet get_service_date_master_single(service_date_masterBAL sdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_reminder where sdtm_id=@sdtmid", con);
        cmd.Parameters.AddWithValue("@sdtmid", sdmBAL.sdtm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet get_not_assigned_service(service_date_masterBAL sdmBAL)
    {
        string query = "";
        query = "select * from get_reminder where sdtm_service_man_id=0 and sdtm_status=0";
        if (sdmBAL.sdtm_start_date.ToString() != "" && sdmBAL.sdtm_end_date.ToString() != "")
        {
            if (sdmBAL.sdtm_start_date.ToString() == sdmBAL.sdtm_end_date.ToString())
            {
                query = query + " and date(sdtm_date)='" + sdmBAL.sdtm_start_date + "'";
            }
            else
            {
                query = query + " and date(sdtm_date) between '" + sdmBAL.sdtm_start_date + "' and '" + sdmBAL.sdtm_end_date + "'";
            }
        }
        else if (sdmBAL.sdtm_start_date.ToString() == "" && sdmBAL.sdtm_end_date.ToString() == "")
        {
            query = query + " and date(sdtm_date)=curdate()";
        }
        mycon();
        cmd = new MySqlCommand(query, con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_assigned_service(service_date_masterBAL sdmBAL)
    {

        string query = "", dateq = "", servicemanq = "";
        query = "select * from get_reminder where sdtm_status=" + sdmBAL.sdtm_status + "";
        if (sdmBAL.sdtm_service_man_id != 0)
        {
            servicemanq = " and sdtm_service_man_id=" + sdmBAL.sdtm_service_man_id + "";
            query = query + servicemanq;
        }
        if (sdmBAL.sdtm_start_date.ToString() != "" && sdmBAL.sdtm_end_date.ToString() != "")
        {
            if (sdmBAL.sdtm_start_date.ToString() == sdmBAL.sdtm_end_date.ToString())
            {
                dateq = " and date(sdtm_date)='" + sdmBAL.sdtm_start_date + "'";
            }
            else
            {
                dateq = dateq + " and date(sdtm_date) between '" + sdmBAL.sdtm_start_date + "' and '" + sdmBAL.sdtm_end_date + "'";
            }
            query = query + dateq;
        }
        else if (sdmBAL.sdtm_start_date.ToString() == "" && sdmBAL.sdtm_end_date.ToString() == "")
        {
            query = query + " and date(sdtm_date)=curdate()";
        }
        mycon();
        cmd = new MySqlCommand(query, con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_service_man_list()
    {
        mycon();
        cmd = new MySqlCommand("select * from admin_registration_master where admn_usr_role=@admn_urole", con);
        cmd.Parameters.AddWithValue("@admn_urole", 1);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}
public class service_date_masterDAL : connection
{
    public int update_service_man_details(service_date_masterBAL sdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("update service_date_master set sdtm_service_man_id=@smid , sdtm_status=1,sdtm_logrid=@lrid,sdtm_logdt=@ldt where sdtm_id=@sdtmid", con);
        cmd.Parameters.AddWithValue("@sdtmid", sdmBAL.sdtm_id);
        cmd.Parameters.AddWithValue("@smid", sdmBAL.sdtm_service_man_id);
        cmd.Parameters.AddWithValue("@lrid", sdmBAL.sdtm_logrid);
        cmd.Parameters.AddWithValue("@ldt", sdmBAL.sdtm_logdt);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return 1;
    }


    public int update_service_to_close(service_date_masterBAL sdmBAL)
    {
        mycon();
        if (sdmBAL.sdtm_repeat == 0)
        {
            cmd = new MySqlCommand("update service_date_master set  sdtm_status=2 ,sdtm_logrid=@logrid,sdtm_logdt=@logdt where sdtm_id=@sdtmid", con);
            cmd.Parameters.AddWithValue("@sdtmid", sdmBAL.sdtm_id);
        }
        else if (sdmBAL.sdtm_repeat == 1)
        {
            cmd = new MySqlCommand("update service_date_master set  sdtm_status=2 ,sdtm_logrid=@lrid,sdtm_logdt=@ldt where sdtm_id=@sdtmid", con);
            cmd.Parameters.AddWithValue("@sdtmid", sdmBAL.sdtm_id);
            cmd.Parameters.AddWithValue("@lrid", sdmBAL.sdtm_logrid);
            cmd.Parameters.AddWithValue("@ldt", sdmBAL.sdtm_logdt);
            cmd.ExecuteNonQuery();
            cmd = new MySqlCommand("select count(sdm_id),sdm_continuity,sdm_interval_days,sdm_interval_months from get_reminder where sdm_id=@sdmid1", con);
            cmd.Parameters.AddWithValue("@sdmid1", sdmBAL.sdtm_sdm_id);
            da = new MySqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds);
            int days = 0, interval = 0;
            if (ds.Tables[0].Rows.Count > 0)
            {
                days = (Convert.ToInt16(ds.Tables[0].Rows[0]["sdm_interval_months"].ToString()) * 30) + Convert.ToInt16(ds.Tables[0].Rows[0]["sdm_interval_days"].ToString());
                interval = 365 / days;
            }
            if (Convert.ToInt16(ds.Tables[0].Rows[0]["count(sdm_id)"].ToString()) < interval)
            {
                cmd = new MySqlCommand("insert into service_date_master values(NULL,@custid,@sdmid,@servcmnid,@date,@sts,@insrid,@insdt,@logrid,@logdt)", con);
            }
            if (ds.Tables[0].Rows[0]["count(sdm_id)"].ToString() == interval.ToString())
            {
                cmd = new MySqlCommand("update service_details_master set sdm_continuity=0 where sdm_id=@sdmid2", con);
                cmd.Parameters.AddWithValue("@sdmid2", sdmBAL.sdtm_sdm_id);
            }

        }
        cmd.Parameters.AddWithValue("@custid", sdmBAL.sdtm_cust_id);
        cmd.Parameters.AddWithValue("@sdmid", sdmBAL.sdtm_sdm_id);
        cmd.Parameters.AddWithValue("@servcmnid", 0);
        cmd.Parameters.AddWithValue("@date", sdmBAL.sdtm_date);
        cmd.Parameters.AddWithValue("@sts", 0);
        cmd.Parameters.AddWithValue("@insrid", sdmBAL.sdtm_insrid);
        cmd.Parameters.AddWithValue("@insdt", sdmBAL.sdtm_insdt);
        cmd.Parameters.AddWithValue("@logrid", sdmBAL.sdtm_logrid);
        cmd.Parameters.AddWithValue("@logdt", sdmBAL.sdtm_logdt);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return 1;
    }
}
public class tax_code_masterDAL : connection
{
    public int insert_into_tax_code(tax_code_masterBAL txcdBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_tax", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_txcd_id", txcdBAL.txcd_id);
        cmd.Parameters.AddWithValue("@_txcd_name", txcdBAL.txcd_name);
        cmd.Parameters.AddWithValue("@_txcd_cgst", txcdBAL.txcd_cgst);
        cmd.Parameters.AddWithValue("@_txcd_sgst", txcdBAL.txcd_sgst);
        cmd.Parameters.AddWithValue("@_txcd_igst", txcdBAL.txcd_igst);
        cmd.Parameters.AddWithValue("@_txcd_insrid", txcdBAL.txcd_insrid);
        cmd.Parameters.AddWithValue("@_txcd_insdt", txcdBAL.txcd_insdt);
        cmd.Parameters.AddWithValue("@_txcd_logrid", txcdBAL.txcd_logrid);
        cmd.Parameters.AddWithValue("@_txcd_logdt", txcdBAL.txcd_logdt);

        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();

        int ret_tax_val = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        con.Dispose();
        return ret_tax_val;


    }

    public int update_tax_code(tax_code_masterBAL txcdBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_tax", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_txcd_name", txcdBAL.txcd_name);
        cmd.Parameters.AddWithValue("@_txcd_cgst", txcdBAL.txcd_cgst);
        cmd.Parameters.AddWithValue("@_txcd_sgst", txcdBAL.txcd_sgst);
        cmd.Parameters.AddWithValue("@_txcd_igst", txcdBAL.txcd_igst);
        cmd.Parameters.AddWithValue("@_txcd_logrid", txcdBAL.txcd_logrid);
        cmd.Parameters.AddWithValue("@_txcd_logdt", txcdBAL.txcd_logdt);

        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();

        int ret_tax_val = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());

        con.Close();
        con.Dispose();
        return ret_tax_val;
    }

    public DataSet get_tax_code_list()
    {
        mycon();
        cmd = new MySqlCommand("select * from tax_code_master", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_tax_code_list_for_edit(tax_code_masterBAL txcdBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from tax_code_master where txcd_id=@txcd_id", con);
        cmd.Parameters.AddWithValue("@txcd_id", txcdBAL.txcd_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }
}

public class supplier_masterDAL : connection
{
    public int insert_into_supplier(supplier_masterBAL supBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_supplier", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sup_id", supBAL.sup_id);
        cmd.Parameters.AddWithValue("@_sup_first_name", supBAL.sup_first_name);
        cmd.Parameters.AddWithValue("@_sup_middle_name", supBAL.sup_middle_name);
        cmd.Parameters.AddWithValue("@_sup_last_name", supBAL.sup_last_name);
        cmd.Parameters.AddWithValue("@_sup_business_name", supBAL.sup_business_name);
        cmd.Parameters.AddWithValue("@_sup_gst_no", supBAL.sup_gst_no);
        cmd.Parameters.AddWithValue("@_sup_primary_ctn", supBAL.sup_primary_ctn);
        cmd.Parameters.AddWithValue("@_sup_second_ctn", supBAL.sup_second_ctn);
        cmd.Parameters.AddWithValue("@_sup_third_ctn", supBAL.sup_third_ctn);
        cmd.Parameters.AddWithValue("@_sup_email", supBAL.sup_email);
        cmd.Parameters.AddWithValue("@_sup_address", supBAL.sup_address);
        cmd.Parameters.AddWithValue("@_sup_city_village", supBAL.sup_city_village);
        cmd.Parameters.AddWithValue("@_sup_pincode", supBAL.sup_pincode);
        cmd.Parameters.AddWithValue("@_sup_insrid", supBAL.sup_insrid);
        cmd.Parameters.AddWithValue("@_sup_insdt", supBAL.sup_insdt);
        cmd.Parameters.AddWithValue("@_sup_logrid", supBAL.sup_logrid);
        cmd.Parameters.AddWithValue("@_sup_logdt", supBAL.sup_logdt);

        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();

        int ret_sup_val = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        con.Dispose();
        return ret_sup_val;

    }

    public DataSet get_supplier_list()
    {
        mycon();
        cmd = new MySqlCommand("select * from supplier_master", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    public DataSet get_supplier_list_for_edit(supplier_masterBAL supBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from supplier_master where sup_id=@supid", con);
        cmd.Parameters.AddWithValue("@supid", supBAL.sup_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

}
//Jimish Function Starts



public class product_masterDAL : connection
{
    public string insert_into_product(product_masterBAL prdBAL)
    {

        mycon();
        cmd = new MySqlCommand("add_update_product", con);
        cmd.CommandType = CommandType.StoredProcedure;

        //product database
        cmd.Parameters.AddWithValue("@_prdm_id", prdBAL.prdm_id);
        cmd.Parameters.AddWithValue("@_prdm_name", prdBAL.prdm_name);
        cmd.Parameters.AddWithValue("@_prdm_cat_id", prdBAL.prdm_cat_id);
        cmd.Parameters.AddWithValue("@_prdm_brand_id", prdBAL.prdm_brand_id);
        cmd.Parameters.AddWithValue("@_prdm_unit_id", prdBAL.prdm_unit_id);
        cmd.Parameters.AddWithValue("@_prdm_photo_link", prdBAL.prdm_photo_link);
        cmd.Parameters.AddWithValue("@_prdm_insrid", prdBAL.prdm_insrid);
        cmd.Parameters.AddWithValue("@_prdm_ldt", prdBAL.prdm_ldt);
        cmd.Parameters.AddWithValue("@_prdm_logrid", prdBAL.prdm_logrid);
        cmd.Parameters.AddWithValue("@_prdm_logdt", prdBAL.prdm_logdt);


        //product variationname master
        cmd.Parameters.AddWithValue("@_prvm_id", prdBAL.prvm_id);
        cmd.Parameters.AddWithValue("@_prvm_pdrm_id", prdBAL.prvm_prdm_id);
        cmd.Parameters.AddWithValue("@_prvm_product_variation_name", prdBAL.prvm_product_variation_name);
        cmd.Parameters.AddWithValue("@_prvm_tax_code_id", prdBAL.prvm_tax_code_id);
        //low stock
        cmd.Parameters.AddWithValue("@_prvm_low_stock", prdBAL.prvm_low_stock);

        cmd.Parameters.AddWithValue("@_prvm_insrid", prdBAL.prvm_insrid);
        cmd.Parameters.AddWithValue("@_prvm_insdt", prdBAL.prvm_insdt);
        cmd.Parameters.AddWithValue("@_prvm_logdt", prdBAL.prvm_logdt);
        cmd.Parameters.AddWithValue("@_prvm_logrid", prdBAL.prvm_logrid);

        //product_starting_stock_master
        cmd.Parameters.AddWithValue("@_pssm_id", prdBAL.pssm_id);
        cmd.Parameters.AddWithValue("@_pssm_prdm_id", prdBAL.pssm_prdm_id);
        cmd.Parameters.AddWithValue("@_pssm_pvnm_id", prdBAL.pssm_pvnm_id);
        cmd.Parameters.AddWithValue("@_pssm_starting_qty", prdBAL.pssm_starting_qty);
        cmd.Parameters.AddWithValue("@_pssm_starting_price", prdBAL.pssm_starting_price);
        cmd.Parameters.AddWithValue("@_pssm_financial_year", prdBAL.pssm_financial_year);

        cmd.Parameters.AddWithValue("@_pssm_insrid", prdBAL.pssm_insrid);
        cmd.Parameters.AddWithValue("@_pssm_insdt", prdBAL.pssm_insdt);
        cmd.Parameters.AddWithValue("@_pssm_logrid", prdBAL.pssm_logrid);
        cmd.Parameters.AddWithValue("@_pssm_logdt", prdBAL.pssm_logdt);

        //idle selling price
        cmd.Parameters.AddWithValue("@_idle_sell_id", prdBAL.idle_sell_id);
        cmd.Parameters.AddWithValue("@_idle_prod_var_id", prdBAL.idle_prod_var_id);
        cmd.Parameters.AddWithValue("@_idle_prod_var_name", prdBAL.idle_prod_var_name);
        cmd.Parameters.AddWithValue("@_idle_prod_selling_price", prdBAL.idle_prod_selling_price);
        cmd.Parameters.AddWithValue("@_idle_insrid", prdBAL.idle_insrid);
        cmd.Parameters.AddWithValue("@_idle_insdt", prdBAL.idle_insdt);
        cmd.Parameters.AddWithValue("@_idle_logrid", prdBAL.idle_logrid);
        cmd.Parameters.AddWithValue("@_idle_logdt", prdBAL.idle_logdt);

        MySqlParameter sp1 = new MySqlParameter("_prd_spe_prdm_id_out", MySqlDbType.Int32);
        sp1.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp1);

        MySqlParameter sp2 = new MySqlParameter("_prd_spe_pvnm_id_out", MySqlDbType.Int32);
        sp2.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp2);

        cmd.ExecuteNonQuery();
        int prd_spe_prdm_id = Convert.ToInt32(cmd.Parameters["_prd_spe_prdm_id_out"].Value.ToString());
        int prd_spe_pvnm_id = Convert.ToInt32(cmd.Parameters["_prd_spe_pvnm_id_out"].Value.ToString());

        con.Close();

        return prd_spe_prdm_id + "|" + prd_spe_pvnm_id;

    }

    public String add_product_variation(product_masterBAL prdBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_product_variation_name_qty", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@_prvm_id", prdBAL.prvm_id);
        cmd.Parameters.AddWithValue("@_prvm_pdrm_id", prdBAL.prvm_prdm_id);
        cmd.Parameters.AddWithValue("@_prvm_product_variation_name", prdBAL.prvm_product_variation_name);
        cmd.Parameters.AddWithValue("@_prvm_tax_code_id", prdBAL.prvm_tax_code_id);
        cmd.Parameters.AddWithValue("@_prvm_low_stock", prdBAL.prvm_low_stock);
        cmd.Parameters.AddWithValue("@_prvm_insrid", prdBAL.prvm_insrid);
        cmd.Parameters.AddWithValue("@_prvm_insdt", prdBAL.prvm_insdt);
        cmd.Parameters.AddWithValue("@_prvm_logrid", prdBAL.prvm_logrid);
        cmd.Parameters.AddWithValue("@_prvm_logdt", prdBAL.prvm_logdt);

        cmd.Parameters.AddWithValue("@_pssm_id", prdBAL.pssm_id);
        cmd.Parameters.AddWithValue("@_pssm_prdm_id", prdBAL.pssm_prdm_id);
        cmd.Parameters.AddWithValue("@_pssm_pvnm_id", prdBAL.pssm_pvnm_id);
        cmd.Parameters.AddWithValue("@_pssm_starting_qty", prdBAL.pssm_starting_qty);
        cmd.Parameters.AddWithValue("@_pssm_starting_price", prdBAL.pssm_starting_price);
        cmd.Parameters.AddWithValue("@_pssm_financial_year", prdBAL.pssm_financial_year);
        cmd.Parameters.AddWithValue("@_pssm_insrid", prdBAL.pssm_insrid);
        cmd.Parameters.AddWithValue("@_pssm_insdt", prdBAL.pssm_insdt);
        cmd.Parameters.AddWithValue("@_pssm_logrid", prdBAL.pssm_logrid);
        cmd.Parameters.AddWithValue("@_pssm_logdt", prdBAL.pssm_logdt);



        MySqlParameter sp1 = new MySqlParameter("_ret", MySqlDbType.Int32);
        sp1.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp1);

        MySqlParameter sp2 = new MySqlParameter("_prd_var_id", MySqlDbType.Int32);
        sp2.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp2);

        cmd.ExecuteNonQuery();

        int flg_value = Convert.ToInt32(sp1.Value);

        int prd_var_id = Convert.ToInt32(sp2.Value);


        con.Close();
        con.Dispose();

        return flg_value + "|" + prd_var_id;
    }

    public DataSet get_product_list_for_filter()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_product_list_for_filter; ", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }


    public DataSet get_product_for_add_varient(product_specification_masterBAL pssmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_all_product_details where prvm_id=@prm_id", con);
        cmd.Parameters.AddWithValue("@prvm_id", pssmBAL.prd_spe_id);
        da = new MySqlDataAdapter(cmd);
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_product_details(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select min(prdm_name) as prdm_name ,prdm_brand_id,prdm_cat_id,prdm_photo_link,um_id,min(txcd_id) as txcd_id from get_all_product_details where @prdm_id=prdm_id group by prvm_product_variation_name", con);
        cmd.Parameters.AddWithValue("@prdm_id", pmBAL.prdm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_product_variation(product_masterBAL pmBAL)
    {
        mycon();
        DataSet ds = new DataSet();
        con.Close();

        return ds;
    }

    public DataSet get_product_variation_list(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from product_variation_name_master as pvnm left join product_starting_stock_master as pssm on pvnm.prvm_id = pssm.pssm_pvnm_id where prvm_pdrm_id=@pdrm_id", con);
        cmd.Parameters.AddWithValue("@pdrm_id", pmBAL.prdm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);


        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_product_variaton_list_for_edit(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_all_product_details where prvm_id=@prvm_id", con);
        cmd.Parameters.AddWithValue("@prvm_id", pmBAL.prvm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);


        con.Close();
        con.Dispose();
        return ds;
    }

    public void update_product_variation_price_qty_year(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("update_product_variation_price_qty_year where pssm_pvnm_id=@prd_var_id", con);
        cmd.Parameters.AddWithValue("@prd_var_id", pmBAL.prvm_id);

        con.Close();
        con.Dispose();
    }

    public void update_product_details(product_masterBAL pmBAL)
    {
        mycon();
        //update product master
        cmd = new MySqlCommand("update product_master set prdm_name=@prd_name,prdm_cat_id=@prd_cat_id,prdm_brand_id=@prd_brand_id,prdm_unit_id=@prd_unit_id,prdm_photo_link=@prd_photo_link,prdm_logrid=@prd_logrid,prdm_logdt=@prd_logdt where prdm_id=@prd_id", con);
        cmd.Parameters.AddWithValue("@prd_id", pmBAL.prdm_id);
        cmd.Parameters.AddWithValue("@prd_name", pmBAL.prdm_name);
        cmd.Parameters.AddWithValue("@prd_brand_id", pmBAL.prdm_brand_id);
        cmd.Parameters.AddWithValue("@prd_photo_link", pmBAL.prdm_photo_link);
        cmd.Parameters.AddWithValue("@prd_unit_id", pmBAL.prdm_unit_id);
        cmd.Parameters.AddWithValue("@prd_cat_id", pmBAL.prdm_cat_id);

        cmd.Parameters.AddWithValue("@prd_logrid", pmBAL.prdm_logrid);
        cmd.Parameters.AddWithValue("@prd_logdt", pmBAL.prdm_logdt);

        cmd.ExecuteNonQuery();

        //update product name master update tax code
        cmd = new MySqlCommand("update product_variation_name_master set prvm_tax_code_id=@tax_code where prvm_pdrm_id=@pdrm_id", con);
        cmd.Parameters.AddWithValue("@pdrm_id", pmBAL.prdm_id);
        cmd.Parameters.AddWithValue("@tax_code", pmBAL.prvm_tax_code_id);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();
    }

    public void fill_product_variation_for_edit(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from product_specification_master where prd_spe_pvnm_id=@prd_pvnm_id", con);
        cmd.Parameters.AddWithValue("@prd_pvnm_id", pmBAL.prd_spe_pvnm_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

    public DataSet fill_product_variation_for_edit1(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from product_specification_master as psm left join other_category_master as ocm on psm.prd_spe_oth_cat_id = ocm.oth_cat_id where psm.prd_spe_pvnm_id=@prd_pvnm_id", con);
        cmd.Parameters.AddWithValue("@prd_pvnm_id", pmBAL.prd_spe_pvnm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);


        con.Close();
        con.Dispose();
        return ds;
    }

    public void update_product(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("update_product", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@_prvm_id", pmBAL.prvm_id);
        cmd.Parameters.AddWithValue("@_prvm_product_variation_name", pmBAL.prvm_product_variation_name);
        cmd.Parameters.AddWithValue("@_prvm_tax_code_id", pmBAL.prvm_tax_code_id);
        cmd.Parameters.AddWithValue("@_prvm_logdt", pmBAL.prvm_logdt);
        cmd.Parameters.AddWithValue("@_prvm_logrid", pmBAL.prvm_logrid);

        cmd.Parameters.AddWithValue("@_pssm_pvnm_id", pmBAL.pssm_pvnm_id);
        cmd.Parameters.AddWithValue("@_pssm_starting_price", pmBAL.pssm_starting_price);
        cmd.Parameters.AddWithValue("@_pssm_starting_qty", pmBAL.pssm_starting_qty);
        cmd.Parameters.AddWithValue("@_pssm_financial_year", pmBAL.pssm_financial_year);
        cmd.Parameters.AddWithValue("@_pssm_logrid", pmBAL.pssm_logrid);
        cmd.Parameters.AddWithValue("@_pssm_logdt", pmBAL.pssm_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

    public DataSet get_product_tax_code()
    {
        mycon();
        cmd = new MySqlCommand("select * from tax_code_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }


}

public class product_specification_masterDAL : connection
{
    public int insert_into_product_specification_master(product_specification_masterBAL prdBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_product_specification", con);

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_prd_spe_id", prdBAL.prd_spe_id);
        cmd.Parameters.AddWithValue("@_prd_spe_prdm_id", prdBAL.prd_spe_prdm_id);
        cmd.Parameters.AddWithValue("@_prd_spe_pvnm_id", prdBAL.prd_spe_pvnm_id);
        cmd.Parameters.AddWithValue("@_prd_spe_oth_cat_id", prdBAL.prd_spe_oth_cat_id);
        cmd.Parameters.AddWithValue("@_prd_spe_oth_cat_val", prdBAL.prd_spe_oth_cat_val);
        cmd.Parameters.AddWithValue("@_prd_spe_insrid", prdBAL.prd_spe_insrid);
        cmd.Parameters.AddWithValue("@_prd_spe_insdt", prdBAL.prd_spe_insdt);
        cmd.Parameters.AddWithValue("@_prd_spe_logrid", prdBAL.prd_spe_logrid);
        cmd.Parameters.AddWithValue("@_prd_spe_logdt", prdBAL.prd_spe_logdt);

        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();
        Byte flg_value = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        return flg_value;
    }

    public DataSet get_product_spefication(product_specification_masterBAL psmBAL)
    {
        mycon();
        // cmd = new MySqlCommand("select * from get_all_product_details where prd_spe_prdm_id=@prd_id ", con);
        cmd = new MySqlCommand("select min(prvm_product_variation_name),oth_cat_name,min(oth_cat_id) as oth_cat_id from get_specification_edit_page where prdm_id=@prd_id group by oth_cat_name", con);
        cmd.Parameters.AddWithValue("@prd_id", psmBAL.prd_spe_prdm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    public void insert_new_product_specification_Edit_page(product_specification_masterBAL psmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_into_product_specification_edit_page", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_prd_spe_id", psmBAL.prd_spe_id);
        cmd.Parameters.AddWithValue("@_prd_spe_prdm_id", psmBAL.prd_spe_prdm_id);
        cmd.Parameters.AddWithValue("@_prd_spe_pvnm_id", psmBAL.prd_spe_pvnm_id);
        cmd.Parameters.AddWithValue("@_prd_spe_oth_cat_id", psmBAL.prd_spe_oth_cat_id);
        cmd.Parameters.AddWithValue("@_prd_spe_oth_cat_val", psmBAL.prd_spe_oth_cat_val);
        cmd.Parameters.AddWithValue("@_prd_spe_insrid", psmBAL.prd_spe_insrid);
        cmd.Parameters.AddWithValue("@_prd_spe_insdt", psmBAL.prd_spe_insdt);
        cmd.Parameters.AddWithValue("@_prd_spe_logrid", psmBAL.prd_spe_logrid);
        cmd.Parameters.AddWithValue("@_prd_spe_logdt", psmBAL.prd_spe_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
    }

}

public class supplier_purchse_bill_masterDAL : connection
{
    public int insert_purchase_bill(supplier_purchse_bill_masterBAL supBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_supplier_bill", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_spb_id", supBAL.spb_id);
        cmd.Parameters.AddWithValue("@_spb_supplier_id", supBAL.spb_supplier_id);
        cmd.Parameters.AddWithValue("@_spb_purchse_date", supBAL.spb_purchase_date);
        cmd.Parameters.AddWithValue("@_spb_total_amount", supBAL.spb_total_amount);
        cmd.Parameters.AddWithValue("@_spb_status", supBAL.spb_status);
        cmd.Parameters.AddWithValue("@_spb_financial_year", supBAL.spb_financial_year);
        cmd.Parameters.AddWithValue("@_spb_insrid", supBAL.spb_insrid);
        cmd.Parameters.AddWithValue("@_spb_insdt", supBAL.spb_insdt);
        cmd.Parameters.AddWithValue("@_spb_logrid", supBAL.spb_logrid);
        cmd.Parameters.AddWithValue("@_spb_logdt", supBAL.spb_logdt);


        MySqlParameter sp = new MySqlParameter("spb_id", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();
        int suppier_bill_id = Convert.ToInt32(cmd.Parameters["spb_id"].Value.ToString());
        con.Close();
        return suppier_bill_id;

    }

    public void insert_into_supplier_bill_details(supplier_purchase_bill_detailBAL supbBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_supplier_bill_details", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_spbd_id", supbBAL.spbd_id);
        cmd.Parameters.AddWithValue("@_spbd_bill_id", supbBAL.spbd_bill_id);
        cmd.Parameters.AddWithValue("@_spbd_product_id", supbBAL.spbd_product_id);
        cmd.Parameters.AddWithValue("@_spbd_quentity", supbBAL.spbd_quentity);
        cmd.Parameters.AddWithValue("@_spbd_total", supbBAL.spbd_total);
        cmd.Parameters.AddWithValue("@_spbd_insrid", supbBAL.spbd_insrid);
        cmd.Parameters.AddWithValue("@_spbd_insdt", supbBAL.spbd_insdt);
        cmd.Parameters.AddWithValue("@_spbd_logrid", supbBAL.spbd_logrid);
        cmd.Parameters.AddWithValue("@_spbd_logdt", supbBAL.spbd_logdt);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

    }
}

//mode of payment
public class mode_of_paymentDAL : connection
{
    public int insert_into_mode_of_payment(mode_of_paymentBAL mopBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_mode_of_payment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_mop_id", mopBAL.mop_id);
        cmd.Parameters.AddWithValue("@_mop_name", mopBAL.mop_name);
        //cmd.Parameters.AddWithValue("@_mop_insrid", mopBAL.mop_insrid);
        //cmd.Parameters.AddWithValue("@_mop_insdt", mopBAL.mop_insdt);
        //cmd.Parameters.AddWithValue("@_mop_logrid", mopBAL.mop_logrid);
        //cmd.Parameters.AddWithValue("@_mop_logdt", mopBAL.mop_logdt);

        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();
        int return_val = Convert.ToInt32(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        con.Dispose();
        return return_val;
    }

    public DataSet get_mode_of_payment_list()
    {

        mycon();
        cmd = new MySqlCommand("select * from mode_of_payment", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    public DataSet get_mode_of_payment_for_edit(mode_of_paymentBAL mopBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from mode_of_payment where  mop_id=@mid", con);
        cmd.Parameters.AddWithValue("@mid", mopBAL.mop_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public void delete_mode_of_payment(mode_of_paymentBAL mopBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from mode_of_payment where mop_id=@mid", con);
        cmd.Parameters.AddWithValue("@mid", mopBAL.mop_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

}

//insert into supplier purchase bill 
public class supplier_bill_masterDAL : connection
{
    public string insert_into_supplier_purchase_bill_master(supplier_purchse_bill_masterBAL supBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_supplier_purchase_bill_master", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@_spb_id", supBAL.spb_id);
        cmd.Parameters.AddWithValue("@_spb_supplier_id", supBAL.spb_supplier_id);
        cmd.Parameters.AddWithValue("@_spb_purchase_bill_id", supBAL.spb_purchase_bill_id);
        cmd.Parameters.AddWithValue("@_spb_purchse_date", supBAL.spb_purchase_date);
        cmd.Parameters.AddWithValue("@_spb_total_amount", supBAL.spb_total_amount);
        cmd.Parameters.AddWithValue("@_spb_total_actual_amount", supBAL.spb_total_actual_amount);
        cmd.Parameters.AddWithValue("@_spb_status", supBAL.spb_status);
        cmd.Parameters.AddWithValue("@_spb_financial_year", supBAL.spb_financial_year);
        cmd.Parameters.AddWithValue("@_spb_mode_of_payment", supBAL.spb_mode_of_payment);
        cmd.Parameters.AddWithValue("@_spb_insrid", supBAL.spb_insrid);
        cmd.Parameters.AddWithValue("@_spb_insdt", supBAL.spb_insdt);
        cmd.Parameters.AddWithValue("@_spb_logrid", supBAL.spb_logrid);
        cmd.Parameters.AddWithValue("@_spb_logdt", supBAL.spb_logdt);


        MySqlParameter sp1 = new MySqlParameter("_ret", MySqlDbType.Int32);
        sp1.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp1);

        MySqlParameter sp2 = new MySqlParameter("_spb_ret_id", MySqlDbType.String);
        sp2.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp2);

        cmd.ExecuteNonQuery();

        string ret_val = Convert.ToString(sp1.Value);
        string spb_ret_id = Convert.ToString(sp2.Value);

        con.Close();
        con.Dispose();
        return ret_val + "|" + spb_ret_id;
    }

    public void insert_into_supplier_purchase_bill_details(supplier_purchase_bill_detailBAL supbBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_supplier_purchase_bill_details", con);

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_spbd_id", supbBAL.spbd_id);
        cmd.Parameters.AddWithValue("@_spbd_bill_id", supbBAL.spbd_bill_id);
        cmd.Parameters.AddWithValue("@_spbd_product_id", supbBAL.spbd_product_id);

        //product billing price
        cmd.Parameters.AddWithValue("@_spbd_product_price", supbBAL.spbd_product_price);
        //product actual  price
        cmd.Parameters.AddWithValue("@_spbd_product_actual_price", supbBAL.spbd_product_actual_price);

        //product billing quentity
        cmd.Parameters.AddWithValue("@_spbd_quentity", supbBAL.spbd_quentity);
        //product actual quentity
        cmd.Parameters.AddWithValue("@_spbd_actual_quentity", supbBAL.spbd_actual_quentity);

        //product billing total
        cmd.Parameters.AddWithValue("@_spbd_total", supbBAL.spbd_total);
        //product actual total
        cmd.Parameters.AddWithValue("@_spbd_actual_total", supbBAL.spbd_actual_total);

        //discount in %
        cmd.Parameters.AddWithValue("@_spbd_discount", supbBAL.spbd_discount);
        //discount amount on each product
        cmd.Parameters.AddWithValue("@_spbd_discount_amount", supbBAL.spbd_discount_amount);

        //gst value
        cmd.Parameters.AddWithValue("@_spbd_cgst", supbBAL.spbd_cgst);
        cmd.Parameters.AddWithValue("@_spbd_sgst", supbBAL.spbd_sgst);
        cmd.Parameters.AddWithValue("@_spbd_igst", supbBAL.spbd_igst);

        cmd.Parameters.AddWithValue("@_spbd_insrid", supbBAL.spbd_insrid);
        cmd.Parameters.AddWithValue("@_spbd_insdt", supbBAL.spbd_insdt);
        cmd.Parameters.AddWithValue("@_spbd_logrid", supbBAL.spbd_logrid);
        cmd.Parameters.AddWithValue("@_spbd_logdt", supbBAL.spbd_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

    }

    public void insert_into_supplier_purchase_bill_payment(supplier_purchse_bill_paymentBAL supbpBAL)
    {

        mycon();

        cmd = new MySqlCommand("add_supplier_purchase_bill_payment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_spbp_id", supbpBAL.spbp_id);
        cmd.Parameters.AddWithValue("@_spbp_bill_id", supbpBAL.spbp_bill_id);
        cmd.Parameters.AddWithValue("@_spbp_mod_of_payment", supbpBAL.spbp_mod_of_payment);
        cmd.Parameters.AddWithValue("@_spbp_date_of_payment", supbpBAL.spbp_date_of_payment);
        cmd.Parameters.AddWithValue("@_spbp_amount", supbpBAL.spbp_amount);
        cmd.Parameters.AddWithValue("@_spbp_insrid", supbpBAL.spbp_insrid);
        cmd.Parameters.AddWithValue("@_spbp_insdt", supbpBAL.spbp_insdt);
        cmd.Parameters.AddWithValue("@_spbp_logrid", supbpBAL.spbp_logrid);
        cmd.Parameters.AddWithValue("@_spbp_logdt", supbpBAL.spbp_logdt);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();

    }

    public void get_bill_list_search_page()
    {
        mycon();
        cmd = new MySqlCommand("get_supplier_search_details", con);
        cmd.CommandType = CommandType.StoredProcedure;


        cmd.ExecuteNonQuery();
        con.Close();
    }


    //get data for supplier master
    public List<productEntry> get_data_for_search_supplier_edit(supplier_purchase_bill_detailBAL spbdBAL)
    {

        List<productEntry> lstProEntry = new List<productEntry>();
        mycon();
        cmd = new MySqlCommand("select spb_purchase_bill_id,sup_business_name,sup_id,sup_primary_ctn,spb_purchse_date," +
            "spbd_product_id,spbd_product_id,prvm_product_variation_name,spbd_product_price,spbd_quentity," +
            "txcd_name,price_each_product,mop_id,min(spbd_amount),spbd_id," +
            "txcd_cgst,txcd_sgst,txcd_igst,price_each_product,spbd_actual_total," +
            "spbd_product_actual_price,spbd_actual_quentity,spbd_discount," +
            "spb_financial_year from get_supplier_search_details where spb_id=@spb_id group by spbd_id", con);
        cmd.Parameters.AddWithValue("@spb_id", spbdBAL.spbd_bill_id);

        MySqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        while (reader.Read())
        {
            lstProEntry.Add(new productEntry
            {
                sup_billid = reader["spb_purchase_bill_id"].ToString(),
                sup_name = reader["sup_business_name"].ToString(),
                sup_id = Convert.ToInt32(reader["sup_id"].ToString()),
                sup_mob_no = reader["sup_primary_ctn"].ToString(),
                purchase_date = Convert.ToDateTime(reader["spb_purchse_date"]).ToString(),
                productVarId = Convert.ToInt32(reader["spbd_product_id"]),
                pName = reader["prvm_product_variation_name"].ToString(),
                pPrice = Convert.ToDecimal(reader["spbd_product_price"].ToString()),
                pQty = Convert.ToInt32(reader["spbd_quentity"].ToString()),
                gstVAL = reader["txcd_name"].ToString(),
                pTotal = Convert.ToInt32(reader["price_each_product"].ToString()),
                mopVal = Convert.ToInt32(reader["mop_id"].ToString()),
                mopAMO = reader["min(spbd_amount)"].ToString(),
                spb_bill_det_id = Convert.ToInt32(reader["spbd_id"].ToString()),
                cgst = float.Parse(reader["txcd_cgst"].ToString()),
                sgst = float.Parse(reader["txcd_sgst"].ToString()),
                igst = float.Parse(reader["txcd_igst"].ToString()),

                //each product price
                product_each_price = float.Parse(reader["price_each_product"].ToString()),

                //actual total amount 
                product_actual_total_amount = Convert.ToInt32(reader["spbd_actual_total"].ToString()),

                //actual product price
                product_actual_price = float.Parse(reader["spbd_product_actual_price"].ToString()),

                //actual product quentity
                product_actual_quentity = Convert.ToInt32(reader["spbd_actual_quentity"].ToString()),

                //product discount
                product_discount = float.Parse(reader["spbd_discount"].ToString()),

                //financial_year_id
                financial_year = reader["spb_financial_year"].ToString()
            });
        }
        //reader.Close();

        return lstProEntry;


    }



    //update product bill master
    public void update_product_bill_master(supplier_purchse_bill_masterBAL spbBAL)
    {

        mycon();
        cmd = new MySqlCommand("update supplier_purchase_bill_master set spb_supplier_id=@sup_id,spb_purchase_bill_id=@sup_bill_id,spb_purchse_date=@spb_purchase_date,spb_total_amount=@total_amo,spb_total_actual_amount=@spb_actual_amount,spb_financial_year=@financial_year,spb_mode_of_payment=@mop,spb_logrid=@spb_logrid,spb_logdt=@spb_logdt where spb_id=@spb_id", con);
        cmd.Parameters.AddWithValue("@spb_id", spbBAL.spb_id);
        cmd.Parameters.AddWithValue("@sup_id", spbBAL.spb_supplier_id);
        cmd.Parameters.AddWithValue("@sup_bill_id", spbBAL.spb_purchase_bill_id);
        cmd.Parameters.AddWithValue("@spb_purchase_date", spbBAL.spb_purchase_date);


        //total billing amount
        cmd.Parameters.AddWithValue("@total_amo", spbBAL.spb_total_amount);
        //actual total amount

        cmd.Parameters.AddWithValue("@spb_actual_amount", spbBAL.spb_total_actual_amount);

        //financial year 
        cmd.Parameters.AddWithValue("@financial_year", spbBAL.spb_financial_year);

        //mode of payment
        cmd.Parameters.AddWithValue("@mop", spbBAL.spb_mode_of_payment);

        cmd.Parameters.AddWithValue("@spb_logrid", spbBAL.spb_logrid);
        cmd.Parameters.AddWithValue("@spb_logdt", spbBAL.spb_logdt);
        cmd.ExecuteNonQuery();
        con.Close();

    }


    //update purchase bill details
    public void update_purchase_bill_details(supplier_purchase_bill_detailBAL spbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("update supplier_purchase_bill_detail set spbd_product_id=@prdid,spbd_product_price=@prdprice,spbd_product_actual_price=@prdactprice,spbd_quentity=@prdqty,spbd_actual_quentity=@prdactqty,spbd_total=@prdtotalprice,spbd_actual_total=@prdacttot,spbd_discount=@prddis,spbd_discount_amount=@prddisamo,spbd_cgst=@prdcgst,spbd_sgst=@prdsgst,spbd_igst=@prdigst,spbd_logrid=@logrid,spbd_logdt=@logdt where spbd_id=@spbd_id", con);
        cmd.Parameters.AddWithValue("@spbd_id", spbdBAL.spbd_id);
        cmd.Parameters.AddWithValue("@prdid", spbdBAL.spbd_product_id);

        //product billing price
        cmd.Parameters.AddWithValue("@prdprice", spbdBAL.spbd_product_price);
        //product actual price
        cmd.Parameters.AddWithValue("@prdactprice", spbdBAL.spbd_product_actual_price);

        //product billing quentity
        cmd.Parameters.AddWithValue("@prdqty", spbdBAL.spbd_quentity);
        //product actual quentity
        cmd.Parameters.AddWithValue("@prdactqty", spbdBAL.spbd_actual_quentity);

        //product billing price
        cmd.Parameters.AddWithValue("@prdtotalprice", spbdBAL.spbd_total);
        //product actual price
        cmd.Parameters.AddWithValue("@prdacttot", spbdBAL.spbd_actual_total);

        //prpoduct discount
        cmd.Parameters.AddWithValue("@prddis", spbdBAL.spbd_discount);
        //product discount amount
        cmd.Parameters.AddWithValue("@prddisamo", spbdBAL.spbd_discount_amount);

        cmd.Parameters.AddWithValue("@prdcgst", spbdBAL.spbd_cgst);
        cmd.Parameters.AddWithValue("@prdsgst", spbdBAL.spbd_sgst);
        cmd.Parameters.AddWithValue("@prdigst", spbdBAL.spbd_igst);
        cmd.Parameters.AddWithValue("@logrid", spbdBAL.spbd_logrid);
        cmd.Parameters.AddWithValue("@logdt", spbdBAL.spbd_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
    }

    //update purchase bill payment
    public void update_purchase_payment(supplier_purchse_bill_paymentBAL spbpBAL)
    {
        mycon();
        cmd = new MySqlCommand("update supplier_purchase_bill_payment set spbp_mod_of_payment=@mop,spbp_amount=@spb_amo,spbp_logrid=@logrid,spbp_logdt=@logdt where spbp_bill_id=@bill_id", con);
        cmd.Parameters.AddWithValue("@bill_id", spbpBAL.spbp_bill_id);
        cmd.Parameters.AddWithValue("@mop", spbpBAL.spbp_mod_of_payment);
        cmd.Parameters.AddWithValue("@spb_amo", spbpBAL.spbp_amount);
        cmd.Parameters.AddWithValue("@logrid", spbpBAL.spbp_logrid);
        cmd.Parameters.AddWithValue("@logdt", spbpBAL.spbp_logdt);

        cmd.ExecuteNonQuery();
        con.Close();

    }


    //delete purchase bill details 
    public void delete_purchase_bill_details(supplier_purchase_bill_detailBAL spbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from supplier_purchase_bill_detail where spbd_id=@spbd_id", con);
        cmd.Parameters.AddWithValue("@spbd_id", spbdBAL.spbd_id);

        cmd.ExecuteNonQuery();
        con.Close();

    }




    //get supplier data in payment page
    public DataSet get_supplier_product_list(supplier_purchse_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_bill_detail_for_list_view where spb_id=@spb_id", con);
        cmd.Parameters.AddWithValue("@spb_id", spbmBAL.spb_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }


    //get product data in bill payment page

    //public DataSet get_supplier_product_list(supplier_purchase_bill_detailBAL spbdBAL)
    //{
    //    mycon();
    //    cmd = new MySqlCommand("select * from get_product_list_bill_payment where spbd_bill_id=@spb_id", con);
    //    cmd.Parameters.AddWithValue("@spb_id", spbdBAL.spbd_bill_id);

    //    da = new MySqlDataAdapter(cmd);
    //    ds = new DataSet();
    //    da.Fill(ds);

    //    con.Close();
    //    con.Dispose();
    //    return ds;
    //}


    //get customer data in bill

    public DataSet get_customer_product_list(supplier_purchse_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_bill_detail_for_list_view where spb_id=@spb_id ", con);
        cmd.Parameters.AddWithValue("@spb_id", spbmBAL.spb_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    //insert into supplier purchase bill payment
    public void insert_into_bill_payment(supplier_purchse_bill_paymentBAL spbdBAL)
    {
        mycon();

        cmd = new MySqlCommand("insert into supplier_purchase_bill_payment values(null,@spbp_bill_id,@spbp_mod_of_payment,@spbp_date_of_payment,@spbp_amount,@spbp_insrid,@spbp_insdt,@spbp_logrid,@spbp_logdt)", con);
        cmd.Parameters.AddWithValue("@spbp_bill_id", spbdBAL.spbp_bill_id);
        cmd.Parameters.AddWithValue("@spbp_mod_of_payment", spbdBAL.spbp_mod_of_payment);
        cmd.Parameters.AddWithValue("@spbp_date_of_payment", spbdBAL.spbp_date_of_payment);
        cmd.Parameters.AddWithValue("@spbp_amount", spbdBAL.spbp_amount);
        cmd.Parameters.AddWithValue("@spbp_insrid", spbdBAL.spbp_insrid);
        cmd.Parameters.AddWithValue("@spbp_insdt", spbdBAL.spbp_insdt);
        cmd.Parameters.AddWithValue("@spbp_logrid", spbdBAL.spbp_logrid);
        cmd.Parameters.AddWithValue("@spbp_logdt", spbdBAL.spbp_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

}

//insert into sales bill
public class sales_bill_masterDAL : connection
{
    //insert intp bill master

    public string insert_into_sales_bill_master(sales_bill_masterBAL sbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_sales_bill_master", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@_sbm_id", sbmBAL.sbm_id);
        cmd.Parameters.AddWithValue("@_customer_id", sbmBAL.customer_id);
        cmd.Parameters.AddWithValue("@_sbm_sales_bill_id", sbmBAL.sbm_sales_bill_id);
        cmd.Parameters.AddWithValue("@_sbm_sales_date", sbmBAL.sbm_sales_date);
        cmd.Parameters.AddWithValue("@_sbm_total_amount", sbmBAL.sbm_total_amount);
        cmd.Parameters.AddWithValue("@_sbm_total_actual_amount", sbmBAL.sbm_total_actual_amount);
        cmd.Parameters.AddWithValue("@_sbm_status", sbmBAL.sbm_status);
        cmd.Parameters.AddWithValue("@_sbm_financial_year", sbmBAL.sbm_financial_year);
        cmd.Parameters.AddWithValue("@_sbm_mode_of_payment", sbmBAL.sbm_mode_of_payment);
        cmd.Parameters.AddWithValue("@_sbm_insrid", sbmBAL.sbm_insrid);
        cmd.Parameters.AddWithValue("@_sbm_insdt", sbmBAL.sbm_insdt);
        cmd.Parameters.AddWithValue("@_sbm_logrid", sbmBAL.sbm_logrid);
        cmd.Parameters.AddWithValue("@_sbm_logdt", sbmBAL.sbm_logdt);




        MySqlParameter sp1 = new MySqlParameter("_ret", MySqlDbType.Int32);
        sp1.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp1);

        MySqlParameter sp2 = new MySqlParameter("_sbm_ret_id", MySqlDbType.String);
        sp2.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp2);

        cmd.ExecuteNonQuery();

        string ret_val = Convert.ToString(sp1.Value);
        string sbm_ret_id = Convert.ToString(sp2.Value);

        con.Close();
        con.Dispose();
        return ret_val + "|" + sbm_ret_id;
    }

    //insert into bill details
    public void insert_into_sales_bill_details(sales_bill_detailBAL sbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_sales_bill_details", con);

        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sbd_id", sbdBAL.sbd_id);
        cmd.Parameters.AddWithValue("@_sbd_bill_id", sbdBAL.sbd_bill_id);
        cmd.Parameters.AddWithValue("@_sbd_product_id", sbdBAL.sbd_product_id);

        //product billing price
        cmd.Parameters.AddWithValue("@_sbd_product_price", sbdBAL.sbd_product_price);
        //product actual  price
        cmd.Parameters.AddWithValue("@_sbd_product_actual_price", sbdBAL.sbd_product_actual_price);

        //product billing quentity
        cmd.Parameters.AddWithValue("@_sbd_quentity", sbdBAL.sbd_quentity);
        //product actual quentity
        cmd.Parameters.AddWithValue("@_sbd_actual_quentity", sbdBAL.sbd_actual_quentity);

        //product billing total
        cmd.Parameters.AddWithValue("@_sbd_total", sbdBAL.sbd_total);
        //product actual total
        cmd.Parameters.AddWithValue("@_sbd_actual_total", sbdBAL.sbd_actual_total);

        //discount in %
        cmd.Parameters.AddWithValue("@_sbd_discount", sbdBAL.sbd_discount);
        //discount amount on each product
        cmd.Parameters.AddWithValue("@_sbd_discount_amount", sbdBAL.sbd_discount_amount);

        //gst value
        cmd.Parameters.AddWithValue("@_sbd_cgst", sbdBAL.sbd_cgst);
        cmd.Parameters.AddWithValue("@_sbd_sgst", sbdBAL.sbd_sgst);
        cmd.Parameters.AddWithValue("@_sbd_igst", sbdBAL.sbd_igst);

        cmd.Parameters.AddWithValue("@_sbd_insrid", sbdBAL.sbd_insrid);
        cmd.Parameters.AddWithValue("@_sbd_insdt", sbdBAL.sbd_insdt);
        cmd.Parameters.AddWithValue("@_sbd_logrid", sbdBAL.sbd_logrid);
        cmd.Parameters.AddWithValue("@_sbd_logdt", sbdBAL.sbd_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

    }

    //insert into bill payment
    public void insert_into_sales_bill_payment(sales_bill_paymentBAL sbpBAL)
    {

        mycon();

        cmd = new MySqlCommand("add_sales_bill_payment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sbp_id", sbpBAL.sbp_id);
        cmd.Parameters.AddWithValue("@_sbp_bill_id", sbpBAL.sbp_bill_id);
        cmd.Parameters.AddWithValue("@_sbp_mod_of_payment", sbpBAL.sbp_mod_of_payment);
        cmd.Parameters.AddWithValue("@_sbp_date_of_payment", sbpBAL.sbp_date_of_payment);
        cmd.Parameters.AddWithValue("@_sbp_amount", sbpBAL.sbp_amount);
        cmd.Parameters.AddWithValue("@_sbp_insrid", sbpBAL.sbp_insrid);
        cmd.Parameters.AddWithValue("@_sbp_insdt", sbpBAL.sbp_insdt);
        cmd.Parameters.AddWithValue("@_sbp_logrid", sbpBAL.sbp_logrid);
        cmd.Parameters.AddWithValue("@_sbp_logdt", sbpBAL.sbp_logdt);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();

    }


    //get data for customer bill
    public List<productEntry> get_data_for_search_customer_edit(sales_bill_detailBAL spbdBAL)
    {

        List<productEntry> lstProEntry = new List<productEntry>();
        mycon();
        cmd = new MySqlCommand("select sbm_sales_bill_id,cust_first_name,cust_middle_name,cust_last_name," +
            "cust_id,cust_primary_ctn,sbm_sales_date,sbd_product_id,prvm_product_variation_name," +
            "sbd_product_price,sbd_quentity,txcd_name,sbd_total,mop_id,sbd_id," +
            "txcd_cgst,txcd_sgst,txcd_igst,sbd_actual_total,sbd_product_actual_price," +
            "sbd_actual_quentity,sbd_discount,sbd_total,sbm_financial_year from get_customer_search_details where sbm_id=@sbm_id group by sbd_id ", con);
        cmd.Parameters.AddWithValue("@sbm_id", spbdBAL.sbd_bill_id);

        MySqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        while (reader.Read())
        {
            lstProEntry.Add(new productEntry
            {
                sup_billid = reader["sbm_sales_bill_id"].ToString(),
                cust_name = reader["cust_first_name"].ToString() + " " + reader["cust_middle_name"].ToString() + " " + reader["cust_last_name"].ToString(),
                sup_id = Convert.ToInt32(reader["cust_id"].ToString()),
                sup_mob_no = reader["cust_primary_ctn"].ToString(),
                purchase_date = Convert.ToDateTime(reader["sbm_sales_date"]).ToString(),
                productVarId = Convert.ToInt32(reader["sbd_product_id"]),
                pName = reader["prvm_product_variation_name"].ToString(),
                pPrice = Convert.ToDecimal(reader["sbd_product_price"].ToString()),
                pQty = Convert.ToInt32(reader["sbd_quentity"].ToString()),
                gstVAL = reader["txcd_name"].ToString(),
                pTotal = Convert.ToInt32(reader["sbd_total"].ToString()),
                mopVal = Convert.ToInt32(reader["mop_id"].ToString()),
                //mopAMO = reader["spbd_amount"].ToString(),
                spb_bill_det_id = Convert.ToInt32(reader["sbd_id"].ToString()),

                //for gst values
                cgst = float.Parse(reader["txcd_cgst"].ToString()),
                sgst = float.Parse(reader["txcd_sgst"].ToString()),
                igst = float.Parse(reader["txcd_igst"].ToString()),

                //actual total amount 
                product_actual_total_amount = Convert.ToInt32(reader["sbd_actual_total"].ToString()),

                //actual product price
                product_actual_price = float.Parse(reader["sbd_product_actual_price"].ToString()),

                //actual product quentity
                product_actual_quentity = Convert.ToInt32(reader["sbd_actual_quentity"].ToString()),

                //product discount
                product_discount = float.Parse(reader["sbd_discount"].ToString()),


                //product each price
                product_each_price = float.Parse(reader["sbd_total"].ToString()),

                //financial_year_id
                financial_year = reader["sbm_financial_year"].ToString()

            });
        }
        //reader.Close();

        return lstProEntry;

    }

    //update sales bill master
    public void update_sales_master(sales_bill_masterBAL sbmBAL)
    {

        mycon();
        cmd = new MySqlCommand("update sales_bill_master set customer_id=@sup_id,sbm_sales_bill_id=@sup_bill_id,sbm_sales_date=@spb_purchase_date,sbm_total_amount=@total_amo,sbm_total_actual_amount=@spb_actual_amount,sbm_financial_year=@financial_year,sbm_mode_of_payment=@mod,sbm_logrid=@spb_logrid,sbm_logdt=@spb_logdt where sbm_id=@spb_id", con);
        cmd.Parameters.AddWithValue("@spb_id", sbmBAL.sbm_id);
        cmd.Parameters.AddWithValue("@sup_id", sbmBAL.customer_id);
        cmd.Parameters.AddWithValue("@sup_bill_id", sbmBAL.sbm_sales_bill_id);
        cmd.Parameters.AddWithValue("@spb_purchase_date", sbmBAL.sbm_sales_date);

        //total billing amount
        cmd.Parameters.AddWithValue("@total_amo", sbmBAL.sbm_total_amount);
        //actual total amount
        cmd.Parameters.AddWithValue("@spb_actual_amount", sbmBAL.sbm_total_actual_amount);

        //financial year
        cmd.Parameters.AddWithValue("@financial_year", sbmBAL.sbm_financial_year);

        //mode of payment
        cmd.Parameters.AddWithValue("@mod", sbmBAL.sbm_mode_of_payment);

        cmd.Parameters.AddWithValue("@spb_logrid", sbmBAL.sbm_logrid);
        cmd.Parameters.AddWithValue("@spb_logdt", sbmBAL.sbm_logdt);
        cmd.ExecuteNonQuery();
        con.Close();

    }

    //update sales details
    public void update_sales_details(sales_bill_detailBAL sbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("update sales_bill_detail  set sbd_product_id=@prdid,sbd_product_price=@prdprice,sbd_product_actual_price=@prdactprice,sbd_quentity=@prdqty,sbd_actual_quentity=@prdactqty,sbd_total=@prdtotalprice,sbd_actual_total=@prdacttot,sbd_discount=@prddis,sbd_discount_amount=@prddisamo,sbd_cgst=@prdcgst,sbd_sgst=@prdsgst,sbd_igst=@prdigst,sbd_logrid=@logrid,sbd_logdt=@logdt where sbd_id=@spbd_id", con);
        cmd.Parameters.AddWithValue("@spbd_id", sbdBAL.sbd_id);
        cmd.Parameters.AddWithValue("@prdid", sbdBAL.sbd_product_id);

        //product billing price
        cmd.Parameters.AddWithValue("@prdprice", sbdBAL.sbd_product_price);
        //product actual price
        cmd.Parameters.AddWithValue("@prdactprice", sbdBAL.sbd_product_actual_price);

        //product billing quentity
        cmd.Parameters.AddWithValue("@prdqty", sbdBAL.sbd_quentity);
        //product actual quentity
        cmd.Parameters.AddWithValue("@prdactqty", sbdBAL.sbd_actual_quentity);

        //product billing price
        cmd.Parameters.AddWithValue("@prdtotalprice", sbdBAL.sbd_total);
        //product actual price
        cmd.Parameters.AddWithValue("@prdacttot", sbdBAL.sbd_actual_total);

        //prpoduct discount
        cmd.Parameters.AddWithValue("@prddis", sbdBAL.sbd_discount);
        //product discount amount
        cmd.Parameters.AddWithValue("@prddisamo", sbdBAL.sbd_discount_amount);

        cmd.Parameters.AddWithValue("@prdcgst", sbdBAL.sbd_cgst);
        cmd.Parameters.AddWithValue("@prdsgst", sbdBAL.sbd_sgst);
        cmd.Parameters.AddWithValue("@prdigst", sbdBAL.sbd_igst);
        cmd.Parameters.AddWithValue("@logrid", sbdBAL.sbd_logrid);
        cmd.Parameters.AddWithValue("@logdt", sbdBAL.sbd_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
    }

    //update sales payment
    public void update_sales_payment(sales_bill_paymentBAL sbpBAL)
    {
        mycon();
        cmd = new MySqlCommand("update sales_bill_payment set sbp_mod_of_payment=@mop,sbp_amount=@spb_amo,sbp_logrid=@logrid,sbp_logdt=@logdt where sbp_bill_id=@bill_id", con);
        cmd.Parameters.AddWithValue("@bill_id", sbpBAL.sbp_bill_id);
        cmd.Parameters.AddWithValue("@mop", sbpBAL.sbp_mod_of_payment);
        cmd.Parameters.AddWithValue("@spb_amo", sbpBAL.sbp_amount);
        cmd.Parameters.AddWithValue("@logrid", sbpBAL.sbp_logrid);
        cmd.Parameters.AddWithValue("@logdt", sbpBAL.sbp_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
    }

    //get supplier data in payment page
    public DataSet get_customer_product_list(sales_bill_masterBAL sbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_sell_detail_for_list_view where sbm_id=@sbm_id", con);
        cmd.Parameters.AddWithValue("@sbm_id", sbmBAL.sbm_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    //insert into sales bill payment
    public void insert_into_sales_bill_payment_pay(sales_bill_paymentBAL sbpBAL)
    {
        mycon();

        cmd = new MySqlCommand("insert into sales_bill_payment values(null,@sbp_bill_id,@sbp_mod_of_payment,@sbp_date_of_payment,@sbp_amount,@sbp_insrid,@sbp_insdt,@sbp_logrid,@sbp_logdt)", con);
        cmd.Parameters.AddWithValue("@sbp_bill_id", sbpBAL.sbp_bill_id);
        cmd.Parameters.AddWithValue("@sbp_mod_of_payment", sbpBAL.sbp_mod_of_payment);
        cmd.Parameters.AddWithValue("@sbp_date_of_payment", sbpBAL.sbp_date_of_payment);
        cmd.Parameters.AddWithValue("@sbp_amount", sbpBAL.sbp_amount);
        cmd.Parameters.AddWithValue("@sbp_insrid", sbpBAL.sbp_insrid);
        cmd.Parameters.AddWithValue("@sbp_insdt", sbpBAL.sbp_insdt);
        cmd.Parameters.AddWithValue("@sbp_logrid", sbpBAL.sbp_logrid);
        cmd.Parameters.AddWithValue("@sbp_logdt", sbpBAL.sbp_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }


    //delete customer bill details 
    public void delete_customer_bill_details(sales_bill_detailBAL sbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from sales_bill_detail where sbd_id=@sbd_id", con);
        cmd.Parameters.AddWithValue("@sbd_id", sbdBAL.sbd_id);

        cmd.ExecuteNonQuery();
        con.Close();

    }

    //public void get purchased product list in bill payment
    public DataSet get_product_list_bill_payment(sales_bill_detailBAL sbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from  get_product_list_sales_bill_payment where sbd_bill_id=@sup_id", con);

        cmd.Parameters.AddWithValue("@sup_id", sbdBAL.sbd_bill_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

}

//get supplier serach bill details
public class supplier_search_detailsDAL : connection
{
    //get supplier and customer bill list 
    public DataSet get_supplier_bill_details(supplier_purchse_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select spb_id,sup_business_name,sup_primary_ctn,spb_total_actual_amount,min(spbp_amount),paidamount,unpaidamount,cust_first_name,cust_last_name,cust_middle_name,cust_primary_ctn from get_bill_detail_for_list_view where  spb_status=@status group by spb_id", con);
        //cmd.Parameters.AddWithValue("@sprch_id", spbmBAL.spb_sales_purchase_id);
        cmd.Parameters.AddWithValue("@status", spbmBAL.spb_status);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }


    //get supplier bill detials
    public DataSet get_supplier_bill_details_click_event(supplier_purchse_bill_masterBAL spbmBAL, supplier_masterBAL smBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_bill_detail_for_list_view where (sup_business_name=@sbn) or (spb_purchse_date BETWEEN @startdate AND @enddate) or (spb_purchase_bill_id=@spb_bill_id) ", con);
        // cmd.Parameters.AddWithValue("@prchid", spbmBAL.spb_sales_purchase_id);
        cmd.Parameters.AddWithValue("@spb_bill_id", spbmBAL.spb_purchase_bill_id);
        cmd.Parameters.AddWithValue("@sbn", smBAL.sup_business_name);
        cmd.Parameters.AddWithValue("@startdate", spbmBAL.startdate);
        cmd.Parameters.AddWithValue("@enddate", spbmBAL.enddate);

        //custmer master 


        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }


    //get customer bill details
    public DataSet get_customer_bill_details(sales_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select sbm_id,sbm_total_actual_amount,min(sbp_amount),paidamount,unpaidamount,cust_first_name,cust_last_name,cust_middle_name,cust_primary_ctn from get_sell_detail_for_list_view where sbm_status=@status group by sbm_id", con);
        cmd.Parameters.AddWithValue("@status", spbmBAL.sbm_status);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }


    //get supplier bill detials
    public DataSet get_customer_bill_details_click_event(sales_bill_masterBAL sbmBAL, customer_masterBAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_sell_detail_for_list_view where (cust_first_name=@cfn) or (cust_middle_name=@cmn) or (cust_last_name=@cln) or (sbm_sales_date BETWEEN @startdate AND @enddate) or (sbm_sales_bill_id=@sbm_sales_id) ", con);

        cmd.Parameters.AddWithValue("@sbm_sales_id", sbmBAL.sbm_sales_bill_id);
        cmd.Parameters.AddWithValue("@cfn", cmBAL.cust_first_name);
        cmd.Parameters.AddWithValue("@cmn", cmBAL.cust_middle_name);
        cmd.Parameters.AddWithValue("@cln", cmBAL.cust_last_name);
        cmd.Parameters.AddWithValue("@startdate", sbmBAL.startdate);
        cmd.Parameters.AddWithValue("@enddate", sbmBAL.enddate);

        //custmer master 

        cmd.ExecuteNonQuery();
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

}

//insert_update into voucher  master
public class voucher_masterDAL : connection
{
    //insert into the voucher master 
    public void insert_into_voucher_master(voucher_masterBAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_voucher", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_vm_id", vmBAL.vm_id);
        cmd.Parameters.AddWithValue("@_vm_vnm_id", vmBAL.vm_vnm_id);
        cmd.Parameters.AddWithValue("@_vm_name", vmBAL.vm_name);
        cmd.Parameters.AddWithValue("@_vm_person_name", vmBAL.vm_person_name);
        cmd.Parameters.AddWithValue("@_vm_phone_num", vmBAL.vm_phone_num);
        cmd.Parameters.AddWithValue("@_vm_amount", vmBAL.vm_amount);
        cmd.Parameters.AddWithValue("@_vm_date", vmBAL.vm_date);
        cmd.Parameters.AddWithValue("@_vm_financial_year", vmBAL.vm_financial_year);
        cmd.Parameters.AddWithValue("@_vm_insrid", vmBAL.vm_insrid);
        cmd.Parameters.AddWithValue("@_vm_insdt", vmBAL.vm_insdt);
        cmd.Parameters.AddWithValue("@_vm_logrid", vmBAL.vm_logrid);
        cmd.Parameters.AddWithValue("@_vm_logdt", vmBAL.vm_logdt);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();
    }

    //edit voucher master
    public DataSet get_voucher_list_for_edit(voucher_masterBAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from voucher_master where vm_id=@vmid", con);
        cmd.Parameters.AddWithValue("@vmid", vmBAL.vm_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    //get voucher master list
    public DataSet get_voucher_list()
    {
        mycon();
        cmd = new MySqlCommand("select vm.vm_id,vnm.vm_name as voucher_type,vm.vm_name as voucher_name,vm.vm_person_name,vm.vm_phone_num,vm.vm_amount from voucher_master vm  left join voucher_name_master as vnm on vnm.vm_id = vm.vm_vnm_id where vm.vm_financial_year=(select current_financial_year from current_financial_year_master);", con);


        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }



    //voucher name master insert
    public int insert_voucher_name_master(voucher_name_masterBAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_voucher_name_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_vm_id", vmBAL.vm_id);
        cmd.Parameters.AddWithValue("@_vm_name", vmBAL.vm_name);
        cmd.Parameters.AddWithValue("@_vm_insrid", vmBAL.vm_insrid);
        cmd.Parameters.AddWithValue("@_vm_insdt", vmBAL.vm_insdt);
        cmd.Parameters.AddWithValue("@_vm_logrid", vmBAL.vm_logrid);
        cmd.Parameters.AddWithValue("@_vm_logdt", vmBAL.vm_logdt);
        MySqlParameter sp = new MySqlParameter("_ret", MySqlDbType.Byte);
        sp.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(sp);
        cmd.ExecuteNonQuery();
        Byte flg_value = Convert.ToByte(cmd.Parameters["_ret"].Value.ToString());
        con.Close();
        return flg_value;

    }

    //voucher name master list
    public DataSet get_voucher_name_master_list()
    {

        mycon();
        cmd = new MySqlCommand("select * from voucher_name_master", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    //voucher name master get for edit
    public DataSet get_voucher_name_master_for_edit(voucher_name_masterBAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from voucher_name_master where vm_id=@vid", con);
        cmd.Parameters.AddWithValue("@vid", vmBAL.vm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    //delete from voucher name master
    public void delete_voucher_name_master(voucher_name_masterBAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete from voucher_name_master where vm_id=@vid", con);
        cmd.Parameters.AddWithValue("@vid", vmBAL.vm_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

}

//idle selling price
public class idle_selling_priceDAL : connection
{
    public DataSet get_product_variation_list()
    {
        mycon();
        cmd = new MySqlCommand("SELECT prvm_id,prvm_product_variation_name FROM product_variation_name_master", con);


        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_product_variation_name(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("SELECT prvm_id,prvm_product_variation_name FROM product_variation_name_master where prvm_id=@prdid", con);
        cmd.Parameters.AddWithValue("@prdid", pmBAL.prvm_id);
        cmd.ExecuteNonQuery();

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    public void insert_into_idle_selling_price(idle_selleing_priceBAL ispBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_ideal_selling_price", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_idle_sell_id", ispBAL.idle_sell_id);
        cmd.Parameters.AddWithValue("@_idle_prod_var_id", ispBAL.idle_prod_var_id);
        cmd.Parameters.AddWithValue("@_idle_prod_var_name", ispBAL.idle_prod_var_name);
        cmd.Parameters.AddWithValue("@_idle_prod_selling_price", ispBAL.idle_prod_selling_price);

        cmd.Parameters.AddWithValue("@_idle_insrid", ispBAL.idle_insrid);
        cmd.Parameters.AddWithValue("@_idle_insdt", ispBAL.idle_insdt);
        cmd.Parameters.AddWithValue("@_idle_logrid", ispBAL.idle_logrid);
        cmd.Parameters.AddWithValue("@_idle_logdt", ispBAL.idle_logdt);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();

    }

    public DataSet get_product_var_name_for_edit(idle_selleing_priceBAL ispBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from idle_selling_price as isp left join product_variation_name_master as pvnm on isp.idle_prod_var_id = pvnm.prvm_id where idle_prod_var_id=@prd_id", con);
        cmd.Parameters.AddWithValue("@prd_id", ispBAL.idle_prod_var_id);
        cmd.ExecuteNonQuery();

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

}

//get product list bill payment
public class bill_paymentDAL : connection
{
    public DataSet get_product_list_bill_payment(supplier_purchase_bill_detailBAL spbdBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from  get_product_list_bill_payment where spbd_bill_id=@sup_id ", con);

        cmd.Parameters.AddWithValue("@sup_id", spbdBAL.spbd_bill_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }
}

//add product variation on view update product variation
public class add_product_variationDAL : connection
{
    //get product other specification variation name  list on add_product_variation_page
    public DataSet get_product_name_variation_list(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select min(prd_spe_oth_cat_id) as prd_spe_oth_cat_id,oth_cat_name,prdm_name,min(prvm_id) from get_product_variation_edit_page where prvm_pdrm_id=@prd_id group by oth_cat_id", con);
        cmd.Parameters.AddWithValue("@prd_id", pmBAL.prdm_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }


    //get list of product variation id on add product variation page
    public DataSet get_product_variation_id(product_masterBAL pmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select pssm_pvnm_id from get_product_variation_edit_page where prvm_pdrm_id=@prdm_id group by pssm_pvnm_id", con);
        cmd.Parameters.AddWithValue("@prdm_id", pmBAL.prdm_id);
        cmd.ExecuteNonQuery();


        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }


    //delete from product_specification_master page on add_product_varitaion page
    public void detete_from_product_other_category_edit_page(product_specification_masterBAL psmBAL)
    {
        mycon();
        cmd = new MySqlCommand("delete  from product_specification_master where prd_spe_prdm_id=@prd_spe_id and prd_spe_oth_cat_id=@prd_spe_oth_id ", con);
        cmd.Parameters.AddWithValue("@prd_spe_id", psmBAL.prd_spe_prdm_id);
        cmd.Parameters.AddWithValue("@prd_spe_oth_id", psmBAL.prd_spe_oth_cat_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }


    //insert into product_specification_master database 
    public void insert_into_product_specification_edit_page(product_specification_masterBAL psmBAL)
    {
        mycon();
        cmd = new MySqlCommand("insert into product_specification_master values(null,@prd_spe_prdm_id,@prd_spe_pvnm_id,@prd_spe_oth_cat_id,@prd_spe_oth_cat_val,@insrid,@insdt,@logrid,@logdt)", con);
        cmd.Parameters.AddWithValue("@prd_spe_prdm_id", psmBAL.prd_spe_prdm_id);
        cmd.Parameters.AddWithValue("@prd_spe_pvnm_id", psmBAL.prd_spe_pvnm_id);
        cmd.Parameters.AddWithValue("@prd_spe_oth_cat_id", psmBAL.prd_spe_oth_cat_id);
        cmd.Parameters.AddWithValue("@prd_spe_oth_cat_val", psmBAL.prd_spe_oth_cat_val);
        cmd.Parameters.AddWithValue("@insrid", psmBAL.prd_spe_insrid);
        cmd.Parameters.AddWithValue("@insdt", psmBAL.prd_spe_insdt);
        cmd.Parameters.AddWithValue("@logrid", psmBAL.prd_spe_logrid);
        cmd.Parameters.AddWithValue("@logdt", psmBAL.prd_spe_logdt);

        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

    public DataSet get_other_category_list_edit_page(product_specification_masterBAL psmBAL)
    {
        mycon();

        cmd = new MySqlCommand("select oth_cat_id,oth_cat_name from other_category_master as ocm left " +
            "join product_specification_master as psm on ocm.oth_cat_id = psm.prd_spe_oth_cat_id where " +
            " ocm.oth_cat_id  not in (select min(prd_spe_oth_cat_id) from product_specification_master" +
            " where prd_spe_prdm_id = @prd_spe_prdm_id group by prd_spe_oth_cat_id) group by ocm.oth_cat_id ", con);

        cmd.Parameters.AddWithValue("@prd_spe_prdm_id", psmBAL.prd_spe_prdm_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

}

//inventory report
public class inventiry_reportDAL : connection
{
    //report product variation name 
    public DataSet get_product_current_quentity()
    {
        mycon();
        //old code
        // cmd = new MySqlCommand("select min(prvm_product_variation_name) as prvm_product_variation_name ,min(pssm_starting_qty) as pssm_starting_qty,min(purchased_quentity) as purchased_quentity,min(sold_quentity) as sold_quentity,min(current_quentity) as current_quentity from report_product_var_name group by pssm_pvnm_id", con);
        cmd = new MySqlCommand("SELECT rpvn.pssm_pvnm_id,pvnm.prvm_product_variation_name,rpvn.pssm_starting_qty,rpvn.purchased_quentity,rpvn.sold_quentity," +
            " (rpvn.pssm_starting_qty+rpvn.purchased_quentity-rpvn.sold_quentity) as current_quentity FROM jp_raval.report_product_var_name as rpvn left join product_variation_name_master as pvnm on rpvn.pssm_pvnm_id = pvnm.prvm_id", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }


    //report product name 
    public DataSet get_product_current_quentity_product_name()
    {
        mycon();
        cmd = new MySqlCommand("SELECT min(prdm_name) as prdm_name,sum(pssm_starting_qty) as starting_quentity,sum(purchased_quentity) as purchased_quentity , sum(sell_quantity) as sell_quentity , " +
            "(sum(pssm_starting_qty)+sum(purchased_quentity) -sum(sell_quantity)) as current_quentity from report_product_name group by  prdm_id", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

    //voucher report total voucher and total price
    public DataSet get_voucher_total()
    {
        mycon();
        cmd = new MySqlCommand("select count(vm_id) as total_voucher,sum(vm_amount) as total_voucher_amount from voucher_master where vm_financial_year=(select current_financial_year from current_financial_year_master)", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }

    //report voucher total count voucher,each voucher total,voucher name
    public DataSet get_voucher_name_total_price()
    {

        mycon();
        cmd = new MySqlCommand("select * from report_voucher", con);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

}

//low stock
public class low_stockDAL : connection
{
    public DataSet get_product_low_stock()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_low_stock_alert", con);


        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }
}

//profit- loss
public class profit_lossDAL : connection
{
    //get total starting stock
    public int get_total_starting_stock()
    {
        mycon();
        cmd = new MySqlCommand("select sum(pssm_starting_price) from product_starting_stock_master where pssm_financial_year=(select current_financial_year from current_financial_year_master)", con);
        int val = Convert.ToInt32(cmd.ExecuteScalar());
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

        return val;
    }

    //get total investment
    public int get_total_investment()
    {
        mycon();
        cmd = new MySqlCommand("select sum(spb_total_actual_amount) from supplier_purchase_bill_master where spb_financial_year = ((select current_financial_year from current_financial_year_master));", con);
        string val= Convert.ToString(cmd.ExecuteScalar());
        if (val == "")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

        return Convert.ToInt32(val);
    }

    //get total sales
    public int get_total_return()
    {
        mycon();
        cmd = new MySqlCommand("select sum(sbm_total_actual_amount) from sales_bill_master where sbm_financial_year=(select current_financial_year from current_financial_year_master)", con);
        string val = Convert.ToString(cmd.ExecuteScalar());
        if(val=="")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

        return Convert.ToInt32(val);
    }

    //get total voucher
    public int get_total_voucher()
    {

        mycon();
        cmd = new MySqlCommand("select sum(vm_amount) from voucher_master where vm_financial_year=(select current_financial_year from current_financial_year_master);", con);
        string val = Convert.ToString(cmd.ExecuteScalar());
        if(val=="")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();

        return Convert.ToInt32(val);
    }


    //get investment in search date
    public Int64 get_investment_search_date(supplier_purchse_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select sum(spb_total_actual_amount) from supplier_purchase_bill_master where date(spb_purchse_date) between " + spbmBAL.startdate + " and " + spbmBAL.enddate + " and spb_financial_year=((select current_financial_year from current_financial_year_master))", con);
        string val = cmd.ExecuteScalar().ToString();
        con.Close();
        con.Dispose();
        if (val.ToString() == "")
        {
            val = "0";
        }
        return Convert.ToInt64(val);

    }

    //get total sales in search
    public Int64 get_return_search_date(supplier_purchse_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select sum(sbm_total_actual_amount) from sales_bill_master where date(sbm_sales_date) between " + spbmBAL.startdate + " and " + spbmBAL.enddate + " and sbm_financial_year=((select current_financial_year from current_financial_year_master))", con);
        string val = cmd.ExecuteScalar().ToString();
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        if (val.ToString() == "")
        {
            val = "0";
        }
        return Convert.ToInt64(val);
    }

    //get total voucher in search
    public Int64 get_return_voucher_date(supplier_purchse_bill_masterBAL spbmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select sum(vm_amount) from voucher_master where date(vm_date) between " + spbmBAL.startdate + " and " + spbmBAL.enddate + " and vm_financial_year=((select current_financial_year from current_financial_year_master))", con);
        string val = cmd.ExecuteScalar().ToString();
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        if (val.ToString() == "")
        {
            val = "0";
        }
        return Convert.ToInt64(val);
    }

    //get total purchase amount amount 
    public Int64 get_total_purchase_amount()
    {

        mycon();
        cmd = new MySqlCommand("SELECT sum(spb_total_actual_amount) FROM supplier_purchase_bill_master where spb_financial_year=((select current_financial_year from current_financial_year_master))", con);
        string val = cmd.ExecuteScalar().ToString();
        if(val.ToString()=="")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return Convert.ToInt32(val);
    }

    //get total purchase bill amount
    public Int64 get_total_purchase_bill_amount()
    {
        mycon();
        cmd = new MySqlCommand("select sum(spbp.spbp_amount) from supplier_purchase_bill_payment as spbp left join supplier_purchase_bill_master as spbm on spbp.spbp_bill_id = spbm.spb_id where spbm.spb_financial_year=(select current_financial_year from current_financial_year_master); ", con);
        string val = cmd.ExecuteScalar().ToString();
        if(val.ToString()=="")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return Convert.ToInt32(val);
    }

    //get sales purchase amount total
    public Int64 get_total_sales_amount()
    {
        mycon();
        cmd = new MySqlCommand("select sum(sbm_total_actual_amount) from sales_bill_master where sbm_financial_year=(select current_financial_year from current_financial_year_master)", con);
        string val = cmd.ExecuteScalar().ToString();
        if(val=="")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return Convert.ToInt32(val);
    }


    //get sales total paid amount
    public Int64 get_total_sales_bill_amount()
    {
        mycon();
        cmd = new MySqlCommand("select sum(sbp.sbp_amount) from sales_bill_master as sbm left join sales_bill_payment as sbp on sbm.sbm_id=sbp.sbp_bill_id where sbm.sbm_financial_year= (select current_financial_year from current_financial_year_master);", con);
        string val = (cmd.ExecuteScalar().ToString());
        if(val=="")
        {
            val = "0";
        }
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return Convert.ToInt32(val);
    }

}


//new  chages for current financial year chaaged
public class change_current_financialyearDAL : connection
{
    //update product staring stock master
    public void insert_product_starting_stock_master(int val)
    {
        mycon();
        cmd = new MySqlCommand("insert_into_starting_stock_master", con);
        cmd.Parameters.AddWithValue("@_var", val);
        
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();
    }

    //update current financial year in product starting stock master
    public void update_fin_year_product_starting_stock_master(product_starting_stock_masterBAL pssmBAL)
    {
        mycon();
        cmd = new MySqlCommand("update product_starting_stock_master set pssm_financial_year=@fin_year where pssm_financial_year=@year", con);
        cmd.Parameters.AddWithValue("@fin_year", pssmBAL.pssm_financial_year);
        cmd.Parameters.AddWithValue("@year", "0");
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

    //check if the financial year we want to change into that exits in database or not
    public DataSet get_exists_date_starting_stock_master(product_starting_stock_masterBAL pssmBAL)
    {

        mycon();
        cmd = new MySqlCommand("select * from product_starting_stock_master where pssm_financial_year=@year", con);
        cmd.Parameters.AddWithValue("@year", pssmBAL.pssm_financial_year);
        cmd.ExecuteNonQuery();

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;

    }


    //update insert date and logdt
    public void update_insdt_logdt(product_starting_stock_masterBAL pssmBAL)
    {
        mycon();
        cmd = new MySqlCommand("update product_starting_stock_master set pssm_insdt=@insdt,pssm_logdt=@logdt where pssm_financial_year=@year", con);
        cmd.Parameters.AddWithValue("@insdt", System.DateTime.Now);
        cmd.Parameters.AddWithValue("@logdt", System.DateTime.Now);
        cmd.Parameters.AddWithValue("@year", pssmBAL.pssm_financial_year);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
    }

    //update product average price
    public void update_avegrage_price(product_starting_stock_masterBAL pssmBAL)
    {
        mycon();
        cmd = new MySqlCommand("update_product_average_price", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_year", pssmBAL.pssm_financial_year);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();

    }

    //insert only those product whose values change after
    //changing in financial year
    public DataSet get_new_added_product_after_changing_financial_year()
    {
        mycon();
        cmd = new MySqlCommand("select * from product_starting_stock_master where pssm_insdt > (select current_financial_year_logdt from current_financial_year_master)",con);
        cmd.ExecuteNonQuery();

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);

        con.Close();
        con.Dispose();
        return ds;
    }

}















