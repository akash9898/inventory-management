﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Drawing;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;


public partial class DEMO : System.Web.UI.Page
{

    public MySqlCommand cmd;
    public MySqlConnection con;
    public MySqlDataAdapter da;
    public DataSet ds;

    public void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }




protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string barCode = TextBox1.Text;
        //System.Web.UI.WebControls.Image imgBarCode = new System.Web.UI.WebControls.Image();
        //using (Bitmap bitMap = new Bitmap(barCode.Length * 40, 80))
        //{

        //    using (Graphics graphics = Graphics.FromImage(bitMap))
        //    {
        //        Font oFont = new Font("IDAutomationHC39M", 16);
        //        //Font oFont = new Font(, 16);

        //        PointF point = new PointF(2f, 2f);
        //        SolidBrush blackBrush = new SolidBrush(Color.Black);
        //        SolidBrush whiteBrush = new SolidBrush(Color.White);
        //        graphics.FillRectangle(whiteBrush, 0, 0, bitMap.Width, bitMap.Height);
        //        graphics.DrawString("*" + barCode + "*", oFont, blackBrush, point);
        //    }

        //    using (MemoryStream ms = new MemoryStream())
        //    {
        //        bitMap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
        //        byte[] byteImage = ms.ToArray();

        //        Convert.ToBase64String(byteImage);
        //        imgBarCode.ImageUrl = "data:image/png;base64," + Convert.ToBase64String(byteImage);
        //    }

        //    PlaceHolder1.Controls.Add(imgBarCode);

        //}

        mycon();
        cmd = new MySqlCommand("select name from db_table where barcode=@bar",con);
        cmd.Parameters.AddWithValue("@bar", barCode);
        string names = cmd.ExecuteScalar().ToString();
        if(names==null)
        {
            names = "";
        }

        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();

        product_name.Text = names;

       
    }


    protected void btnsave_Click(object sender, EventArgs e)
    {

        mycon();
        cmd = new MySqlCommand("insert into db_table values(null,@nm,@bar)",con);
        cmd.Parameters.AddWithValue("@nm", txtentername.Text);
        cmd.Parameters.AddWithValue("@bar", txtbarcode.Text);
        cmd.ExecuteNonQuery();

        con.Close();
        con.Dispose();

    }

}
