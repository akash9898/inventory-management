﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Unit : System.Web.UI.Page
{
    void loadgridview()
    {
        unit_masterDAL umDAL = new unit_masterDAL();
        DataSet ds = umDAL.get_unit_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                loadgridview();

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {

        unit_masterBAL umBAL = new unit_masterBAL();
        if (hfcatid.Value.ToString() == "")
        {
            umBAL.um_id = 0;
        }
        else if (hfcatid.Value.ToString() != "")
        {
            umBAL.um_id = Convert.ToInt16(hfcatid.Value.ToString());
        }

        umBAL.um_name = txtunit.Text.Trim().Replace('-','~').ToUpper();
        umBAL.um_insrid = Convert.ToInt32(Session["login"].ToString());
        umBAL.um_insdt = System.DateTime.Now;
        umBAL.um_logrid = Convert.ToInt32(Session["login"].ToString());
        umBAL.um_logdt = System.DateTime.Now;

        unit_masterDAL umDAL = new unit_masterDAL();
        int val = umDAL.insert_unit(umBAL);

        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('Unit Alredy Exists Please Enter Another Category.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('Succesfully Inserted Unit.')</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('Unit Updated Successfully.')</script>");
        }

        hfcatid.Value = "";
        txtunit.Text = "";
        loadgridview();
    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnview")
        {
            unit_masterBAL umBAL = new unit_masterBAL();
            umBAL.um_id = Convert.ToInt16(e.CommandArgument.ToString());

            unit_masterDAL umDAL = new unit_masterDAL();
            DataSet ds = umDAL.get_unit_for_edit(umBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfcatid.Value = ds.Tables[0].Rows[0]["um_id"].ToString();
                txtunit.Text = ds.Tables[0].Rows[0]["um_name"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Sorry data does not exists');</script>");

            }
        }
        //else if (e.CommandName.ToString() == "btndelete")
        //{
        //    string id = e.CommandArgument.ToString();
        //    unit_masterBAL umBAL = new unit_masterBAL();
        //    umBAL.um_id = Convert.ToInt32(id);
        //    unit_masterDAL umDAL = new unit_masterDAL();
        //    umDAL.delete_unit(umBAL);
        //    loadgridview();
        //}
    }
}