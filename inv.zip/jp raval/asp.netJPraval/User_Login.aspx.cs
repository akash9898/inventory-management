﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class User_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            Session["login"] = null;
            Session.Clear();
            Session.Abandon();
        }
        if (Session["login_admin"] != null)
        {
            Session["login_admin"] = null;
            Session.Clear();
            Session.Abandon();
        }
        if (Session["login_service"] != null)
        {
            Session["login_service"] = null;
            Session.Clear();
            Session.Abandon();
        }
    }

    //protected void btnlogin_Click(object sender, EventArgs e)
    //{
    //    if (Session["login"] != null)
    //    {
    //        Session["login"] = null;
    //        Session.Clear();
    //        Session.Abandon();
    //    }
    //    if (Session["login_admin"] != null)
    //    {
    //        Session["login_admin"] = null;
    //    }
    //    if (Session["login_service"] != null)
    //    {
    //        Session["login_service"] = null;
    //    }

    //    admin_userBAL aduBAL = new admin_userBAL();
    //    aduBAL.admn_usr_mobile_no = txtmobileno.Text;
    //    aduBAL.admn_usr_password = txtpassword.Text;
    //    admin_userDAL aduDAL = new admin_userDAL();
    //    string[] rval = aduDAL.admin_user_login(aduBAL).ToString().Split('|');
    //    if (rval[0].ToString() == "0")
    //    {
    //        Response.Write("<script>alert('Mobile No or Password Wrong');</script>");

    //    }
    //    else if (rval[0].ToString() == "1")
    //    {

    //        Response.Write("<script>alert('Your account is disabled please contact super user of system');</script>");

    //    }
    //    else if (rval[0].ToString() == "2" && rval[2].ToString() == "1")
    //    {
    //        Session["login"] = rval[1].ToString();
    //        Session["login_admin"] = rval[1].ToString();
    //        Response.Redirect("Todays_Service_Details.aspx");
    //    }
    //    else if (rval[0].ToString() == "2" && rval[2].ToString() == "2")
    //    {
    //        Session["login"] = rval[1].ToString();
    //        Session["login_service"] = rval[1].ToString();
    //        Response.Redirect("Get_All_Reminders.aspx");
    //    }
    //}


    protected void btnlogin_Click(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            Session["login"] = null;
            Session.Clear();
            Session.Abandon();
        }
        if (Session["login_admin"] != null)
        {
            Session["login_admin"] = null;

        }
        if (Session["login_service"] != null)
        {
            Session["login_service"] = null;

        }

        admin_userBAL aduBAL = new admin_userBAL();
        aduBAL.admn_usr_mobile_no = txtmobileno.Text;
        aduBAL.admn_usr_password = txtpassword.Text;
        admin_userDAL aduDAL = new admin_userDAL();
        string[] rval = aduDAL.admin_user_login(aduBAL).ToString().Split('|');

        //password or mobile is wrong!
        if (rval[0].ToString() == "0" && rval[1].ToString() == "0")
        {
            Response.Write("<script>alert('Mobile No or Password Wrong');</script>");

        }

        //account disabled
        else if (rval[0].ToString() == "1" && rval[1].ToString() == "0")
        {

            Response.Write("<script>alert('Your account is disabled please contact super user of system');</script>");

        }

        //for normal user
        else if (rval[0].ToString() == "2" && rval[2].ToString() == "1")
        {
            Session["login"] = rval[1].ToString();
            Session.Timeout = 99999;

            Session["login_admin"] = rval[1].ToString();
            Session.Timeout = 99999;

            Response.Redirect("Todays_Service_Details.aspx");
        }

        //this is for super user
        else if (rval[0].ToString() == "2" && rval[2].ToString() == "2")
        {
            Session["login"] = rval[1].ToString();
            Session.Timeout = 99999;
            Session["login_admin"] = rval[1].ToString();
            Session.Timeout = 99999;
            Session["super_user"] = rval[1].ToString();
            Session.Timeout = 99999;
            Response.Redirect("Todays_Service_Details.aspx");

        }

        //for normal user
        else if (rval[0].ToString() == "2" && rval[2].ToString() == "3")
        {
            Session["login"] = rval[1].ToString();
            Session.Timeout = 99999;
            Session["login_service"] = rval[1].ToString();
            Session.Timeout = 99999;
            Response.Redirect("Get_All_Reminders.aspx");


        }



    }


}