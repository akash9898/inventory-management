﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Web.Services;
using System.Data;
using System.Web.Script.Services;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;


public partial class Search_Bill : System.Web.UI.Page
{
    //load supplier bill data
    public void loadgridsupplierbill()
    {
        supplier_purchse_bill_masterBAL spbmBAL = new supplier_purchse_bill_masterBAL();

        //1-whilte
        //0->black
        if (Session["super_user"] != null)
        {
            spbmBAL.spb_status = 0;
        }
        else
        {
            spbmBAL.spb_status = 1;
        }

        supplier_search_detailsDAL ssdDAL = new supplier_search_detailsDAL();
        DataSet ds = ssdDAL.get_supplier_bill_details(spbmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeatersupplierdata.DataSource = ds;
            gridrepeatersupplierdata.DataBind();
        }
        else
        {
            gridrepeatersupplierdata.DataSource = null;
            gridrepeatersupplierdata.DataBind();
        }
    }

    //load customer bill data
    public void loadgridcustomerbill()
    {
        sales_bill_masterBAL sbmBAL = new sales_bill_masterBAL();

        if (Session["super_user"] != null)
        {
            sbmBAL.sbm_status = 0;
        }
        else
        {
            sbmBAL.sbm_status = 1;
        }
        supplier_search_detailsDAL ssdDAL = new supplier_search_detailsDAL();
        DataSet ds = ssdDAL.get_customer_bill_details(sbmBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {


            gridrepeatercustomerdata.DataSource = ds;
            gridrepeatercustomerdata.DataBind();

        }
        else
        {
            gridrepeatercustomerdata.DataSource = null;
            gridrepeatercustomerdata.DataBind();
        }
    }


    //page load event
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {

                if (Request.QueryString["purchase_sales_billid"] == null)
                {
                    Response.Redirect("User_Login.aspx");
                }

                if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 1)
                {
                    supplier_list.Visible = true;
                    customer_list.Visible = false;
                    loadgridsupplierbill();
                }
                else if (Request.QueryString["purchase_sales_billid"].ToString() == "2")
                {
                    supplier_list.Visible = false;
                    customer_list.Visible = true;
                    loadgridcustomerbill();
                }
                else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) > 2 || Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 0)
                {
                    Response.Redirect("User_Login.aspx");
                }

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");

        }
    }

    //grid reapeaterc code
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

        if (e.CommandName == "btnview")
        {
            Response.Redirect("Supplier_Purchase_Bill.aspx?spid=" + e.CommandArgument.ToString() + "&purchase_sales_billid=" + Request.QueryString["purchase_sales_billid"]);
        }
        else if (e.CommandName == "btnpay")
        {
            Response.Redirect("Bill_Payment.aspx?spid=" + e.CommandArgument.ToString() + "&purchase_sales_billid=" + Request.QueryString["purchase_sales_billid"]);
        }
        else if(e.CommandName == "btnpdfDownload")
        {
            Response.Redirect("invoiceDownload.aspx?spid=" + e.CommandArgument.ToString() + "&purchase_sales_billid=" + Request.QueryString["purchase_sales_billid"]);
        }
    }

    //get supplier bill id
    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public static string[] GetSuppliersBilId(string prefix)
    {
        List<string> supblid = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select spb_purchase_bill_id from supplier_purchase_bill_master where (spb_purchase_bill_id like @SearchText) ", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");
            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                supblid.Add(string.Format("{0}", sdr["spb_purchase_bill_id"]));
            }
            con.Close();
        }

        return supblid.ToArray();

    }


    //get supplier name
    [WebMethod]
    public static string[] GetSuppliersName(string prefix)
    {
        List<string> supblid = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select sup_business_name from supplier_master where sup_business_name like @SearchText", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");
            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                supblid.Add(string.Format("{0}", sdr["sup_business_name"]));
            }
            con.Close();
        }

        return supblid.ToArray();

    }



    //seach by customer name
    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public static string[] GetCustomer(string prefix)
    {
        List<string> customer = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select cust_first_name,cust_middle_name,cust_last_name from customer_master where (cust_first_name like @SearchText) or (cust_middle_name like @SearchText) or (cust_last_name like @SearchText)", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");
            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                customer.Add(string.Format("{0}-{1}-{2}", sdr["cust_first_name"], sdr["cust_middle_name"], sdr["cust_last_name"]));
            }
            con.Close();
        }

        return customer.ToArray();
    }

    //search by customer id
    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public static string[] GetCustomerBilId(string prefix)
    {
        List<string> cusblid = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select sbm_sales_bill_id from sales_bill_master where (sbm_sales_bill_id like @SearchText) ", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");
            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                cusblid.Add(string.Format("{0}", sdr["sbm_sales_bill_id"]));
            }
            con.Close();
        }

        return cusblid.ToArray();

    }




    //search on click
    protected void searchbill_Click(object sender, EventArgs e)
    {

        if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 1)
        {

            supplier_purchse_bill_masterBAL spbmBAL = new supplier_purchse_bill_masterBAL();
            // spbmBAL.spb_sales_purchase_id = Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString());
            spbmBAL.spb_purchase_bill_id = txtbillno.Value;
            // spbmBAL.startdate = datefrom.Text;
            // spbmBAL.enddate = dateto.Text;

            if (datefrom.Text.ToString() != "")
            {
                spbmBAL.startdate = Convert.ToDateTime(datefrom.Text).ToString("yyyy-MM-dd 00:00:00");
            }
            if (dateto.Text.ToString() != "")
            {
                spbmBAL.enddate = Convert.ToDateTime(dateto.Text).ToString("yyyy-MM-dd 00:00:00");
            }

            supplier_masterBAL smBAL = new supplier_masterBAL();
            smBAL.sup_business_name = txtsupname.Value;


            supplier_search_detailsDAL ssdDAL = new supplier_search_detailsDAL();
            DataSet ds = ssdDAL.get_supplier_bill_details_click_event(spbmBAL, smBAL);


            if (ds.Tables[0].Rows.Count > 0)
            {
                gridrepeatersupplierdata.DataSource = ds;
                gridrepeatersupplierdata.DataBind();
            }
            else
            {
                gridrepeatersupplierdata.DataSource = null;
                gridrepeatersupplierdata.DataBind();
            }





        }


        else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 2)
        {
            sales_bill_masterBAL sbmBAL = new sales_bill_masterBAL();
            sbmBAL.sbm_sales_bill_id = txtbillno.Value;

            if (datefrom.Text.ToString() != "")
            {
                sbmBAL.startdate = Convert.ToDateTime(datefrom.Text ).ToString("yyyy-MM-dd 00:00:00");
            }
            if (dateto.Text.ToString() != "")
            {
                sbmBAL.enddate = Convert.ToDateTime(dateto.Text).ToString("yyyy-MM-dd 00:00:00");
            }

            customer_masterBAL cmBAL = new customer_masterBAL();
            cmBAL.cust_first_name = txtsupname.Value;
            cmBAL.cust_middle_name = txtsupname.Value;
            cmBAL.cust_last_name = txtsupname.Value;

            supplier_masterBAL smBAL = new supplier_masterBAL();
            smBAL.sup_business_name = txtsupname.Value;


            // sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
            supplier_search_detailsDAL ssdDAL = new supplier_search_detailsDAL();
            DataSet ds = ssdDAL.get_customer_bill_details_click_event(sbmBAL, cmBAL);

            if (ds.Tables[0].Rows.Count > 0)
            {
                gridrepeatercustomerdata.DataSource = ds;
                gridrepeatercustomerdata.DataBind();
            }
            else
            {
                gridrepeatercustomerdata.DataSource = null;
                gridrepeatercustomerdata.DataBind();
            }
        }

    }


}




