﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Voucher_List : System.Web.UI.Page
{
    void loadvouchergrid()
    {
        voucher_masterDAL vmDAL = new voucher_masterDAL();
        DataSet ds = vmDAL.get_voucher_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeatervoucherlist.DataSource = ds;
            gridrepeatervoucherlist.DataBind();
        }
        else
        {
            gridrepeatervoucherlist.DataSource = null;
            gridrepeatervoucherlist.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["login_admin"] != null)
            {

                loadvouchergrid();
            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }

    protected void gridrepeatervoucherlist_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnviewedit")
        {
            Response.Redirect("Create_Voucher.aspx?vm_id=" + Convert.ToInt32(e.CommandArgument.ToString()));
        }


    }
}