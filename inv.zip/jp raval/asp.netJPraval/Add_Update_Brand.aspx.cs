﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Brand : System.Web.UI.Page
{
    void loadgridview()
    {
        brand_masterDAL bmDAL = new brand_masterDAL();
        DataSet ds = bmDAL.get_brand_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                loadgridview();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {

        brand_masterBAL bmBAL = new brand_masterBAL();
        if (hfcatid.Value.ToString() == "")
        {
            bmBAL.bm_rid = 0;
        }
        else if (hfcatid.Value.ToString() != "")
        {
            bmBAL.bm_rid = Convert.ToInt16(hfcatid.Value.ToString());
        }

        bmBAL.bm_name = txtbrand.Text.Trim().Replace('-','~') .ToUpper();
        bmBAL.bm_insrid = Convert.ToInt32(Session["login"].ToString());
        bmBAL.bm_insdt = System.DateTime.Now;
        bmBAL.bm_logrid = Convert.ToInt32(Session["login"].ToString());
        bmBAL.bm_logdt = System.DateTime.Now;

        brand_masterDAL bmDAL = new brand_masterDAL();
        int val = bmDAL.insert_brand(bmBAL);

        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('Brand Alredy Exists Please Enter Another Category.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('Succesfully Inserted Brand.')</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('Brand Updated Successfully.')</script>");
        }

        hfcatid.Value = "";
        txtbrand.Text = "";
        loadgridview();

    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnview")
        {
            brand_masterBAL bmBAL = new brand_masterBAL();
            bmBAL.bm_rid = Convert.ToInt16(e.CommandArgument.ToString());

            brand_masterDAL bmDAL = new brand_masterDAL();
            DataSet ds = bmDAL.get_brand_for_edit(bmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfcatid.Value = ds.Tables[0].Rows[0]["bm_rid"].ToString();
                txtbrand.Text = ds.Tables[0].Rows[0]["bm_name"].ToString();

            }
            else
            {
                Response.Write("<script>alert('Sorry data does not exists');</script>");

            }
        }
        //else if (e.CommandName.ToString() == "btndelete")
        //{
        //    string id = e.CommandArgument.ToString();
        //    brand_masterBAL bmBAL = new brand_masterBAL();
        //    bmBAL.bm_rid = Convert.ToInt32(id);
        //    brand_masterDAL bmDAL = new brand_masterDAL();
        //    bmDAL.delete_brand(bmBAL);
        //    loadgridview();
        //}
    }
}