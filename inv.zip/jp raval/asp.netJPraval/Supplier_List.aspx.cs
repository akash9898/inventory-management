﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Supplier_List : System.Web.UI.Page
{
    void loadsuppliergrid()
    {
        supplier_masterDAL supDAL = new supplier_masterDAL();
        DataSet ds = supDAL.get_supplier_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            suppliergrid.DataSource = ds;
            suppliergrid.DataBind();
        }
        else
        {
            suppliergrid.DataSource = null;
            suppliergrid.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if ((Session["login_admin"]) != null)
            {
                loadsuppliergrid();
            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument.ToString());
        if (e.CommandName == "btnview")
        {
            Response.Redirect("Add_Update_Supplier.aspx?supid=" + id);
        }
    }
}