﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class edit_idle_selling_price : System.Web.UI.Page
{
    void lblprdvarname()
    {
        idle_selleing_priceBAL ispBAL = new idle_selleing_priceBAL();
        ispBAL.idle_prod_var_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());

        idle_selling_priceDAL ispDAL = new idle_selling_priceDAL();
        DataSet ds = ispDAL.get_product_var_name_for_edit(ispBAL);

        if (ds.Tables[0].Rows.Count > 0)
        {
            prdvarname.Text = ds.Tables[0].Rows[0]["prvm_product_variation_name"].ToString();
            txtprdsellprice.Text = ds.Tables[0].Rows[0]["idle_prod_selling_price"].ToString();
            hfedle_sell_id.Value = ds.Tables[0].Rows[0]["idle_sell_id"].ToString();

        }
        else
        {
            product_masterBAL pmBAL = new product_masterBAL();
            pmBAL.prvm_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());

            idle_selling_priceDAL ispDAL_name = new idle_selling_priceDAL();
            DataSet ds_name = ispDAL_name.get_product_variation_name(pmBAL);

            if (ds_name.Tables[0].Rows.Count > 0)
            {
                prdvarname.Text = ds_name.Tables[0].Rows[0]["prvm_product_variation_name"].ToString();
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {

                lblprdvarname();

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        idle_selleing_priceBAL ispBAL = new idle_selleing_priceBAL();
        if (hfedle_sell_id.Value.ToString() == "")
        {
            ispBAL.idle_sell_id = 0;
        }
        else if (hfedle_sell_id.Value.ToString() != "")
        {
            ispBAL.idle_sell_id = Convert.ToInt32(hfedle_sell_id.Value.ToString());
        }

        ispBAL.idle_prod_var_id = Convert.ToInt32(Request.QueryString["prd_id"].ToString());
        ispBAL.idle_prod_var_name = prdvarname.Text;
        ispBAL.idle_prod_selling_price = Convert.ToInt32(txtprdsellprice.Text);

        ispBAL.idle_insrid = Convert.ToInt32(Session["login"].ToString());
        ispBAL.idle_insdt = System.DateTime.Now;
        ispBAL.idle_logrid = Convert.ToInt32(Session["login"].ToString());
        ispBAL.idle_logdt = System.DateTime.Now;

        idle_selling_priceDAL ispDAL = new idle_selling_priceDAL();
        ispDAL.insert_into_idle_selling_price(ispBAL);

        if (hfedle_sell_id.Value.ToString() == "")
        {
            Response.Write("<script>alert('Selling Price Inserted Succesfully.');window.location.href='idle_selling_price.aspx';</script>");
        }
        else if (hfedle_sell_id.Value.ToString() != "")
        {
            Response.Write("<script>alert('Selling Price Updated Succesfully.');window.href.location='idle_selling_price.aspx'</script>");
        }

    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}