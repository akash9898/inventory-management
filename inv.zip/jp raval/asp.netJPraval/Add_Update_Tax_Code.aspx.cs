﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Tax_Code : System.Web.UI.Page
{
    void loadtaxgrid()
    {
        tax_code_masterDAL txcdDAL = new tax_code_masterDAL();
        DataSet ds = txcdDAL.get_tax_code_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridtaxrepeater.DataSource = ds;
            gridtaxrepeater.DataBind();
        }
        else
        {
            gridtaxrepeater.DataSource = null;
            gridtaxrepeater.DataBind();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["login"] != null)
            {
                loadtaxgrid();
            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {

        tax_code_masterBAL txcdBAL = new tax_code_masterBAL();
        if (hftaxcodeid.Value.ToString() == "")
        {
            txcdBAL.txcd_id = 0;
        }
        else if (hftaxcodeid.Value.ToString() != "")
        {
            txcdBAL.txcd_id = Convert.ToInt16(hftaxcodeid.Value.ToString());
        }

        txcdBAL.txcd_name = txttax.Text.Trim().Replace('-',' ').Trim().ToUpper();
        txcdBAL.txcd_cgst = float.Parse(txtcgst.Text.Trim().Replace('-','~').ToString());
        txcdBAL.txcd_sgst = float.Parse(txtsgst.Text.Trim().Replace('-','~').ToString());
        txcdBAL.txcd_igst = float.Parse(txtigst.Text.Trim().Replace('-','~').ToString());
        txcdBAL.txcd_insrid = Convert.ToInt32(Session["login"].ToString());
        txcdBAL.txcd_insdt = System.DateTime.Now;
        txcdBAL.txcd_logrid = Convert.ToInt32(Session["login"].ToString());
        txcdBAL.txcd_logdt = System.DateTime.Now;

        tax_code_masterDAL txcdDAL = new tax_code_masterDAL();
        int ret_tax_val = txcdDAL.insert_into_tax_code(txcdBAL);

        if (ret_tax_val == 2)
        {
            Response.Write("<script>alert('Tax Code Inserted Succesfully!');window.location.href='Add_Update_Tax_Code.aspx';</script>");
        }

        else if (ret_tax_val == 1)
        {
            Response.Write("<script>alert('Tax Code Alredy Exists!')</script>");
        }
        else if (ret_tax_val == 3)
        {
            Response.Write("<script>alert('Tax Code Updated Succesfully!');window.location.href='Add_Update_Tax_Code.aspx'; </script>");
        }
        loadtaxgrid();
    }



    protected void gridtaxrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnview")
        {

            int id = Convert.ToInt32(e.CommandArgument.ToString());
            tax_code_masterBAL txcdBAL = new tax_code_masterBAL();
            txcdBAL.txcd_id = id;

            tax_code_masterDAL txcdDAL = new tax_code_masterDAL();
            DataSet ds = txcdDAL.get_tax_code_list_for_edit(txcdBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hftaxcodeid.Value = ds.Tables[0].Rows[0]["txcd_id"].ToString();
                txttax.Text= ds.Tables[0].Rows[0]["txcd_name"].ToString();
                txtcgst.Text= ds.Tables[0].Rows[0]["txcd_cgst"].ToString();
                txtsgst.Text= ds.Tables[0].Rows[0]["txcd_sgst"].ToString();
                txtigst.Text = ds.Tables[0].Rows[0]["txcd_igst"].ToString();

            }

            //Text.Trim().Replace('-',' ')box enable edit
            txttax.Enabled = false;
            txtigst.Enabled = false;
            txtcgst.Enabled = false;
            txtsgst.Enabled = false;
            btnsave.Visible = false;
            btnupdate.Visible = true;

        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        txttax.Enabled = true;
        txtigst.Enabled = true;
        txtcgst.Enabled = true;
        txtsgst.Enabled = true;
        btnsave.Visible = true;
        btnsave.Text = "Update";
        btnupdate.Visible = false;
    }
}