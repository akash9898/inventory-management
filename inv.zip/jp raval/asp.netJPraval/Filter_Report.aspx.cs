﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Filter_Report : System.Web.UI.Page
{
    public void fill_product_dropdown()
    {
        category_masterDAL cmDAL = new category_masterDAL();
        DataSet ds = cmDAL.get_category_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            drpprdcat.DataSource = ds;
            drpprdcat.DataTextField = "cat_name";
            drpprdcat.DataValueField = "cat_id";

            drpprdcat.DataBind();
            drpprdcat.Items.Insert(0, "--- Select Product Category ---");
            drpprdcat.Items[0].Value = "0";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                fill_product_dropdown();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {

    }
}