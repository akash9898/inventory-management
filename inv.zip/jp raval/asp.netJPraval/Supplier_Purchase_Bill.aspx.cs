﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Collections;
using System.Web.Script.Services;


public partial class Supplier_Purchase_Bill : System.Web.UI.Page
{  //dropdown page load event
    //dropdown page load event
    public void loadpaydrp()
    {
        mode_of_paymentDAL mopDAL = new mode_of_paymentDAL();
        DataSet ds = mopDAL.get_mode_of_payment_list();
        if (ds.Tables[0].Rows.Count > 0)
        {

            drpmop.DataSource = ds;
            drpmop.DataTextField = "mop_name";
            drpmop.DataValueField = "mop_id";
            drpmop.DataBind();
            drpmop.Items.Insert(0, "--- Select Mode Of Payment ---");

        }
    }

    //dropdown current financial year
    public void loadfinyear()
    {
        financial_year_masterDAL fymDAL = new financial_year_masterDAL();
        DataSet ds = fymDAL.get_all_financial_year();

        if (ds.Tables[0].Rows.Count > 0)
        {
            drpfinyear.DataSource = ds;
            drpfinyear.DataTextField = "financial_year";
            drpfinyear.DataValueField = "financial_year_id";
            drpfinyear.DataBind();
            drpfinyear.Items.Insert(0, "--- Select Financial Year ---");
        }

    }

    public void load_current_financial_year()
    {
        financial_year_masterDAL fmDAL = new financial_year_masterDAL();

        string value = fmDAL.get_current_financial_year();
        drpfinyear.Items.FindByText(value).Selected = true;



    }


    protected void Page_Load(object sender, EventArgs e)
    {

        //for super_user
        if (Session["login"] != null && Session["super_user"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["purchase_sales_billid"] == null)
                {

                    Response.Redirect("User_Login.aspx");
                }

                if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 1)
                {
                    if (Request.QueryString["spid"] != null && Request.QueryString["spid"].ToString() != "")
                    {
                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();

                        supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                        spbdBAL.spbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());


                        supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                        sbmDAL.get_data_for_search_supplier_edit(spbdBAL);

                    }
                    else
                    {
                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();
                    }
                }


                else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 2)
                {
                    if (Request.QueryString["spid"] != null && Request.QueryString["spid"].ToString() != "")
                    {

                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();

                        sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
                        //supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                        sbdBAL.sbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());


                        sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
                        sbmDAL.get_data_for_search_customer_edit(sbdBAL);

                    }
                    else
                    {
                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();
                    }
                }

                else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) > 2 || Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 0)
                {
                    Response.Redirect("User_Login.aspx");
                }

            }
        }


        //for normal user
        else if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["purchase_sales_billid"] == null)
                {

                    Response.Redirect("User_Login.aspx");
                }

                if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 1)
                {
                    if (Request.QueryString["spid"] != null && Request.QueryString["spid"].ToString() != "")
                    {
                        //load payment drop
                        loadpaydrp();

                        //load financial year drop
                        loadfinyear();

                        supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                        spbdBAL.spbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());


                        supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                        sbmDAL.get_data_for_search_supplier_edit(spbdBAL);

                    }
                    else
                    {
                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();
                        load_current_financial_year();
                    }
                }


                else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 2)
                {
                    if (Request.QueryString["spid"] != null && Request.QueryString["spid"].ToString() != "")
                    {

                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();


                        supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                        spbdBAL.spbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());


                        supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                        // sbmDAL.get_data_for_search_customer_edit(spbdBAL);

                    }
                    else
                    {
                        //load payment dropdown
                        loadpaydrp();

                        //load financial year dropodown
                        loadfinyear();
                        load_current_financial_year();
                    }
                }

                else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) > 2 || Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 0)
                {
                    Response.Redirect("User_Login.aspx");
                }

            }
        }


        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    static DropDownList dl;

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        //  AddNewRowToGrid();
    }

    //get suppliers list
    [WebMethod]
    public static string[] GetSuppliers(string prefix)
    {
        List<string> customers = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select sup_id,sup_business_name,sup_primary_ctn from supplier_master where sup_business_name like @SearchText", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");
            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                customers.Add(string.Format("{0}-{1}-{2}", sdr["sup_business_name"], sdr["sup_primary_ctn"], sdr["sup_id"]));
            }

            con.Close();

        }
        return customers.ToArray();
    }


    //get product list
    [WebMethod]
    public static string[] GetProduct(string prefix)
    {
        List<string> product = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select prvm_id,prvm_pdrm_id,min(prdm_name),min(bm_name),min(cat_name),prvm_product_variation_name,txcd_cgst,txcd_sgst,txcd_igst,txcd_name,min(idle_prod_selling_price) from get_all_product_details where (prdm_name like @SearchText) or (bm_name like @SearchText) or (cat_name like @SearchText) or (oth_cat_name like @SearchText) or(prvm_product_variation_name like @SearchText) group by prvm_id", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");

            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                product.Add(string.Format("{0}-{1}-{2}-{3}-{4}-{5}-{6}-{7}-{8}-{9}-{10}",
                sdr["min(prdm_name)"], sdr["min(bm_name)"], sdr["min(cat_name)"],
                sdr["prvm_product_variation_name"], sdr["prvm_pdrm_id"],
                sdr["prvm_id"], sdr["txcd_cgst"], sdr["txcd_sgst"],
                sdr["txcd_igst"], sdr["txcd_name"],
                sdr["min(idle_prod_selling_price)"]));
            }

            con.Close();

        }
        return product.ToArray();
    }


    //get customer list
    [WebMethod]
    public static string[] GetCustomer(string prefix)
    {
        List<String> customers = new List<string>();
        using (MySqlConnection con = new MySqlConnection())
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

            MySqlCommand cmd = new MySqlCommand("select * from customer_master where (cust_first_name like @SearchText) or (cust_middle_name like @SearchText) or (cust_last_name like @SearchText)", con);
            cmd.Parameters.AddWithValue("@SearchText", "%" + prefix + "%");

            cmd.Connection = con;
            con.Open();
            MySqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                customers.Add(string.Format("{0}-{1}-{2}-{3}-{4}", sdr["cust_first_name"], sdr["cust_middle_name"], sdr["cust_last_name"], sdr["cust_id"], sdr["cust_primary_ctn"]));
            }

            con.Close();

        }
        return customers.ToArray();
    }


    protected void btnregister_Click(object sender, EventArgs e)
    {

    }



    //insert into supplier product bill
    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public static void InsertProduct(List<productEntry> productData) //productEntry[] pEntry
    {

        //var data = JsonConvert.SerializeObject(productData);
        float totalPrice = 0;
        int supid = 0;
        string prch_Date = "0";
        string sup_bl_id = "0";
        float product_price = 0;
        int purchase_sales_billid = 0;
        int mopval = 0;
        float actualTotalPrice = 0;
        string financial_year = "0";

        //for sum of total price
        foreach (productEntry pdata1 in productData)
        {
            totalPrice += float.Parse((pdata1.pTotal).ToString());
            actualTotalPrice += float.Parse((pdata1.product_actual_total_amount).ToString());
            supid = pdata1.supId;
            prch_Date = Convert.ToString(pdata1.purchase_date);
            sup_bl_id = pdata1.sup_billid;
            product_price = float.Parse((pdata1.product_price).ToString());
            purchase_sales_billid = pdata1.purchase_sales_billid;
            mopval = pdata1.mopVal;
            financial_year = pdata1.financial_year.ToString();
        }


        //---------->check if the id == 1 then purchase bill

        if (purchase_sales_billid == 1)
        {
            //insert into supplier purchase bill master
            supplier_purchse_bill_masterBAL supBAL = new supplier_purchse_bill_masterBAL();
            supBAL.spb_supplier_id = supid;
            // supBAL.spb_sales_purchase_id = purchase_sales_billid;
            supBAL.spb_purchase_bill_id = sup_bl_id.Trim().ToUpper();
            supBAL.spb_purchase_date = Convert.ToDateTime(prch_Date);

            supBAL.spb_total_amount = Convert.ToInt32(Math.Round(totalPrice));
            supBAL.spb_total_actual_amount = actualTotalPrice;

            //1->while
            //0-->black
            if (HttpContext.Current.Session["super_user"] == null)
            {
                supBAL.spb_status = 1;
            }
            else if (HttpContext.Current.Session["super_user"] != null)
            {
                supBAL.spb_status = 0;
            }

            //financial year
            supBAL.spb_financial_year = financial_year;

            //mode of payment added newly 
            supBAL.spb_mode_of_payment = mopval;

            supBAL.spb_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            supBAL.spb_insdt = System.DateTime.Now;
            supBAL.spb_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            supBAL.spb_logdt = System.DateTime.Now;

            supplier_bill_masterDAL supDAL = new supplier_bill_masterDAL();
            String ret_val = supDAL.insert_into_supplier_purchase_bill_master(supBAL);

            string[] v1 = new string[2];
            v1 = ret_val.Split('|');

            int bill_id = Convert.ToInt32(v1[1]);
            int ret_val_chl = Convert.ToInt32(v1[0]);



            //inset into supplier purchase bill details

            foreach (productEntry pdata1 in productData)
            {
                supplier_purchase_bill_detailBAL supdBAL = new supplier_purchase_bill_detailBAL();
                supdBAL.spbd_bill_id = bill_id;
                supdBAL.spbd_product_id = Convert.ToInt32(pdata1.productVarId);

                //billing price
                supdBAL.spbd_product_price = float.Parse((pdata1.pPrice).ToString());
                //product actual quentity
                supdBAL.spbd_product_actual_price = float.Parse((pdata1.product_actual_price).ToString());


                //billing quentity
                supdBAL.spbd_quentity = Convert.ToInt32(pdata1.pQty);
                //actual quentity
                supdBAL.spbd_actual_quentity = Convert.ToInt32(pdata1.product_actual_quentity);

                //billing total
                supdBAL.spbd_total = Convert.ToInt32(pdata1.pTotal);
                //actual total
                supdBAL.spbd_actual_total = Convert.ToInt32(pdata1.product_actual_total_amount);


                //discount
                supdBAL.spbd_discount = float.Parse((pdata1.product_discount).ToString());
                supdBAL.spbd_discount_amount = (Convert.ToInt32(pdata1.pTotal) * float.Parse((pdata1.product_discount).ToString())) / 100;

                //gst values
                supdBAL.spbd_cgst = float.Parse(pdata1.cgst.ToString());
                supdBAL.spbd_sgst = float.Parse(pdata1.sgst.ToString());
                supdBAL.spbd_igst = float.Parse(pdata1.igst.ToString());


                supdBAL.spbd_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                supdBAL.spbd_insdt = System.DateTime.Now;
                supdBAL.spbd_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                supdBAL.spbd_logdt = System.DateTime.Now;

                supplier_bill_masterDAL supdDAL = new supplier_bill_masterDAL();
                supDAL.insert_into_supplier_purchase_bill_details(supdBAL);
            }


            //insert into supplier purchase bill payment
            supplier_purchse_bill_paymentBAL spbBAL = new supplier_purchse_bill_paymentBAL();

            var mopVal = 0;
            var mopAMO = 0;
            var date = "0";


            foreach (productEntry pdata1 in productData)
            {
                mopVal = pdata1.mopVal;
                mopAMO = Convert.ToInt32(pdata1.mopAMO);
                date = pdata1.purchase_date;
            }

            if (mopval == 1)
            {
                mopAMO = Convert.ToInt32(Math.Round(actualTotalPrice).ToString());

            }


            spbBAL.spbp_bill_id = bill_id;
            //this is mode of payment changed  --> spbBAL.spbp_mod_of_payment = mopVal <-- this is original one only goes 1 value for future change!
            spbBAL.spbp_mod_of_payment = 1;

            //total cash payment
            if (mopval == 1 || mopval == 2)
            {
                spbBAL.spbp_date_of_payment = Convert.ToDateTime(date);
            }
            else if (mopval == 3)
            {
                spbBAL.spbp_date_of_payment = System.DateTime.Now;
            }


            spbBAL.spbp_amount = Convert.ToInt32(mopAMO);
            spbBAL.spbp_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            spbBAL.spbp_insdt = System.DateTime.Now;
            spbBAL.spbp_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            spbBAL.spbp_logdt = System.DateTime.Now;

            supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
            sbmDAL.insert_into_supplier_purchase_bill_payment(spbBAL);

        }

        //---------->check if the id == 2 then sales bill
        else if (purchase_sales_billid == 2)
        {
            //insert into sales purchase bill master
            sales_bill_masterBAL sbmBAL = new sales_bill_masterBAL();
            sbmBAL.customer_id = supid;
            sbmBAL.sbm_sales_bill_id = sup_bl_id.Trim().ToUpper();
            sbmBAL.sbm_sales_date = Convert.ToDateTime(prch_Date);

            sbmBAL.sbm_total_amount = Convert.ToInt32(Math.Round(totalPrice));
            sbmBAL.sbm_total_actual_amount = actualTotalPrice;

            //1->while
            //0-->black
            if (HttpContext.Current.Session["super_user"] == null)
            {
                sbmBAL.sbm_status = 1;
            }
            else if (HttpContext.Current.Session["super_user"] != null)
            {
                sbmBAL.sbm_status = 0;
            }

            sbmBAL.sbm_financial_year = financial_year.ToString();

            //mode of payment added
            sbmBAL.sbm_mode_of_payment = Convert.ToInt32(mopval.ToString());


            sbmBAL.sbm_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            sbmBAL.sbm_insdt = System.DateTime.Now;
            sbmBAL.sbm_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            sbmBAL.sbm_logdt = System.DateTime.Now;

            sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
            String ret_val = sbmDAL.insert_into_sales_bill_master(sbmBAL);

            string[] v1 = new string[2];
            v1 = ret_val.Split('|');

            int bill_id = Convert.ToInt32(v1[1]);
            int ret_val_chl = Convert.ToInt32(v1[0]);



            //inset into supplier purchase bill details

            foreach (productEntry pdata1 in productData)
            {
                sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
                sbdBAL.sbd_bill_id = bill_id;
                sbdBAL.sbd_product_id = Convert.ToInt32(pdata1.productVarId);

                //billing price
                sbdBAL.sbd_product_price = float.Parse((pdata1.pPrice).ToString());
                //product actual quentity
                sbdBAL.sbd_product_actual_price = float.Parse((pdata1.product_actual_price).ToString());


                //billing quentity
                sbdBAL.sbd_quentity = Convert.ToInt32(pdata1.pQty);
                //actual quentity
                sbdBAL.sbd_actual_quentity = Convert.ToInt32(pdata1.product_actual_quentity);

                //billing total
                sbdBAL.sbd_total = Convert.ToInt32(pdata1.pTotal);
                //actual total
                sbdBAL.sbd_actual_total = Convert.ToInt32(pdata1.product_actual_total_amount);


                //discount
                sbdBAL.sbd_discount = float.Parse((pdata1.product_discount).ToString());
                sbdBAL.sbd_discount_amount = (Convert.ToInt32(pdata1.pTotal) * float.Parse((pdata1.product_discount).ToString())) / 100;

                //gst values
                sbdBAL.sbd_cgst = float.Parse(pdata1.cgst.ToString());
                sbdBAL.sbd_sgst = float.Parse(pdata1.sgst.ToString());
                sbdBAL.sbd_igst = float.Parse(pdata1.igst.ToString());


                sbdBAL.sbd_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                sbdBAL.sbd_insdt = System.DateTime.Now;
                sbdBAL.sbd_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                sbdBAL.sbd_logdt = System.DateTime.Now;

                sales_bill_masterDAL sbmdDAL = new sales_bill_masterDAL();
                sbmdDAL.insert_into_sales_bill_details(sbdBAL);
            }


            //insert into supplier purchase bill payment
            sales_bill_paymentBAL sbmpBAL = new sales_bill_paymentBAL();

            var mopVal = 0;
            var mopAMO = 0;
            var date = "0";

            foreach (productEntry pdata1 in productData)
            {
                mopVal = pdata1.mopVal;
                mopAMO = Convert.ToInt32(pdata1.mopAMO);
                date = pdata1.purchase_date;
            }

            if (mopval == 1)
            {
                mopAMO = Convert.ToInt32(Math.Round(actualTotalPrice).ToString());

            }


            sbmpBAL.sbp_bill_id = bill_id;
            sbmpBAL.sbp_mod_of_payment = mopVal;

            //total cash payment
            if (mopval == 1 || mopval == 2)
            {
                sbmpBAL.sbp_date_of_payment = Convert.ToDateTime(date);
            }
            else if (mopval == 3)
            {
                sbmpBAL.sbp_date_of_payment = System.DateTime.Now;
            }


            sbmpBAL.sbp_amount = Convert.ToInt32(mopAMO);
            sbmpBAL.sbp_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            sbmpBAL.sbp_insdt = System.DateTime.Now;
            sbmpBAL.sbp_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            sbmpBAL.sbp_logdt = System.DateTime.Now;

            sales_bill_masterDAL sbmpDAL = new sales_bill_masterDAL();
            sbmpDAL.insert_into_sales_bill_payment(sbmpBAL);
        }
    }


    //update product list
    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public static void Update_Supplier_Bill_Master(List<productEntry> productData)
    {
        int sup_id = 0;
        string sup_bill_id = "0";
        string prch_Date = "0";
        int spb_mas_id = 0;
        float tot_price = 0;
        int productVarId = 0;
        int spb_bill_det_id = 0;
        int mopVal = 0;
        int mopAmo = 0;
        float actual_price = 0;
        int purchase_sales_bill_id = 0;
        string financial_year = "";

        //if(Convert.ToInt32(HttpContext.Current.Request.QueryString["purchase_sales_billid"].ToString())==1)

        foreach (productEntry pdata1 in productData)
        {
            sup_id = pdata1.sup_id;
            sup_bill_id = pdata1.sup_billid;
            prch_Date = Convert.ToString(pdata1.purchase_date);
            spb_mas_id = pdata1.spb_mas_id;

            //total billing price
            tot_price += float.Parse((pdata1.pTotal).ToString());

            //actual billing price
            actual_price += float.Parse((pdata1.product_actual_total_amount).ToString());

            productVarId = pdata1.productVarId;

            mopVal = pdata1.mopVal;


            mopAmo = Convert.ToInt32(pdata1.mopAMO);


            //get purchase sales bill id for sales or purchase bill
            //1-->purchase bill
            //2-->sales bill
            purchase_sales_bill_id = Convert.ToInt32(pdata1.purchase_sales_billid);

            //financial year
            financial_year = pdata1.financial_year.ToString();

        }

        if (purchase_sales_bill_id == 1)
        {
            //update supplier purchase bill master
            supplier_purchse_bill_masterBAL sbmBAL = new supplier_purchse_bill_masterBAL();
            sbmBAL.spb_id = spb_mas_id;
            sbmBAL.spb_supplier_id = sup_id;
            sbmBAL.spb_purchase_bill_id = sup_bill_id;
            sbmBAL.spb_purchase_date = Convert.ToDateTime(prch_Date);

            //total billing price
            sbmBAL.spb_total_amount = tot_price;
            //total actuall price
            sbmBAL.spb_total_actual_amount = actual_price;

            //financial year
            sbmBAL.spb_financial_year = financial_year;

            //mode of payment
            sbmBAL.spb_mode_of_payment = mopVal;


            sbmBAL.spb_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            sbmBAL.spb_logdt = System.DateTime.Now;

            supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
            sbmDAL.update_product_bill_master(sbmBAL);

            //update supplier purchase bill details
            foreach (productEntry pdata1 in productData)
            {
                spb_bill_det_id = pdata1.spb_bill_det_id;

                if (spb_bill_det_id > 0)
                {
                    supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                    spbdBAL.spbd_id = pdata1.spb_bill_det_id;
                    spbdBAL.spbd_product_id = pdata1.productVarId;

                    //product billing price 
                    spbdBAL.spbd_product_price = float.Parse((pdata1.pPrice).ToString());
                    //product actual price
                    spbdBAL.spbd_product_actual_price = float.Parse((pdata1.product_actual_price).ToString());

                    //product billing quentity
                    spbdBAL.spbd_quentity = Convert.ToInt32(pdata1.pQty);
                    //product actual quentity
                    spbdBAL.spbd_actual_quentity = Convert.ToInt32(pdata1.product_actual_quentity);

                    //product billing total
                    spbdBAL.spbd_total = Convert.ToInt32(pdata1.pTotal);
                    //product actual total
                    spbdBAL.spbd_actual_total = Convert.ToInt32(pdata1.product_actual_total_amount);

                    //product discount
                    spbdBAL.spbd_discount = float.Parse(pdata1.product_discount.ToString());
                    //product discount amount
                    spbdBAL.spbd_discount_amount = (Convert.ToInt32(pdata1.pTotal) * float.Parse((pdata1.product_discount).ToString())) / 100;

                    spbdBAL.spbd_cgst = pdata1.cgst;
                    spbdBAL.spbd_sgst = pdata1.sgst;
                    spbdBAL.spbd_igst = pdata1.igst;

                    spbdBAL.spbd_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                    spbdBAL.spbd_logdt = System.DateTime.Now;

                    supplier_bill_masterDAL spbdDAL = new supplier_bill_masterDAL();
                    spbdDAL.update_purchase_bill_details(spbdBAL);

                }

                //this is new code insert product
                else if (spb_bill_det_id == 0)
                {
                    supplier_purchase_bill_detailBAL supdBAL = new supplier_purchase_bill_detailBAL();
                    supdBAL.spbd_bill_id = spb_mas_id;
                    supdBAL.spbd_product_id = Convert.ToInt32(pdata1.productVarId);
                    //product billing price
                    supdBAL.spbd_product_price = Convert.ToInt32(pdata1.pPrice);

                    //product actual price
                    supdBAL.spbd_product_actual_price = Convert.ToInt32(pdata1.product_actual_price);

                    //product billing quentity
                    supdBAL.spbd_quentity = Convert.ToInt32(pdata1.pQty);

                    //product actual quentity
                    supdBAL.spbd_actual_quentity = Convert.ToInt32(pdata1.product_actual_quentity);

                    //product billing total
                    supdBAL.spbd_total = Convert.ToInt32(pdata1.pTotal);

                    //product actual total
                    supdBAL.spbd_actual_total = Convert.ToInt32(pdata1.product_actual_total_amount);

                    //product discount
                    supdBAL.spbd_discount = Convert.ToInt32(pdata1.product_discount);

                    //gst values
                    supdBAL.spbd_cgst = float.Parse(pdata1.cgst.ToString());
                    supdBAL.spbd_sgst = float.Parse(pdata1.sgst.ToString());
                    supdBAL.spbd_igst = float.Parse(pdata1.igst.ToString());


                    supdBAL.spbd_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                    supdBAL.spbd_insdt = System.DateTime.Now;
                    supdBAL.spbd_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                    supdBAL.spbd_logdt = System.DateTime.Now;

                    supplier_bill_masterDAL supdDAL = new supplier_bill_masterDAL();
                    supdDAL.insert_into_supplier_purchase_bill_details(supdBAL);

                }
            }

            //update supplier purchase payment bill 
            //supplier_purchse_bill_paymentBAL sbmpBAL = new supplier_purchse_bill_paymentBAL();
            //sbmpBAL.spbp_bill_id = Convert.ToInt32(spb_mas_id);
            //sbmpBAL.spbp_mod_of_payment = mopVal;
            //sbmpBAL.spbp_amount = mopAmo;
            //sbmpBAL.spbp_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            //sbmpBAL.spbp_logdt = System.DateTime.Now;

            //supplier_bill_masterDAL sbmpDAL = new supplier_bill_masterDAL();
            ////sbmpDAL.update_purchase_payment(sbmpBAL);
            //sbmpDAL.insert_into_bill_payment(sbmpBAL);

        }

        else if (purchase_sales_bill_id == 2)
        {
            //update sales bill master
            sales_bill_masterBAL sbmBAL = new sales_bill_masterBAL();
            sbmBAL.sbm_id = spb_mas_id;
            sbmBAL.customer_id = sup_id;
            sbmBAL.sbm_sales_bill_id = sup_bill_id;
            sbmBAL.sbm_sales_date = Convert.ToDateTime(prch_Date);

            //total billing price
            sbmBAL.sbm_total_amount = tot_price;
            //total actual price
            sbmBAL.sbm_total_actual_amount = actual_price;

            //financial year
            sbmBAL.sbm_financial_year = financial_year.ToString();

            //mode of payment
            sbmBAL.sbm_mode_of_payment = Convert.ToInt32(mopVal.ToString());

            sbmBAL.sbm_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            sbmBAL.sbm_logdt = System.DateTime.Now;

            sales_bill_masterDAL sbdDAL = new sales_bill_masterDAL();
            sbdDAL.update_sales_master(sbmBAL);

            //update sales bill details
            foreach (productEntry pdata1 in productData)
            {
                spb_bill_det_id = pdata1.spb_bill_det_id;

                if (spb_bill_det_id > 0)
                {

                    sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
                    sbdBAL.sbd_id = pdata1.spb_bill_det_id;
                    sbdBAL.sbd_product_id = pdata1.productVarId;


                    //product billing price 
                    sbdBAL.sbd_product_price = Convert.ToInt32(pdata1.pPrice);
                    //product actual price
                    sbdBAL.sbd_product_actual_price = Convert.ToInt32(pdata1.product_actual_price);

                    //product billing quentity
                    sbdBAL.sbd_quentity = Convert.ToInt32(pdata1.pQty);
                    //product actual quentity
                    sbdBAL.sbd_actual_quentity = Convert.ToInt32(pdata1.product_actual_quentity);

                    //product billing total
                    sbdBAL.sbd_total = Convert.ToInt32(pdata1.pTotal);
                    //product actual total
                    sbdBAL.sbd_actual_total = Convert.ToInt32(pdata1.product_actual_total_amount);

                    //product discount
                    sbdBAL.sbd_discount = float.Parse(pdata1.product_discount.ToString());
                    //product discount amount
                    sbdBAL.sbd_discount_amount = (Convert.ToInt32(pdata1.pTotal) * float.Parse((pdata1.product_discount).ToString())) / 100;

                    sbdBAL.sbd_cgst = pdata1.cgst;
                    sbdBAL.sbd_sgst = pdata1.sgst;
                    sbdBAL.sbd_igst = pdata1.igst;

                    sbdBAL.sbd_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                    sbdBAL.sbd_logdt = System.DateTime.Now;

                    //supplier_bill_masterDAL spbdDAL = new supplier_bill_masterDAL();
                    sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
                    sbmDAL.update_sales_details(sbdBAL);

                }

                //this is new code insert product
                else if (spb_bill_det_id == 0)
                {
                    sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
                    sbdBAL.sbd_bill_id = spb_mas_id;
                    sbdBAL.sbd_product_id = Convert.ToInt32(pdata1.productVarId);

                    //billing price
                    sbdBAL.sbd_product_price = Convert.ToInt32(pdata1.pPrice);
                    //product actual quentity
                    sbdBAL.sbd_product_actual_price = Convert.ToInt32(pdata1.product_actual_price);


                    //billing quentity
                    sbdBAL.sbd_quentity = Convert.ToInt32(pdata1.pQty);
                    //actual quentity
                    sbdBAL.sbd_actual_quentity = Convert.ToInt32(pdata1.product_actual_quentity);

                    //billing total
                    sbdBAL.sbd_total = Convert.ToInt32(pdata1.pTotal);
                    //actual total
                    sbdBAL.sbd_actual_total = Convert.ToInt32(pdata1.product_actual_total_amount);


                    //discount
                    sbdBAL.sbd_discount = float.Parse((pdata1.product_discount).ToString());
                    sbdBAL.sbd_discount_amount = (Convert.ToInt32(pdata1.pTotal) * float.Parse((pdata1.product_discount).ToString())) / 100;

                    //gst values
                    sbdBAL.sbd_cgst = float.Parse(pdata1.cgst.ToString());
                    sbdBAL.sbd_sgst = float.Parse(pdata1.sgst.ToString());
                    sbdBAL.sbd_igst = float.Parse(pdata1.igst.ToString());


                    sbdBAL.sbd_insrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                    sbdBAL.sbd_insdt = System.DateTime.Now;
                    sbdBAL.sbd_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
                    sbdBAL.sbd_logdt = System.DateTime.Now;

                    sales_bill_masterDAL sbmdDAL = new sales_bill_masterDAL();
                    sbmdDAL.insert_into_sales_bill_details(sbdBAL);
                }
            }

            //update sales payment bill 
            //sales_bill_paymentBAL sbpBAL = new sales_bill_paymentBAL();
            //sbpBAL.sbp_bill_id = Convert.ToInt32(spb_mas_id);
            //sbpBAL.sbp_mod_of_payment = mopVal;
            //sbpBAL.sbp_amount = mopAmo;
            //sbpBAL.sbp_logrid = Convert.ToInt32(HttpContext.Current.Session["login"].ToString());
            //sbpBAL.sbp_logdt = System.DateTime.Now;

            //sales_bill_masterDAL sbmpDAL = new sales_bill_masterDAL();
            ////sbmpDAL.update_sales_payment(sbpBAL);
            //sbmpDAL.insert_into_sales_bill_payment(sbpBAL);


        }

    }


    //for data edit page in supplier bill page
    [WebMethod]
    public static List<productEntry> get_supplier_data_in_edit(string spid)
    {
        supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
        spbdBAL.spbd_bill_id = Convert.ToInt32(spid);

        supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
        return sbmDAL.get_data_for_search_supplier_edit(spbdBAL);

    }


    //for data edit in customer bill page
    [WebMethod]
    public static List<productEntry> get_customer_data_in_edit(string spid)
    {
        sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
        //supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
        sbdBAL.sbd_bill_id = Convert.ToInt32(spid);

        sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
        //supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
        return sbmDAL.get_data_for_search_customer_edit(sbdBAL);
    }


    //delete data from database on remove button
    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public static void delete_product(int prd_bill_pay_id, int purchase_sales_billid)
    {

        if (purchase_sales_billid == 1)
        {
            supplier_purchase_bill_detailBAL spbdbal = new supplier_purchase_bill_detailBAL();
            spbdbal.spbd_id = prd_bill_pay_id;

            supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
            sbmDAL.delete_purchase_bill_details(spbdbal);
        }

        else if (purchase_sales_billid == 2)
        {
            sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
            sbdBAL.sbd_id = prd_bill_pay_id;

            sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
            sbmDAL.delete_customer_bill_details(sbdBAL);
        }

    }


    protected void buttonCreateTextbox_Click(object sender, EventArgs e)
    {
        // ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Button clicked.');", true);
    }

}