﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Low_Stock_Alert : System.Web.UI.Page
{
    void getlowStock()
    {
        low_stockDAL lsDAL = new low_stockDAL();
        DataSet ds = lsDAL.get_product_low_stock();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeaterLowStock.DataSource = ds;
            gridrepeaterLowStock.DataBind();
        }
        else
        {
            gridrepeaterLowStock.DataSource = ds;
            gridrepeaterLowStock.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if ((Session["login_admin"]) != null)
            {
                getlowStock();
            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }

    protected void gridrepeaterLowStock_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}