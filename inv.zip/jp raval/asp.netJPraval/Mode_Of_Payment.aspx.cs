﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Mode_Of_Payment : System.Web.UI.Page
{
    void loadgridview()
    {
        mode_of_paymentDAL mopDAL = new mode_of_paymentDAL();
        DataSet ds = mopDAL.get_mode_of_payment_list();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeaterpayment.DataSource = ds;
            gridrepeaterpayment.DataBind();
        }
        else
        {
            gridrepeaterpayment.DataSource = null;
            gridrepeaterpayment.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {
                loadgridview();
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }


    protected void btnsave_Click(object sender, EventArgs e)
    {
        mode_of_paymentBAL mopBAL = new mode_of_paymentBAL();
        if (hfmopid.Value.ToString() == "")
        {
            mopBAL.mop_id = 0;
        }
        else if (hfmopid.Value.ToString() != "")
        {
            mopBAL.mop_id = Convert.ToInt32(hfmopid.Value.ToString());
        }

        mopBAL.mop_name = txtpay.Text.Trim().Replace('-',' ').ToUpper();
        mopBAL.mop_insrid = Convert.ToInt32(Session["login"].ToString());
        mopBAL.mop_insdt = System.DateTime.Now;
        mopBAL.mop_logrid = Convert.ToInt32(Session["login"].ToString());
        mopBAL.mop_logdt = System.DateTime.Now;

        mode_of_paymentDAL mopDAL = new mode_of_paymentDAL();
        int val = mopDAL.insert_into_mode_of_payment(mopBAL);

        if (val == 1)
        {
            // show message for alredy exists
            Response.Write("<script>alert('Payemnt Method Alredy Exists Please Enter Another Mehotd.')</script>");

        }
        else if (val == 2)
        {
            // insert
            Response.Write("<script>alert('Succesfully Inserted Payment Method.')</script>");
        }
        else if (val == 3)
        {
            Response.Write("<script>alert('Succesfully Updated Payment Method.')</script>");
        }

        hfmopid.Value = "";
        txtpay.Text = "";
        loadgridview();
    }


    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

        if (e.CommandName.ToString() == "btnview")
        {
            mode_of_paymentBAL mopBAL = new mode_of_paymentBAL();
            mopBAL.mop_id = Convert.ToInt16(e.CommandArgument.ToString());

            mode_of_paymentDAL mopDAL = new mode_of_paymentDAL();
            DataSet ds = mopDAL.get_mode_of_payment_for_edit(mopBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfmopid.Value = ds.Tables[0].Rows[0]["mop_id"].ToString();
                txtpay.Text = ds.Tables[0].Rows[0]["mop_name"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Sorry data does not exists');</script>");
            }

        }
        else if (e.CommandName.ToString() == "btndelete")
        {
            string id = e.CommandArgument.ToString();
            mode_of_paymentBAL mopBAL = new mode_of_paymentBAL();
            mopBAL.mop_id = Convert.ToInt32(id);

            mode_of_paymentDAL mopDAL = new mode_of_paymentDAL();
            mopDAL.delete_mode_of_payment(mopBAL);
            loadgridview();
        }
    }
}