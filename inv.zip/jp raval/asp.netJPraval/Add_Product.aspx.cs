﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;


public partial class Add_Product : System.Web.UI.Page
{
    //dropdown current financial year
    //public void loadfinyear()
    //{
    //    financial_year_masterDAL fymDAL = new financial_year_masterDAL();
    //    DataSet ds = fymDAL.get_all_financial_year();

    //    if (ds.Tables[0].Rows.Count > 0)
    //    {
    //        drpfinyear.DataSource = ds;
    //        drpfinyear.DataTextField = "financial_year";
    //        drpfinyear.DataValueField = "financial_year_id";
    //        drpfinyear.DataBind();
    //        drpfinyear.Items.Insert(0, "--- Select Financial Year ---");
    //    }


    //}

    //select current financial year
    public void load_current_financial_year()
    {
        financial_year_masterDAL fmDAL = new financial_year_masterDAL();
        string value = fmDAL.get_current_financial_year();
        //drpfinyear.Items.FindByText(value).Selected = true; 
        drpfinyear.Text = value.ToString();
    }

    public void load_tax_drop()
    {
        product_masterDAL pmDAL = new product_masterDAL();
        DataSet ds = pmDAL.get_product_tax_code();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drptaxcode.DataSource = ds;
            drptaxcode.DataTextField = "txcd_name";
            drptaxcode.DataValueField = "txcd_id";
            drptaxcode.DataBind();
            drptaxcode.Items.Insert(0, "--- Select Tax Code ---");
        }
    }

    public void load_brand_drop()
    {
        brand_masterDAL brd_masDAL = new brand_masterDAL();
        DataSet ds = brd_masDAL.get_brand_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drbrand.DataSource = ds;
            drbrand.DataTextField = "bm_name";
            drbrand.DataValueField = "bm_rid";
            drbrand.DataBind();
            drbrand.Items.Insert(0, "--- Select Brand ---");
        }
    }

    public void load_category_drop()
    {
        category_masterDAL catDAL = new category_masterDAL();
        DataSet ds = catDAL.get_category_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            catdrop.DataSource = ds;
            catdrop.DataTextField = "cat_name";
            catdrop.DataValueField = "cat_id";
            catdrop.DataBind();
            catdrop.Items.Insert(0, "--- Select Category ---");
        }

    }

    public void Loadunit()
    {
        unit_masterDAL umDAL = new unit_masterDAL();
        DataSet ds = umDAL.get_unit_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drunit.DataSource = ds;
            drunit.DataTextField = "um_name";
            drunit.DataValueField = "um_id";

            drunit.DataBind();
            drunit.Items.Insert(0, "--- Select Unit ---");
        }
    }

    static DropDownList dl;
    DataTable dt;
    static int r_val;

    private void SetInitialRow()
    {

        DataTable dt = new DataTable();
        DataRow dr = null;

        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        //dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value   
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));//for TextBox value   
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));//for DropDownList selected item   
        // dt.Columns.Add(new DataColumn("Column3", typeof(string)));//for DropDownList selected item   

        dr = dt.NewRow();
        dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dt.Rows.Add(dr);

        //Store the DataTable in ViewState for future reference   
        ViewState["CurrentTable"] = dt;

        //Bind the Gridview   
        grdvwothcattable.DataSource = dt;
        grdvwothcattable.DataBind();

        //After binding the gridview, we can then extract and fill the DropDownList with Data   
        DropDownList ddl1 = (DropDownList)grdvwothcattable.Rows[0].Cells[3].FindControl("dr_oth_cat");
        // DropDownList ddl2 = (DropDownList)grdvwothcattable.Rows[0].Cells[4].FindControl("DropDownList2");
        // FillDropDownList(ddl1);
        //FillDropDownList(ddl2);
    }

    string dropCatText = "";
    private void AddNewRowToGrid()
    {

        if (ViewState["CurrentTable"] != null)
        {

            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;

            if (dtCurrentTable.Rows.Count > 0)
            {
                drCurrentRow = dtCurrentTable.NewRow();
                drCurrentRow["RowNumber"] = dtCurrentTable.Rows.Count + 1;

                //add new row to DataTable   
                dtCurrentTable.Rows.Add(drCurrentRow);
                //Store the current data to ViewState for future reference   

                ViewState["CurrentTable"] = dtCurrentTable;


                for (int i = 0; i < dtCurrentTable.Rows.Count - 1; i++)
                {

                    //extract the TextBox values   

                    TextBox box1 = (TextBox)grdvwothcattable.Rows[i].Cells[2].FindControl("txt_oth_cat_value");


                    //dtCurrentTable.Rows[i]["Column1"] = box1.Text;
                    dtCurrentTable.Rows[i]["Column2"] = box1.Text;

                    //extract the DropDownList Selected Items   

                    DropDownList ddl1 = (DropDownList)grdvwothcattable.Rows[i].Cells[1].FindControl("dr_oth_cat");
                    // DropDownList ddl2 = (DropDownList)grdvwothcattable.Rows[i].Cells[4].FindControl("DropDownList2");

                    // Update the DataRow with the DDL Selected Items 
                    dropCatText += "," + ddl1.SelectedItem.Value;

                    dtCurrentTable.Rows[i]["Column1"] = ddl1.SelectedItem.Text;
                    // dtCurrentTable.Rows[i]["Column3"] = ddl2.SelectedItem.Text;

                }
                dropCatText = dropCatText.Remove(0, 1);

                //Rebind the Grid with the current data to reflect changes   
                grdvwothcattable.DataSource = dtCurrentTable;
                grdvwothcattable.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");

        }
        //Set Previous Data on Postbacks   
        SetPreviousData();
    }

    private void SetPreviousData()
    {

        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    DropDownList ddl1 = (DropDownList)grdvwothcattable.Rows[rowIndex].Cells[1].FindControl("dr_oth_cat");
                    //DropDownList ddl2 = (DropDownList)grdvwothcattable.Rows[rowIndex].Cells[4].FindControl("DropDownList2");


                    // TextBox box1 = (TextBox)grdvwothcattable.Rows[i].Cells[1].FindControl("txt_oth_cat_value");
                    TextBox box1 = (TextBox)grdvwothcattable.Rows[i].Cells[2].FindControl("txt_oth_cat_value");


                    //Fill the DropDownList with Data   
                    //FillDropDownList(ddl1);
                    // FillDropDownList(ddl2);

                    if (i < dt.Rows.Count - 1)
                    {

                        //Set the Previous Selected Items on Each DropDownList  on Postbacks   
                        ddl1.ClearSelection();
                        ddl1.Items.FindByText(dt.Rows[i]["Column1"].ToString()).Selected = true;

                        //Assign the value from DataTable to the TextBox   
                        box1.Text = dt.Rows[i]["Column2"].ToString();


                        // ddl2.ClearSelection();
                        //ddl2.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;

                    }

                    rowIndex++;
                }
            }
        }
    }

    private void ResetRowID(DataTable dt)
    {
        int rowNumber = 1;
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow row in dt.Rows)
            {
                row[0] = rowNumber;
                rowNumber++;
            }
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {

            if (!Page.IsPostBack)
            {
                load_brand_drop();
                load_category_drop();
                Loadunit();
                load_tax_drop();
                SetInitialRow();
                //loadfinyear();
                load_current_financial_year();

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");

        }
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }


    protected void grdvwothcattable_DataBound(object sender, EventArgs e)
    {

        foreach (GridViewRow row in grdvwothcattable.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {

                DropDownList drdrop = row.FindControl("dr_oth_cat") as DropDownList;

                other_category_masterDAL oth_DAL = new other_category_masterDAL();
                DataSet ds = oth_DAL.get_other_category_list();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    drdrop.DataSource = ds;
                    drdrop.DataTextField = "oth_cat_name";
                    drdrop.DataValueField = "oth_cat_id";
                    drdrop.DataBind();
                    drdrop.Items.Insert(0, "--- Select Other Category ---");
                    drdrop.Items[0].Value = "0";
                }

            }
        }
        //   dropCatText = "";
    }

    protected void grdvwothcattable_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");

            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }

        }
        dropCatText = "";
    }


    protected void btnupdate_Click(object sender, EventArgs e)
    {

    }


    protected void Is_Unit_CheckEvent(object sender, EventArgs e)
    {
        if (drunit.Visible == false)
        {
            drunit.Visible = true;
            //   txtunitname.Visible = true;
            Loadunit();
        }
        else if (drunit.Visible == true)
        {
            drunit.Visible = false;
            //  txtunitname.Visible = false;
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        bool insert_prod_decision = false;

        foreach (GridViewRow rowsOfGrid in grdvwothcattable.Rows)
        {
            TextBox txt_oth_cat_value = (TextBox)rowsOfGrid.FindControl("txt_oth_cat_value");
            DropDownList dr_oth_cat = (DropDownList)rowsOfGrid.FindControl("dr_oth_cat");
            if (dr_oth_cat.SelectedItem.Value != "0" && txt_oth_cat_value.Text != "")
            {
                insert_prod_decision = true;
            }
        }
        if (insert_prod_decision == true)
        {

            //product master BAL for product master
            product_masterBAL prdBAL = new product_masterBAL();

            prdBAL.prdm_name = txtfprdname.Text.Trim().ToUpper().Replace('-', '~');

            prdBAL.prdm_cat_id = Convert.ToInt32(catdrop.SelectedValue);

            prdBAL.prdm_brand_id = Convert.ToInt32(drbrand.SelectedValue);

            prdBAL.prdm_unit_id = Convert.ToInt32(drunit.SelectedValue);



            if (fuimportfile.HasFile)
            {
                Guid a = Guid.NewGuid();
                hfextension.Value = Path.GetExtension(fuimportfile.FileName);
                hffilenewname.Value = a.ToString() + hfextension.Value;
                fuimportfile.SaveAs(Server.MapPath("~/product_photo/" + hffilenewname.Value));
                prdBAL.prdm_photo_link = "~/product_photo/" + hffilenewname.Value;

            }
            else
            {
                prdBAL.prdm_photo_link = "~/product_photo/noimage.png";
            }


            prdBAL.prdm_insrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.prdm_ldt = System.DateTime.Now;
            prdBAL.prdm_logrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.prdm_logdt = System.DateTime.Now;


            //product variation name master
            prdBAL.prvm_product_variation_name = txtvarname.Text.Trim().ToUpper().Replace('-', '~');
            prdBAL.prvm_tax_code_id = Convert.ToInt32(drptaxcode.SelectedItem.Value);
            //for  low stock
            prdBAL.prvm_low_stock = Convert.ToInt32(txtlowstock.Text);

            prdBAL.prvm_insrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.prvm_insdt = System.DateTime.Now;
            prdBAL.prvm_logrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.prvm_logdt = System.DateTime.Now;

            //idle selling price master
            prdBAL.idle_prod_var_name = txtvarname.Text.Trim().ToUpper().Replace('-', '~');
            prdBAL.idle_prod_selling_price = 0;
            prdBAL.idle_insrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.idle_insdt = System.DateTime.Now;
            prdBAL.idle_logrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.idle_logdt = System.DateTime.Now;


            //product startring stocke master
            prdBAL.pssm_starting_price = Convert.ToInt32(txtprice.Text);
            prdBAL.pssm_starting_qty = Convert.ToInt32(txtquentity.Text);

            prdBAL.pssm_financial_year = Convert.ToString(drpfinyear.Text);

            prdBAL.pssm_insrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.pssm_insdt = System.DateTime.Now;
            prdBAL.pssm_logrid = Convert.ToInt32(Session["login"].ToString());
            prdBAL.pssm_logdt = System.DateTime.Now;


            product_masterDAL prdDAL = new product_masterDAL();
            string val = prdDAL.insert_into_product(prdBAL);

            string[] id_val = new string[2];
            id_val = val.Split('|');

            int prd_spe_prdm_id = Convert.ToInt32(id_val[0]);
            int prd_spe_prvm_id = Convert.ToInt32(id_val[1]);


            product_specification_masterBAL prd_speBAL = new product_specification_masterBAL();

            //string txtBox2 = "", dropBox = "";
            string oth_cat_id_string = "";

            foreach (GridViewRow rowsOfGrid in grdvwothcattable.Rows)
            {
                //Finding Of Textbox and Drop Down
                TextBox txt_oth_cat_value = (TextBox)rowsOfGrid.FindControl("txt_oth_cat_value");
                DropDownList dr_oth_cat = (DropDownList)rowsOfGrid.FindControl("dr_oth_cat");
                prd_speBAL.prd_spe_prdm_id = prd_spe_prdm_id;
                prd_speBAL.prd_spe_pvnm_id = prd_spe_prvm_id;
                if (dr_oth_cat.SelectedItem.Value != "0" && txt_oth_cat_value.Text != "")
                {
                    string[] oth_cat_id_array = oth_cat_id_string.Split(',');
                    bool insert_decision = true;
                    for (int i = 0; i < oth_cat_id_array.Length; i++)
                    {
                        if (oth_cat_id_array[i].ToString() == dr_oth_cat.SelectedItem.Value)
                        {
                            insert_decision = false;
                        }
                    }
                    if (insert_decision == true)
                    {
                        oth_cat_id_string = oth_cat_id_string.ToString() + "," + dr_oth_cat.SelectedItem.Value;
                        oth_cat_id_string = oth_cat_id_string.Remove(0, 1);
                        prd_speBAL.prd_spe_oth_cat_id = Convert.ToInt32(dr_oth_cat.SelectedItem.Value);
                        prd_speBAL.prd_spe_oth_cat_val = txt_oth_cat_value.Text.Trim().ToUpper().Replace('-', '~');
                        prd_speBAL.prd_spe_insrid = Convert.ToInt32(Session["login"].ToString());
                        prd_speBAL.prd_spe_insdt = System.DateTime.Now;
                        prd_speBAL.prd_spe_logrid = Convert.ToInt32(Session["login"].ToString());
                        prd_speBAL.prd_spe_logdt = System.DateTime.Now;
                        product_specification_masterDAL prd_speDAL = new product_specification_masterDAL();
                        r_val = prd_speDAL.insert_into_product_specification_master(prd_speBAL);
                    }
                }



            }

            if (r_val == 2)
            {
                Response.Write("<script>alert('Product Inserted Successfully.');window.location.href='Add_Product.aspx';</script>");
            }
            else if (r_val == 3)
            {
                Response.Write("<script>alert('Product Variation Added Sucessfully')");
            }
        }
        else
        {
            Response.Write("<script>alert('Please choose specification for product');</script>");
        }

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex;
        if (ViewState["CurrentTable"] != null)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex < dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data and reset row number  
                    dt.Rows.Remove(dt.Rows[rowID]);
                    ResetRowID(dt);
                }
            }

            //Store the current data in ViewState for future reference  
            ViewState["CurrentTable"] = dt;

            //Re bind the GridView for the updated data  
            grdvwothcattable.DataSource = dt;
            grdvwothcattable.DataBind();
        }

        //Set Previous Data on Postbacks  
        SetPreviousData();
    }


    protected void ButtonAdd_Click1(object sender, EventArgs e)
    {

    }
}