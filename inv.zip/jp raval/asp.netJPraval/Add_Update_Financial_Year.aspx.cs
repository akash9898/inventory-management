﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Financial_Year : System.Web.UI.Page
{
    void loadacdmcyear()
    {
        DateTime NowTime = DateTime.Now;
        int year = NowTime.Year;
        for (int i = year - 1; i < year + 6; i++)
        {
            dracdmyr1.Items.Add(i.ToString());
            // dracdmyr2.Items.Add(i.ToString());

        }
    }
    void fillgrid()
    {
        financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
        DataSet ds = finclyrDAL.get_all_financial_year();
        gridrepeater.DataSource = ds;
        gridrepeater.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["login_admin"] != null)
        //{
        if (!IsPostBack)
        {
            loadacdmcyear();
            fillgrid();
        }
        //}
        //else
        //{
        //    Response.Redirect("searchstudent.aspx");
        //}
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        try
        {


            if (btnadd.Text == "Add")
            {
                financial_year_masterBAL finclyrBAL = new financial_year_masterBAL();
                finclyrBAL.financial_year = dracdmyr1.Text + " - " + lblfinancialyr2.Text;
                financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
                DataSet dsstcheck = finclyrDAL.dup_check_financial_year(finclyrBAL);
                if (dsstcheck.Tables[0].Rows.Count > 0)
                {
                    Response.Write("<script>alert('Same financial year already exist in database');</script>");

                }
                finclyrBAL.financial_year = dracdmyr1.Text + " - " + lblfinancialyr2.Text;
                finclyrBAL.financial_year_insdt = System.DateTime.Now;
                finclyrBAL.financial_year_rid = Convert.ToInt16(Session["login"]);
                finclyrBAL.financial_year_logdt = System.DateTime.Now;
                finclyrBAL.financial_year_logrid = Convert.ToInt16(Session["login"]);
                string val = finclyrDAL.insert_financial_year(finclyrBAL);
                Response.Write("<script>alert('financial year added successfully.');</script>");
                fillgrid();


            }

            if (btnadd.Text == "Save")
            {
                financial_year_masterBAL finclyrBAL = new financial_year_masterBAL();
                finclyrBAL.financial_year_id = Convert.ToInt32(hfyrid.Value);
                finclyrBAL.financial_year = dracdmyr1.Text + " - " + lblfinancialyr2.Text;
                finclyrBAL.financial_year_logdt = System.DateTime.Now;
                finclyrBAL.financial_year_logrid = Convert.ToInt16(Session["login"]);
                financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
                string val = finclyrDAL.update_financial_year(finclyrBAL);
                Response.Write("<script>alert('financial_year updated successfully.');</script>");
                btnadd.Text = "Add";
                fillgrid();
            }
        }

        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.ToString() + "');</script>");
        }

    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "btnrptredit")
            {
                btnadd.Text = "Save";
                hfyrid.Value = e.CommandArgument.ToString();
                financial_year_masterBAL finclyrBAL = new financial_year_masterBAL();
                finclyrBAL.financial_year_id = Convert.ToInt32(hfyrid.Value);
                financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
                DataSet ds = finclyrDAL.edit_fill_financial_year(finclyrBAL);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string[] year = ds.Tables[0].Rows[0]["financial_year"].ToString().Split('-');
                    dracdmyr1.Text = year[0].ToString().Trim();

                    lblfinancialyr2.Text = year[1].ToString().Trim();

                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.ToString() + "');</script>");
        }
    }

    protected void dracdmyr1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblfinancialyr2.Text = (Convert.ToInt16(dracdmyr1.SelectedItem.Value) + 1).ToString();
    }
}