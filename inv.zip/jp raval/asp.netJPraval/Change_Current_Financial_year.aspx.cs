﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Change_Current_Financial_year : System.Web.UI.Page
{
    void loadfinancialyear()
    {
        financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
        DataSet ds = finclyrDAL.get_all_financial_year();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drfinancial.DataSource = ds;
            drfinancial.DataTextField = "financial_year";
            drfinancial.DataValueField = "financial_year_id";
            drfinancial.DataBind();
            drfinancial.Items.Insert(0, "---Select financial Year---");

        }
        else
        {
            drfinancial.Items.Clear();

        }
    }

    void loadcurrentyear()
    {
        financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
        txtcurrentyear.Text = finclyrDAL.get_current_financial_year().ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["login_admin"] != null)
        //{
        if (!IsPostBack)
        {
            loadfinancialyear();
            loadcurrentyear();
        }
        //}
        //else
        //{
        //    Response.Redirect("searchstudent.aspx");
        //}

    }

    protected void btnchange_Click(object sender, EventArgs e)
    {

        string val_change = drfinancial.SelectedItem.ToString();
        string val_curr = Convert.ToString(txtcurrentyear.Text);

        int sum_values_changed_fin_year = Convert.ToInt32(val_change.Split('-')[0].ToString()) + Convert.ToInt32(val_change.Split('-')[1].ToString());
        int sum_values_current_fin_year = Convert.ToInt32(val_curr.Split('-')[0].ToString()) + Convert.ToInt32(val_curr.Split('-')[1].ToString());
        
        //chaning to the new financial year
        if (sum_values_changed_fin_year > sum_values_current_fin_year)
        {

            //check if the the financial year we want to change is already exists in product starting stock master 
            //if yes that means you one change financial year then
            /*
             get logdt from current financial year and compare that date with product starting stock master which has old financial year,
             sales bill and purchase bill
             if their logdt > current finacial year logdt
             then only update that product
            */

            //if no
            /*
             that means you never changed financial year that means
             get all old product and inset into product starting stock master
             with current stock,avg price and insert with current date
             */


            //update current financial year in changed last inseted all products
            //product_starting_stock_masterBAL pssmBAL = new product_starting_stock_masterBAL();
            //pssmBAL.pssm_financial_year = Convert.ToString(drfinancial.SelectedItem.Text.ToString());

            //ccdDAL.update_fin_year_product_starting_stock_master(pssmBAL);

            //check if the financial year exists in product starting stock master
            product_starting_stock_masterBAL pssmBAL = new product_starting_stock_masterBAL();
            pssmBAL.pssm_financial_year = Convert.ToString(drfinancial.SelectedItem.Text.ToString());

            change_current_financialyearDAL ccFDAL = new change_current_financialyearDAL();
            DataSet ds = ccFDAL.get_exists_date_starting_stock_master(pssmBAL);


            //if there are values in ds
            //alreay changed once
            if (ds.Tables[0].Rows.Count > 0)
            {
                //get all the product which does not has current financial year but 
                //has logdt > current_financial_year_logdt
                //only those product get insert here

                change_current_financialyearDAL ccdDAL = new change_current_financialyearDAL();

                DataSet new_added_prd = ccdDAL.get_new_added_product_after_changing_financial_year();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    //inster product which is insterd after changing financial year new to old
                    ccdDAL.insert_product_starting_stock_master(2);

                    //update financial year
                    product_starting_stock_masterBAL pssmBAL1 = new product_starting_stock_masterBAL();
                    pssmBAL1.pssm_financial_year = Convert.ToString(drfinancial.SelectedItem.Text.ToString());
                    ccdDAL.update_fin_year_product_starting_stock_master(pssmBAL1);

                    //update insdt and logdt
                    product_starting_stock_masterBAL pssmBAL2 = new product_starting_stock_masterBAL();
                    pssmBAL2.pssm_financial_year = Convert.ToString(drfinancial.SelectedItem.Text.ToString());
                    ccdDAL.update_insdt_logdt(pssmBAL2);

                    ccdDAL.update_avegrage_price(pssmBAL2);

                }


            }

            //if no values in ds
            //first time insert 
            else
            {
                //get all the exists data and insert them again with changed financial year 
                //and current logdt and insdt

                //insert into product starting stock master

                //insert into product starting stock master
                change_current_financialyearDAL ccdDAL = new change_current_financialyearDAL();
                ccdDAL.insert_product_starting_stock_master(1);

                //update current financial year in changed last inseted all products
                product_starting_stock_masterBAL pssmBAL1 = new product_starting_stock_masterBAL();

                //update financial year
                pssmBAL1.pssm_financial_year = Convert.ToString(drfinancial.SelectedItem.Text.ToString());
                ccdDAL.update_fin_year_product_starting_stock_master(pssmBAL1);

                //update insdt and logdt
                product_starting_stock_masterBAL pssmBAL2 = new product_starting_stock_masterBAL();
                pssmBAL2.pssm_financial_year = Convert.ToString(drfinancial.SelectedItem.Text.ToString());
                ccdDAL.update_insdt_logdt(pssmBAL2);

                //upadte average price in product

                ccdDAL.update_avegrage_price(pssmBAL2);
            }

            //changing in current financial year
            financial_year_masterBAL finclBAL = new financial_year_masterBAL();
            finclBAL.financial_year = drfinancial.SelectedItem.Text.ToString();
            finclBAL.financial_year_logdt = System.DateTime.Now;
            finclBAL.financial_year_logrid = Convert.ToInt16(Session["login"].ToString());
            financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
            string val = finclyrDAL.update_current_financial_year(finclBAL);
            if (val == "Updated")
            {
                Response.Write("<script>alert('Current year changed successfully');</script>");
            }
            loadcurrentyear();
            drfinancial.Text = null;

        }

        //changing to the old financial year
        else
        {

            //chaning in current financial year
            financial_year_masterBAL finclBAL = new financial_year_masterBAL();
            finclBAL.financial_year = drfinancial.SelectedItem.Text.ToString();
            finclBAL.financial_year_logdt = System.DateTime.Now;
            finclBAL.financial_year_logrid = Convert.ToInt16(Session["login"].ToString());
            financial_year_masterDAL finclyrDAL = new financial_year_masterDAL();
            string val = finclyrDAL.update_current_financial_year(finclBAL);
            if (val == "Updated")
            {
                Response.Write("<script>alert('Current year changed successfully');</script>");
            }
            loadcurrentyear();
            drfinancial.Text = null;

        }

    }


}