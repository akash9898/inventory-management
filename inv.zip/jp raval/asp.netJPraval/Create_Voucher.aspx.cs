﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class Create_Voucher : System.Web.UI.Page
{
    //drop voucher name
    public void loaddrpvnm()
    {
        voucher_masterDAL vmDAL = new voucher_masterDAL();
        DataSet ds = vmDAL.get_voucher_name_master_list();
        if (ds.Tables[0].Rows.Count > 0)
        {
            dropvnm.DataSource = ds;
            dropvnm.DataTextField = "vm_name";
            dropvnm.DataValueField = "vm_id";

            dropvnm.DataBind();
            dropvnm.Items.Insert(0, "--- Select Vocuher ---");
            dropvnm.Items[0].Value = "0";
        }
    }


    //dropdown current financial year
    public void loadfinyear()
    {
        financial_year_masterDAL fymDAL = new financial_year_masterDAL();
        DataSet ds = fymDAL.get_all_financial_year();

        if (ds.Tables[0].Rows.Count > 0)
        {
            drpfinyear.DataSource = ds;
            drpfinyear.DataTextField = "financial_year";
            drpfinyear.DataValueField = "financial_year_id";
            drpfinyear.DataBind();
            drpfinyear.Items.Insert(0, "--- Select Financial Year ---");
        }

    }

    //select current financial year
    public void load_current_financial_year()
    {
        financial_year_masterDAL fmDAL = new financial_year_masterDAL();
        string value = fmDAL.get_current_financial_year();
        drpfinyear.Items.FindByText(value).Selected = true;


    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Session["login"] != null)
            {
                loaddrpvnm();
                loadfinyear();
                load_current_financial_year();

                if (Request.QueryString["vm_id"] != null && Request.QueryString["vm_id"].ToString() != "")
                {

                    voucher_masterBAL vmBAL = new voucher_masterBAL();
                    vmBAL.vm_id = Convert.ToInt32(Request.QueryString["vm_id"].ToString());

                    voucher_masterDAL vmDAL = new voucher_masterDAL();
                    DataSet ds = vmDAL.get_voucher_list_for_edit(vmBAL);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtvouchername.Enabled = false;
                        dropvnm.Enabled = false;

                        txtpersonname.Enabled = false;
                        txtphonenum.Enabled = false;
                        txtamount.Enabled = false;
                        btnenabledit.Visible = true;

                        drpfinyear.Enabled = false;

                        //date 
                        txtdob.Enabled = false;

                        btnvoucherpay.Visible = false;

                        txtvouchername.Text = ds.Tables[0].Rows[0]["vm_name"].ToString();
                        dropvnm.Text = ds.Tables[0].Rows[0]["vm_vnm_id"].ToString();

                        txtpersonname.Text = ds.Tables[0].Rows[0]["vm_person_name"].ToString();
                        txtphonenum.Text = ds.Tables[0].Rows[0]["vm_phone_num"].ToString();
                        txtamount.Text = ds.Tables[0].Rows[0]["vm_amount"].ToString();

                        //date
                        txtdob.Text = ds.Tables[0].Rows[0]["vm_date"].ToString();
                    }
                }
            }
            else
            {
                Response.Redirect("User_Login.aspx");
            }
        }
    }

    protected void gridrepeatervoucherlist_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void btnvoucherpay_Click(object sender, EventArgs e)
    {
        voucher_masterBAL vmBAL = new voucher_masterBAL();
        vmBAL.vm_vnm_id = Convert.ToInt32(dropvnm.SelectedItem.Value);

        vmBAL.vm_name = txtvouchername.Text;
        vmBAL.vm_person_name = txtpersonname.Text;

        if (txtphonenum.Text == "")
        {
            vmBAL.vm_phone_num = "0";
        }
        vmBAL.vm_phone_num = txtphonenum.Text;

        vmBAL.vm_amount = Convert.ToInt32(txtamount.Text);

        if (txtdob.Text.ToString() != "")
        {
            vmBAL.vm_date = Convert.ToDateTime(txtdob.Text);
        }

        vmBAL.vm_financial_year = drpfinyear.SelectedItem.Text;

        vmBAL.vm_insrid = Convert.ToInt32(Session["login"].ToString());
        vmBAL.vm_insdt = System.DateTime.Now;
        vmBAL.vm_logrid = Convert.ToInt32(Session["login"].ToString());
        vmBAL.vm_logdt = System.DateTime.Now;

        voucher_masterDAL vmDAL = new voucher_masterDAL();
        vmDAL.insert_into_voucher_master(vmBAL);

        Response.Write("<script>alert('Succesfully Created Voucher!');window.location.href='Create_Voucher.aspx';</script>");

    }

    protected void btnuodatevoucher_Click(object sender, EventArgs e)
    {
        voucher_masterBAL vmBAL = new voucher_masterBAL();
        vmBAL.vm_id = Convert.ToInt32(Request.QueryString["vm_id"].ToString());
        vmBAL.vm_vnm_id = Convert.ToInt32(dropvnm.SelectedItem.Value);
        vmBAL.vm_name = txtvouchername.Text;
        vmBAL.vm_person_name = txtpersonname.Text;
        vmBAL.vm_phone_num = txtphonenum.Text;

        if (txtdob.Text.ToString() != "")
        {
            vmBAL.vm_date = Convert.ToDateTime(txtdob.Text);
        }

        vmBAL.vm_amount = Convert.ToInt32(txtamount.Text);

        vmBAL.vm_financial_year = drpfinyear.SelectedItem.Text;

        vmBAL.vm_logrid = Convert.ToInt32(Session["login"].ToString());
        vmBAL.vm_logdt = System.DateTime.Now;

        voucher_masterDAL vmDAL = new voucher_masterDAL();
        vmDAL.insert_into_voucher_master(vmBAL);

        Response.Write("<script>alert('Succesfully Updated Voucher!');window.location.href='Voucher_List.aspx';</script>");

    }

    protected void btnenabledit_Click(object sender, EventArgs e)
    {

        txtvouchername.Enabled = true;
        dropvnm.Enabled = true;
        txtpersonname.Enabled = true;
        txtphonenum.Enabled = true;
        txtamount.Enabled = true;
        btnenabledit.Visible = false;
        btnuodatevoucher.Visible = true;
        txtdob.Enabled = true;
        drpfinyear.Enabled = true;
    }
}