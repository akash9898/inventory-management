﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Inventory_Report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }

    }

    protected void rptbtnprdvar_Click(object sender, EventArgs e)
    {
        //show product variation name div
        rptprdvarname.Visible = true;

        //hide product name div
        rptprdname.Visible = false;


        inventiry_reportDAL irDAL = new inventiry_reportDAL();
        DataSet ds = irDAL.get_product_current_quentity();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridprdvarnamereport.DataSource = ds;
            gridprdvarnamereport.DataBind();
        }
        else
        {
            gridprdvarnamereport.DataSource = null;
            gridprdvarnamereport.DataBind();
        }
    }

    protected void rptbtnprdname_Click(object sender, EventArgs e)
    {
        //hide product variatio name div 
        rptprdvarname.Visible = false;

        //show product name div
        rptprdname.Visible = true;

        inventiry_reportDAL irDAL = new inventiry_reportDAL();
        DataSet ds = irDAL.get_product_current_quentity_product_name();


        if (ds.Tables[0].Rows.Count > 0)
        {
            gridprdnamereport.DataSource = ds;
            gridprdnamereport.DataBind();
        }
        else
        {
            gridprdnamereport.DataSource = null;
            gridprdnamereport.DataBind();
        }


    }


}