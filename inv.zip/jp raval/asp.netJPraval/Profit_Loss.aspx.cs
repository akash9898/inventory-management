﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Profit_Loss : System.Web.UI.Page
{
    //get total profit loss all time
    public void get_profit_loss_all_time()
    {
        profit_lossDAL plDAL = new profit_lossDAL();

        int total_starting_stock = plDAL.get_total_starting_stock();
        int total_investment = plDAL.get_total_investment();
        int total_return = plDAL.get_total_return();
        int total_voucher = plDAL.get_total_voucher();

        //gross_prodit
        int gross_profit = total_return - total_investment - total_starting_stock;
        //net profit
        int net_profit = total_return - total_investment - total_voucher - total_starting_stock;

        //label total starting stock
        lbltotsts.Text = "₹ " + total_starting_stock.ToString();

        //label total investment
        lbltotinv.Text ="₹ "+ total_investment.ToString();

        //label total return
        lbltotret.Text = "₹ " + total_return.ToString();

        //label total voucher
        lbltotvou.Text = "₹ " + total_voucher.ToString();

        //label gross profit
        lblgrossprofit.Text = "₹ " + gross_profit.ToString();

        //label net profit
        lblnetprofit.Text = "₹ " + net_profit.ToString();

    }

    //get total profit loss search date
    public void get_profit_loss_search_time()
    {

        //getz total supplier purchase total
        supplier_purchse_bill_masterBAL spbmBAL = new supplier_purchse_bill_masterBAL();
        if (startdate.Text != "")
        {
            spbmBAL.startdate = "'" + Convert.ToDateTime(startdate.Text + " " + "00:00:00").ToString("yyyy/MM/dd") + "'";
        }
        if (enddate.Text.ToString() != "")
        {
            spbmBAL.enddate = "'" + Convert.ToDateTime(enddate.Text + " " + "00:00:00").ToString("yyyy/MM/dd") + "'";
        }

        profit_lossDAL plDAL = new profit_lossDAL();

        //get investment search 
        Int64 total_investment_search = plDAL.get_investment_search_date(spbmBAL);

        //get return seach
        Int64 total_return_search = plDAL.get_return_search_date(spbmBAL);

        //get voucher seach
        Int64 total_voucher_search = plDAL.get_return_voucher_date(spbmBAL);

        //investment label
        lblseinvesment.Text = "₹ " + total_investment_search.ToString();

        //return label
        lblsereturn.Text = "₹ " + total_return_search.ToString();

        //voucher label
        lblsevoucher.Text = "₹ " + total_voucher_search.ToString();

        //lbl seach gross profit
        lblsegrossprofit.Text = "₹ " + (Convert.ToInt32(total_return_search.ToString()) - Convert.ToInt32(total_investment_search.ToString())).ToString();

        //lbl search net profit
        lblsenetprofit.Text = "₹ " + (Convert.ToInt32(total_return_search.ToString()) - Convert.ToInt32(total_investment_search.ToString()) - (Convert.ToInt32(total_voucher_search.ToString()))).ToString();
    }


    //get total amount to be paid for supplier purchase 
    public void get_total_amount_to_be_paid()
    {
        profit_lossDAL plDAL = new profit_lossDAL();
        Int64 get_total_purchase_amount = plDAL.get_total_purchase_amount();
        Int64 get_total_purchase_bill_amount = plDAL.get_total_purchase_bill_amount();

        lbltotalamounttobepaid.Text = "₹ " + (get_total_purchase_amount - get_total_purchase_bill_amount).ToString();


    }

    //get total amount to be collect from sales
    //which is just substraction for totla sales bill and total paid bill
    public void get_total_amout_to_be_collect()
    {
        profit_lossDAL plDAL = new profit_lossDAL();
        Int64 get_total_sales_amount = plDAL.get_total_sales_amount();
        Int64 get_total_sales_bill_amount = plDAL.get_total_sales_bill_amount();

        lbltotalamounttobecollect.Text = "₹ " + (get_total_sales_amount - get_total_sales_bill_amount).ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //get total profit loss all time which gets total investment,total sales,total voucher,total gross/loss and tot net profit/loss
        get_profit_loss_all_time();

        //get total amount to be paid 
        get_total_amount_to_be_paid();

        //get total amount to be collect from sales
        get_total_amout_to_be_collect();

    }


    protected void btnprofitloss_Click(object sender, EventArgs e)
    {

        get_profit_loss_search_time();

    }
}