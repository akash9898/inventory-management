﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class Bill_Payment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["login"] != null)
        {
            if (!IsPostBack)
            {

                if (Request.QueryString["purchase_sales_billid"].ToString() == "1")
                {
                        
                    prdsalesbill.Visible = false;

                    supplier_purchse_bill_masterBAL spbmBAL = new supplier_purchse_bill_masterBAL();
                    spbmBAL.spb_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                    DataSet ds = sbmDAL.get_supplier_product_list(spbmBAL);


                    lblname.Text = ds.Tables[0].Rows[0]["sup_business_name"].ToString();
                    lblmobileno.Text = ds.Tables[0].Rows[0]["sup_primary_ctn"].ToString();

                    //amount paid,all and unpaid
                    totalbill.Text = ds.Tables[0].Rows[0]["spb_total_amount"].ToString();
                    paidamolbl.Text = ds.Tables[0].Rows[0]["paidamount"].ToString();
                    unpaidamolbl.Text = ds.Tables[0].Rows[0]["unpaidamount"].ToString();




                    supplier_purchase_bill_detailBAL spbdBAL = new supplier_purchase_bill_detailBAL();
                    spbdBAL.spbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    bill_paymentDAL bpDAL = new bill_paymentDAL();
                    DataSet ds1 = bpDAL.get_product_list_bill_payment(spbdBAL);

                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        rptprdpurchasebill.DataSource = ds1;
                        rptprdpurchasebill.DataBind();
                    }
                    else
                    {
                        rptprdpurchasebill.DataSource = null;
                        rptprdpurchasebill.DataBind();
                    }

                    //for hide payment button and show list button
                    int total_amount = Convert.ToInt32(ds.Tables[0].Rows[0]["spb_total_amount"].ToString());
                    int paid_amount = Convert.ToInt32(ds.Tables[0].Rows[0]["paidamount"].ToString());

                    if (total_amount == paid_amount)
                    {
                        //hide payment  date and label
                        paymentlbl.Visible = false;

                        //hide enter amount label and text
                        lblpayamo.Visible = false;

                        //payment button hide
                        btnpay.Visible = false;
                    }
                    else
                    {
                        //hide button list
                        btnlist.Visible = false;
                    }


                }

                else if (Request.QueryString["purchase_sales_billid"].ToString() == "2")
                {

                    prdpurchasebill.Visible = false;

                    sales_bill_masterBAL sbmBAL = new sales_bill_masterBAL();
                    sbmBAL.sbm_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
                    DataSet ds = sbmDAL.get_customer_product_list(sbmBAL);


                    lblname.Text = ds.Tables[0].Rows[0]["cust_first_name"].ToString() + ' ' + ds.Tables[0].Rows[0]["cust_middle_name"].ToString() + ' ' + ds.Tables[0].Rows[0]["cust_last_name"].ToString();
                    lblmobileno.Text = ds.Tables[0].Rows[0]["cust_primary_ctn"].ToString();


                    //amount paid,all and unpaid
                    totalbill.Text = ds.Tables[0].Rows[0]["sbm_total_amount"].ToString();
                    paidamolbl.Text = ds.Tables[0].Rows[0]["paidamount"].ToString();
                    unpaidamolbl.Text = ds.Tables[0].Rows[0]["unpaidamount"].ToString();


                    //sales bill dedtails for bill id
                    sales_bill_detailBAL sbdBAL = new sales_bill_detailBAL();
                    sbdBAL.sbd_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());

                    //sales bill payment product list
                    DataSet dsprd = sbmDAL.get_product_list_bill_payment(sbdBAL);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        rptprdsalesbill.DataSource = dsprd;
                        rptprdsalesbill.DataBind();
                    }
                    else
                    {
                        rptprdsalesbill.DataSource = null;
                        rptprdsalesbill.DataBind();
                    }


                    //for hide payment button and show list button
                    int total_amount = Convert.ToInt32(ds.Tables[0].Rows[0]["sbm_total_amount"].ToString());
                    int paid_amount = Convert.ToInt32(ds.Tables[0].Rows[0]["paidamount"].ToString());

                    if (total_amount == paid_amount)
                    {
                        //hide payment  date and label
                        paymentlbl.Visible = false;

                        //hide enter amount label and text
                        lblpayamo.Visible = false;

                        //payment button hide
                        btnpay.Visible = false;
                    }
                    else
                    {
                        //hide button list
                        btnlist.Visible = false;
                    }

                }
            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }

    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void btnpay_Click(object sender, EventArgs e)
    {

        if (Convert.ToInt32(unpaidamolbl.Text) < Convert.ToInt32(payamo.Text))
        {
            Response.Write("<script>alert('You pay amount is more then unpaid amount!')</script>");
        }

        else
        {

            if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 1)
            {

                supplier_purchse_bill_paymentBAL spbpBAL = new supplier_purchse_bill_paymentBAL();
                spbpBAL.spbp_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());
                spbpBAL.spbp_mod_of_payment = 2;
                if (txtdob.Text.ToString() != "")
                {
                    spbpBAL.spbp_date_of_payment = Convert.ToDateTime(txtdob.Text);

                }
                spbpBAL.spbp_amount = Convert.ToInt32(payamo.Text);
                spbpBAL.spbp_insrid = Convert.ToInt32(Session["login"].ToString());
                spbpBAL.spbp_insdt = System.DateTime.Now;
                spbpBAL.spbp_logrid = Convert.ToInt32(Session["login"].ToString());
                spbpBAL.spbp_logdt = System.DateTime.Now;


                supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                sbmDAL.insert_into_bill_payment(spbpBAL);

                Response.Write("<script>alert('Bill Payment Succesfully!');window.location.href='Search_Bill.aspx?purchase_sales_billid=1'</script>");

            }

            else if (Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString()) == 2)
            {

                sales_bill_paymentBAL sbpBAL = new sales_bill_paymentBAL();
                //supplier_purchse_bill_paymentBAL spbpBAL = new supplier_purchse_bill_paymentBAL();
                sbpBAL.sbp_bill_id = Convert.ToInt32(Request.QueryString["spid"].ToString());
                sbpBAL.sbp_mod_of_payment = 2;
                if (txtdob.Text.ToString() != "")
                {
                    sbpBAL.sbp_date_of_payment = Convert.ToDateTime(txtdob.Text);

                }
                sbpBAL.sbp_amount = Convert.ToInt32(payamo.Text);
                sbpBAL.sbp_insrid = Convert.ToInt32(Session["login"].ToString());
                sbpBAL.sbp_insdt = System.DateTime.Now;
                sbpBAL.sbp_logrid = Convert.ToInt32(Session["login"].ToString());
                sbpBAL.sbp_logdt = System.DateTime.Now;

                sales_bill_masterDAL sbmDAL = new sales_bill_masterDAL();
                //supplier_bill_masterDAL sbmDAL = new supplier_bill_masterDAL();
                sbmDAL.insert_into_sales_bill_payment_pay(sbpBAL);

                Response.Write("<script>alert('Bill Payment Succesfully!');window.location.href='Search_Bill.aspx?purchase_sales_billid=2'</script>");

            }

        }
    }



    protected void btnlist_Click(object sender, EventArgs e)
    {
        int prch_sales_id = Convert.ToInt32(Request.QueryString["purchase_sales_billid"].ToString());

        Response.Redirect("Search_Bill.aspx?purchase_sales_billid=" + prch_sales_id);

    }
}