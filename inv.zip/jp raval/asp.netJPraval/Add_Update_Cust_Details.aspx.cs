﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Add_Update_Cust_Details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["login_admin"] != null)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["cuid"] != null && Request.QueryString["cuid"].ToString() != "")
                {
                    customer_masterBAL cuBAL = new customer_masterBAL();
                    cuBAL.cust_id = Convert.ToInt16(Request.QueryString["cuid"].ToString());
                    customer_masterDAL cuDAL = new customer_masterDAL();
                    DataSet ds = cuDAL.get_customer_list_for_edit(cuBAL);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        btnregister.Visible = false;
                        btnaddservice.Visible = false;
                        btnregister.Text = "Update";
                        btnupdate.Visible = true;
                        txtfirstname.Text = ds.Tables[0].Rows[0]["cust_first_name"].ToString();
                        txtmiddlename.Text = ds.Tables[0].Rows[0]["cust_middle_name"].ToString();
                        txtsurname.Text = ds.Tables[0].Rows[0]["cust_last_name"].ToString();
                        txtbusinessame.Text = ds.Tables[0].Rows[0]["cust_busines_name"].ToString();
                        txtctn.Text = ds.Tables[0].Rows[0]["cust_primary_ctn"].ToString();
                        txtwactn.Text = ds.Tables[0].Rows[0]["cust_whats_app_ctn"].ToString();
                        txtsectn.Text = ds.Tables[0].Rows[0]["cust_second_ctn"].ToString();
                        txtthctn.Text = ds.Tables[0].Rows[0]["cust_third_ctn"].ToString();
                        txtemail.Text = ds.Tables[0].Rows[0]["cust_email"].ToString();

                        txtaddress.Text = ds.Tables[0].Rows[0]["cust_address"].ToString();
                        txtctvlg.Text = ds.Tables[0].Rows[0]["cust_city_village"].ToString();

                        txtpincode.Text = ds.Tables[0].Rows[0]["cust_pincode"].ToString();

                        if (ds.Tables[0].Rows[0]["cust_gender"].ToString() == "Male")
                        {
                            rdomale.Checked = true;
                        }
                        else if (ds.Tables[0].Rows[0]["cust_gender"].ToString() == "Female")
                        {
                            rdofemale.Checked = true;
                        }

                        txtfirstname.Enabled = false;
                        txtmiddlename.Enabled = false;
                        txtsurname.Enabled = false;
                        txtctn.Enabled = false;
                        txtemail.Enabled = false;
                        txtwactn.Enabled = false;
                        txtsectn.Enabled = false;
                        txtthctn.Enabled = false;
                        txtaddress.Enabled = false;
                        txtctvlg.Enabled = false;
                        txtpincode.Enabled = false;


                    }
                }

            }
        }
        else
        {
            Response.Redirect("User_Login.aspx");
        }
    }


    protected void btnregister_Click(object sender, EventArgs e)
    {

        if (rdomale.Checked == false && rdofemale.Checked == false)
        {
            Response.Write("<script>alert('Select Gender');</script>");
        }
        else
        {

            customer_masterBAL cmBAL = new customer_masterBAL();
            if (Request.QueryString["cuid"] != null && Request.QueryString["cuid"].ToString() != "")
            {
                cmBAL.cust_id = Convert.ToInt16(Request.QueryString["cuid"].ToString());
            }
            else
            {
                cmBAL.cust_id = 0;
            }


         
            cmBAL.cust_first_name = txtfirstname.Text.Trim().Replace('-',' ');
            cmBAL.cust_middle_name = txtmiddlename.Text.Trim().Replace('-',' ');
            cmBAL.cust_last_name = txtsurname.Text.Trim().Replace('-',' ');
            cmBAL.cust_busines_name = txtbusinessame.Text.Trim().Replace('-',' ');
            if (rdomale.Checked == true)
            {
                cmBAL.cust_gender = "Male";
            }
            else if (rdofemale.Checked == true)
            {

                cmBAL.cust_gender = "Female";
            }
            cmBAL.cust_email = txtemail.Text.Trim().Replace('-',' ');
            cmBAL.cust_address = txtaddress.Text.Trim().Replace('-',' ');
            cmBAL.cust_city_village = txtctvlg.Text.Trim().Replace('-',' ');
            if (txtpincode.Text != "")
            {


                cmBAL.cust_pincode = Convert.ToInt32(txtpincode.Text.Trim().Replace('-',' '));
            }
            cmBAL.cust_primary_ctn = txtctn.Text.Trim().Replace('-',' ');
            cmBAL.cust_whatsapp_ctn = txtwactn.Text.Trim().Replace('-',' ');
            cmBAL.cust_second_ctn = txtsectn.Text.Trim().Replace('-',' ');
            cmBAL.cust_third_ctn = txtthctn.Text.Trim().Replace('-',' ');

            cmBAL.cust_logdt = System.DateTime.Now;
            cmBAL.cust_insrid = Convert.ToInt32(Session["login"].ToString());
            cmBAL.cust_insdt = System.DateTime.Now;

            cmBAL.cust_logrid = Convert.ToInt32(Session["login"].ToString());

            customer_masterDAL cmDAL = new customer_masterDAL();
            int ret_val = cmDAL.insert_customer(cmBAL);

            if (ret_val == 0)
            {
                Response.Write("<script>alert('Please wait server is busy right now.');</script>");
            }
            else if (ret_val == -1 || ret_val == -2 || ret_val == -3)
            {
                Response.Write("<script>alert('This customer already exists in database try to change moblie number');</script>");
            }

            else if (ret_val != 0 || ret_val != -1 || ret_val != -3 || ret_val != -5)
            {
                Response.Write("<script>alert('Customer Added successfully');</script>");

                txtfirstname.Text = "";
                txtmiddlename.Text = "";
                txtsurname.Text = "";
                txtctn.Text = "";
                txtemail.Text = "";
                txtwactn.Text = "";
                txtsectn.Text = "";
                txtthctn.Text = "";
                rdomale.Checked = false;
                rdofemale.Checked = false;
                txtaddress.Text = "";
                txtctvlg.Text = "";
                txtpincode.Text = "";

            }
            else if (ret_val == -5)
            {
                Response.Write("<script>alert('Customer Data updated successfully');</script>");
                Response.Redirect("Filter_Customer.aspx");
                txtfirstname.Text = "";
                txtmiddlename.Text = "";
                txtsurname.Text = "";
                txtctn.Text = "";
                txtemail.Text = "";
                txtwactn.Text = "";
                txtsectn.Text = "";
                txtthctn.Text = "";
                rdomale.Checked = false;
                rdofemale.Checked = false;
                txtaddress.Text = "";
                txtctvlg.Text = "";
                txtpincode.Text = "";
            }
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        btnregister.Visible = true;
        btnupdate.Visible = false;
        txtfirstname.Enabled = true;
        txtmiddlename.Enabled = true;
        txtsurname.Enabled = true;
        txtctn.Enabled = true;
        txtemail.Enabled = true;
        txtwactn.Enabled = true;
        txtsectn.Enabled = true;
        txtthctn.Enabled = true;
        txtaddress.Enabled = true;
        txtctvlg.Enabled = true;
        txtpincode.Enabled = true;
    }

    protected void btnaddservice_Click(object sender, EventArgs e)
    {
        if (rdomale.Checked == false && rdofemale.Checked == false)
        {
            Response.Write("<script>alert('Select Gender');</script>");
        }
        else
        {

            customer_masterBAL cmBAL = new customer_masterBAL();
            if (Request.QueryString["cuid"] != null && Request.QueryString["cuid"].ToString() != "")
            {
                cmBAL.cust_id = Convert.ToInt16(Request.QueryString["cuid"].ToString());
            }
            else
            {
                cmBAL.cust_id = 0;
            }


            cmBAL.cust_insrid = Convert.ToInt32(Session["login"].ToString());
            cmBAL.cust_first_name = txtfirstname.Text.Trim().Replace('-',' ');
            cmBAL.cust_middle_name = txtmiddlename.Text.Trim().Replace('-',' ');
            cmBAL.cust_last_name = txtsurname.Text.Trim().Replace('-',' ');
            cmBAL.cust_busines_name = txtbusinessame.Text.Trim().Replace('-',' ');
            if (rdomale.Checked == true)
            {
                cmBAL.cust_gender = "Male";
            }
            else if (rdofemale.Checked == true)
            {

                cmBAL.cust_gender = "Female";
            }
            cmBAL.cust_email = txtemail.Text.Trim().Replace('-',' ');
            cmBAL.cust_address = txtaddress.Text.Trim().Replace('-',' ');
            cmBAL.cust_city_village = txtctvlg.Text.Trim().Replace('-',' ');
            if (txtpincode.Text != "")
            {


                cmBAL.cust_pincode = Convert.ToInt32(txtpincode.Text.Trim().Replace('-',' '));
            }
            cmBAL.cust_primary_ctn = txtctn.Text.Trim().Replace('-',' ');
            cmBAL.cust_whatsapp_ctn = txtwactn.Text.Trim().Replace('-',' ');
            cmBAL.cust_second_ctn = txtsectn.Text.Trim().Replace('-',' ');
            cmBAL.cust_third_ctn = txtthctn.Text.Trim().Replace('-',' ');

            cmBAL.cust_logdt = System.DateTime.Now;
            cmBAL.cust_insdt = System.DateTime.Now;


            customer_masterDAL cmDAL = new customer_masterDAL();
            int ret_val = cmDAL.insert_customer(cmBAL);

            if (ret_val == 0)
            {
                Response.Write("<script>alert('Please wait server is busy right now.');</script>");
            }
            else if (ret_val == -1 || ret_val == -2 || ret_val == -3)
            {
                Response.Write("<script>alert('This customer already exists in database try to change moblie number');</script>");
            }

            else if (ret_val != 0 || ret_val != -1 || ret_val != -3 || ret_val != -5)
            {
                Response.Redirect("Add_Service_Detail.aspx?cuid=" + ret_val + "");

            }
            else if (ret_val == -5)
            {
                Response.Write("<script>alert('Customer Data updated successfully');</script>");
                Response.Redirect("Filter_Customer.aspx");
                txtfirstname.Text = "";
                txtmiddlename.Text = "";
                txtsurname.Text = "";
                txtctn.Text = "";
                txtemail.Text = "";
                txtwactn.Text = "";
                txtsectn.Text = "";
                txtthctn.Text = "";
                rdomale.Checked = false;
                rdofemale.Checked = false;
                txtaddress.Text = "";
                txtctvlg.Text = "";
                txtpincode.Text = "";
            }
        }
    }
 
}